#!/usr/bin/python
import sys, os

def copyfile(filenamein, filenameout):
  filein = file(filenamein,"r")
  fileout = file(filenameout,"w")
  for line in filein:
    fileout.write(line)
  filein.close()
  fileout.close()
  
def newlang(lang):
  print "Setting up directories for %s" % lang
  os.mkdir("Config/%s" % lang)
  os.mkdir("Logs/%s" % lang)
  x = file("Config/%s/Console.help" % lang,"w")
  x.close()
  x = file("Config/%s/Console.msgs" % lang,"w")
  x.close()
  copyfile("Config/en/StaticConfig", "Config/%s/StaticConfig" % lang)
  copyfile("Config/en/Commands.ini", "Config/%s/Commands.ini" % lang)

  print "Created basic directory structure, config now needs updating for correct values for language"
  
if __name__ == '__main__':
  for lang in sys.argv[1:]:
    newlang(lang)



