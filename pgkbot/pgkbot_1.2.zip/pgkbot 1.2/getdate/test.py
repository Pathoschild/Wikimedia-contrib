import time, getdate

print "Fortnight from now %s" % time.strftime("%Y-%b-%d %H:%M:%S",time.gmtime(getdate.getdate("fortnight")))
print "Fortnight from yesterday %s" % time.strftime("%Y-%b-%d %H:%M:%S",time.gmtime(getdate.getdate("fortnight",int(time.time()-86400))))
