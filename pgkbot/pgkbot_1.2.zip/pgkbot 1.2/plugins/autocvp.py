import CVUBot.RCPLists, threading, urllib2, time, calendar, re

class AutomaticCVP:

	TITLE = "Auto CVP Frontpage"
	VERSION = 1
	PIVERSION = 1

	def __init__(self, lang, lists, reportEvent):
		self.reportEvent = reportEvent
		self.lang = lang
		self.lists = lists
		self.mainthread = ACVPThread(lists)
		self.mainthread.setDaemon(True)
		self.mainthread.start()

		#self.config = open("plugins\Config\GLTB2-%s.dbm" % lang,"c")
		#if "gltb2_mins" not in self.config:
		#	self.config["gltb2_mins"] = "10"
		#	self.config.flush()
		
	def status(self):
		if self.mainthread.isAlive():
			return "Auto CVP thread running"
		else:
			return "Auto CVP thread failed"

class ACVPThread(threading.Thread):
		
	def __init__(self, lists):
		threading.Thread.__init__(self)
		self.lists = lists
		
	def run(self):
		while True:

			# Process the dates and FA for today
			self.processToday()
			
			# Work out how long to sleep so we get to the next 23:10 UTC
			basetime = time.time()
			currtime = list(time.gmtime(basetime))
			if currtime[3] >= 23:
				currtime = list(time.gmtime(basetime+86400)) # move to tomorrow
			
			currtime[3] = 23
			currtime[4] = 10
			newtime = calendar.timegm(currtime)
			# Sleep
			print "Sleeping %s" % str(newtime-basetime)
			print "Which is %s" % time.strftime("%Y-%B-%d %HH:%MM:%SS",time.gmtime(newtime))
			time.sleep(newtime-basetime)

	def processToday(self):
			
		basetime = time.time()
		currtime = time.gmtime(basetime)

		if currtime[3] < 23:
			self.cvpFrontPage(basetime)
		else:
			self.cvpFrontPage(basetime+86400)

	def cvpFrontPage(self, basetime):
		# work out here what urls we need to check
		currmonth = time.strftime("%B",time.gmtime(basetime))
		currday = eval(time.strftime("%d",time.gmtime(basetime)))
		curryear = time.strftime("%Y",time.gmtime(basetime))
		print "%s %s %s" % (currmonth, currday, curryear)
		self.cvpURLLinks("http://en.wikipedia.org/w/index.php?title=Wikipedia:Today%%27s_featured_article/%s_%s%%2C_%s&action=raw" % (currmonth, currday, curryear))
		self.cvpURLLinks("http://en.wikipedia.org/w/index.php?title=Wikipedia:POTD row/%s_%s%%2C_%s&action=raw" % (currmonth, currday, curryear))
		self.cvpURLLinks("http://en.wikipedia.org/w/index.php?title=Wikipedia:Selected anniversaries/%s_%s&action=raw" % (currmonth, currday))
		# self.cvpURLLinks("http://en.wikipedia.org/w/index.php?title=Wikipedia:Recent_additions&action=raw") # Needs some filtering?
		
	def cvpURLLinks(self, url):
		req = urllib2.Request(url,headers={"user-agent":"pgkbot"})
		data = urllib2.urlopen(req)
		reWikilink = re.compile("\[\[(.*?)[|\]]")
		
		for line in data:
			for match in reWikilink.finditer(line):
				articlename = match.group(1)
				articletype, item = self.lists.classifyarticle(articlename)
				if articletype == CVUBot.RCPLists.c_normalarticle:
					item = CVUBot.RCPLists.ListEntry(articlename.replace(" ","_"), "pgkbot", CVUBot.RCPLists.c_watchlist, "Linked from main page" , 72, 3600)
					self.lists.articles[articlename.replace(" ","_")] = item
				else:
					exptime = item.expiry_time()
					if exptime != None:
						if time.time() + (72 * 3600) > exptime:
							item = CVUBot.RCPLists.ListEntry(articlename.replace(" ","_"), "pgkbot", CVUBot.RCPLists.c_watchlist, "linked from main page" , 72, 3600)
							self.lists.articles[articlename.replace(" ","_")] = item







