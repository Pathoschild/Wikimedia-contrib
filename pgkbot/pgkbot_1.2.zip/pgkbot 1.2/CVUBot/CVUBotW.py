#
# Main program for CVUBot on Windows like platforms
# Brings the components together and starts the Twisted reactor
#
from twisted.internet import reactor
from IRCRCReader import ReaderFactory
from IRCConsole import ConsoleFactory
from Processor import Processor
from twisted.python import log
import ListManager as ListManager
import sys, logging, signal, platform, ConfigParser
# Make this optional
try:
	import SysTray
	stray = True
except:
	stray = False

def signalled(sn, sf):
	if sn == signal.SIGINT:
		print "Got kb interrupt, stopping"
		reactor.stop()
	return


def main():
	signal.signal(signal.SIGINT,signalled)

	logfile = open("run.log","a")
	log.startLogging(logfile)
	print "Starting CVUBot : %s" % platform.platform()

	processors = {}
	langs=set()
	if len(sys.argv) > 1:
		langs = set(sys.argv[1:])
	else:
		cp = ConfigParser.SafeConfigParser()
		cp.read("systems.ini")
		langs=set(cp.get("systems","list").split(","))

	for lang in langs:
		print "Creating processor for language/system : %s" % lang
		processors[lang]=Processor(lang)

	if len(langs) > 0:
		reader = ReaderFactory(processors)
		console = ConsoleFactory(processors)
		if stray:
			x = SysTray.SysTray()
			x.start()
		reactor.run()
	else:
		print "No language/system selected to run"

	print "Shutting down logging"
	logging.shutdown()

	print "Closing all lists"
	ListManager.closeall()

	print "Stopping"
	logfile.close()
