import cPickle, sys, re, urllib2, threading, bz2, traceback

class loadconfig:
	
	TITLE = "Load config from a URL"
	VERSION = 1
	PIVERSION = 2
	
	def __init__(self, lang, lists, reportEvent):
		self.reportEvent = reportEvent
		self.lang = lang
		self.lists = lists
		self.threadstop = threading.Event()
		self.threadstop.clear()
		self.loadthread = None
	
	def unload(self):
		try:
			self.threadstop.set()
			self.loadthread.join()
		except:
			pass
		
	def commands(self):
		return {
				"cl_load" : [self.cmdLoad, "C", "!",False],
				"cl_status" : [self.cmdStatus, "C", "",False],
				"cl_cancel" : [self.cmdCancel, "C", "!", False]}

	def status(self):
		if self.loadthread != None:
			if not self.loadthread.stopped:
				return "Currently loading a flat config : %s" % self.loadthread.lasterr
		return None

	def cmdLoad(self, source, subcommand, data, user, channel):
		if self.loadthread != None:
			if not self.loadthread.stopped:
				return "Cannot start a new load, previous load still running"
				
		self.threadstop.clear() # Make sure it's not going to stop immediately
		self.loadthread = loader(self.threadstop, subcommand + " " + data, self.lists)
		self.loadthread.setDaemon(True)
		self.loadthread.start()
		return "Started thread to load config from: " + subcommand + " " + data
		
	def cmdStatus(self, source, subcommand, data, user, channel):
		if self.loadthread == None:
			return "No status to report, no loads initiated"
		if self.loadthread.stopped:
			return "Last load finished with message: %s" % self.loadthread.lasterr
		
		return "Last load running, last message %s" % self.loadthread.lasterr
	
	def cmdCancel(self, source, subcommand, data, user, channel):
		if self.loadthread != None:
			if self.loadthread.stopped:
				return "No current load to cancel"
			else:
				self.threadstop.set()
				return "Cancelling config load..."
		return "No current load to cancel"
		
class bz2url:
	
	def __init__(self, url):
		self.buffoff = 0
		self.buffer = ""
		self.data = urllib2.urlopen(url)
		self.decomp = bz2.BZ2Decompressor( ) 
		self.eof = False
	
	def read(self, size=-1):
		if self.buffoff == len(self.buffer):
			self.buffoff = 0
			self.buffer = ""

		if len(self.buffer) == self.buffoff and self.eof:
			return ""
			
		if (len(self.buffer)-self.buffoff) < size or size == -1:
			sizex = 32768* 8
			if sizex < size:
				sizex = size
			self.decompress(sizex)
		if (len(self.buffer)-self.buffoff) <= size:
			temp = self.buffoff
			self.buffoff=len(self.buffer)
			return self.buffer[temp:] 
		else:
			temp = self.buffoff
			self.buffoff = temp+size 
			return self.buffer[temp:self.buffoff] 

	def readline(self, size=-1):
		readsize = len(self.buffer) - self.buffoff
		if readsize == 0:
			self.buffoff = 0
			self.buffer = ""
		while True:
			if len(self.buffer) == self.buffoff and self.eof:
				return ""
			x = self.buffer.find("\n", self.buffoff) - self.buffoff
			
			if x ==-1 and size != -1 and size <= (len(self.buffer) - self.buffoff):
				temp = self.buffoff
				self.buffoff = temp + size
				return self.buffer[temp:self.buffoff] 
				
			if x !=-1 and (x < size or size == -1):
				temp = self.buffoff
				self.buffoff = temp+x+1
				return self.buffer[temp:self.buffoff] 
					
			if self.eof:
				temp = self.buffoff
				self.buffoff=len(self.buffer)
				return self.buffer[temp:] 

			readsize=readsize+(32768*8)
			self.decompress(readsize)
	
	def decompress(self,size):
		if self.buffoff != 0:
			self.buffer = self.buffer[self.buffoff:]
			self.buffoff = 0
		while len(self.buffer) < size or size == -1:
			temp = self.data.read(32768*4)
			if temp == "":
				self.eof=True
				break
			try:
				self.buffer = "".join((self.buffer,self.decomp.decompress(temp)))
			except bz2.EOFError:
				self.eof = True
				break
	
	
class loader(threading.Thread):
	
	def __init__(self, stopevent, url, lists):
		self.stopped = False 
		self.stopevent = stopevent
		self.url = url
		self.lasterr = "Not started"
		self.lists = lists
		threading.Thread.__init__(self)
	
	def processitems(self,list, infile):
		count = 0
		line = infile.readline()
		while line.startswith("key:"):
			item = line[4:].rstrip()
			value = cPickle.load(infile)
			list[item]=value
			line = infile.readline()
			count = count + 1
			if count % 500 == 0:
				self.stopevent.wait(0.01)  # wait a bit, let others access the list
				if self.stopevent.isSet():
					return "", count
		return line, count

	def skipitems(self, infile):
		count = 0
		line = infile.readline()
		while line.startswith("key:"):
			item = line[4:].rstrip()
			value = cPickle.load(infile)
			line = infile.readline()
			if count % 100 == 0:
				if self.stopevent.isSet():
					return "", count
			count = count + 1
		return line, count

		
	def run(self):
		try:
			infile = bz2url(self.url)
			line = infile.readline()
			if not line.startswith("Config for "):
				infile.close()
				self.lasterr = "Not a config file"
				self.stopped = True
				return
		
		# line[11:13] original lang
			reHeader = re.compile("#<(.*?)>#")

			line = infile.readline()
			while line != "":
				if self.stopevent.isSet():
					break
				x = reHeader.search(line)
				if x == None:
					self.lasterr = "Couldn't interpret header line %s" % line.strip()
					break
				
				list = x.group(1)

				if list == "editors":
					self.lasterr = "loading editor list"
					line, count = self.processitems(self.lists.editors, infile)
					self.lasterr = "Processed %d editors" % count
					continue
				if list == "articles":
					self.lasterr = "loading article list"
					line, count = self.processitems(self.lists.articles, infile)
					self.lasterr = "Processed %d articles" % count
					continue
				if list == "new users watch words":
					self.lasterr = "loading bnu list"
					line, count = self.processitems(self.lists.newuserWW, infile)
					self.lasterr = "Processed %d bnu expressions" % count
					continue
				if list == "new article watch words":
					self.lasterr = "loading bna list"
					line, count = self.processitems(self.lists.newarticleWW, infile)
					self.lasterr = "Processed %d bna expressions" % count
					continue
				if list == "wheeler words":
					self.lasterr = "loading wheels list"
					line, count = self.processitems(self.lists.moveWW, infile)
					self.lasterr = "Processed %d wheeler words" % count
					continue
				if list == "image list":
					self.lasterr = "loading cvi list"
					line, count = self.processitems(self.lists.images,infile)
					self.lasterr = "Processed %d images" % count
					continue
				if list == "acl":
					self.lasterr = "Skipping acl list"
					line, count = self.skipitems(infile)
					self.lasterr = "Skipped %d ACL" % count
					continue
				if list == "aclo":
					self.lasterr = "skipping aclo list"
					line, count = self.skipitems(infile)
					self.lasterr = "Skipped %d ACLO" % count
					continue
				if list == "flag list":
					self.lasterr = "loading flagged list"
					line, count = self.processitems(self.lists.flaglist,infile)
					self.lasterr = "Processed %d flag list" % count
					continue
				
				self.lasterr = "Skipping unknown list %s" % list
				line, count = self.skipitems(infile)
				self.lasterr = "Skipped unknown list %s" % list
				
			self.lasterr = "Finished OK"
		except:
			self.lasterr = "Unhandled exception"
			traceback.print_exc()
		if self.stopevent.isSet():
			self.lasterr = "Cancelled"
		self.stopped = True
		infile = None # The object can be destroyed now

