# This is a temporary module to allow upgrading of existing configs, it will disappear in a future release

import CVUBot.RCPLists

ListEntry=CVUBot.RCPLists.ListEntry
