import cPickle, sys, re
from bz2 import BZ2File
# maps for editor types
editortype={
	0:"Whitelist",
	1:"Blacklist",
	2:"Adminlist",
	5:"Bot"}
		
articletype = {
	0:"CVP",
	1:"CNVP"}

imagetype = {
	0:"CVI"}

def processlist(maintype, infile, typemap, outfile):
	count = 0
	line = infile.readline()
	while line.startswith("key:"):
		key = line[4:].rstrip()
		print key
		item = cPickle.load(infile)
		type = typemap.get(item.type,"Unknown")
		outfile.write("%s,%s,%s,%s,%s,%s,%s\n" % (maintype,type, item['itemname'], item['editor'], item['timestamp'],item['expiry'], item['reason']))
		line = infile.readline()
		count = count + 1
	return line, count

def skip(infile):
	count = 0
	line = infile.readline()
	while line.startswith("key:"):
		key = line[4:].rstrip()
		item = cPickle.load(infile)
		line = infile.readline()
		count = count + 1
	return line, count


if len(sys.argv) != 3:
	print "Usage: ExtractCSV2.py <inputfilename> <outputfilename>"
	sys.exit(2)

infile = BZ2File(sys.argv[1],"r")
opfile=open(sys.argv[2],"w")
opfile.write("Type,Sub type,Name,Who Added,When Added,Expiry Date,Reason\n")

line = infile.readline()
if not line.startswith("Config for "):
	infile.close()
	print "Doesn't look like a flat config file"
	sys.exit(1)
print "Config file was originally for %s" % line[11:13]
line = infile.readline()
while line != "":
	if line.startswith("#<editors>#"):
		line, count = processlist("User",infile, editortype, opfile)
		print "Processed %d editors" % count
	if line.startswith("#<articles>#"):
		line, count = processlist("Article",infile, articletype, opfile)
		print "Processed %d articles" % count
	if line.startswith("#<new users watch words>#"):
		line, count = skip(infile)
		print "Skipped %d bnu expressions" % count
	if line.startswith("#<new article watch words>#"):
		line, count = skip(infile)
		print "Skipped %d bna expressions" % count
	if line.startswith("#<wheeler words>#"):
		line, count = skip(infile)
		print "Skipped %d wheeler words" % count
	if line.startswith("#<image list>#"):
		line, count = processlist("Image",infile, imagetype, opfile)
		print "Processed %d images" % count
	if line.startswith("#<acl>#"):
		line, count = skip(infile)
		print "Skipped %d acl entries" % count
	if line.startswith("#<aclo>#"):
		line, count = skip(infile)
		print "Skipped %d aclo entries" % count
	if line.startswith("#<flag list>#"):
		line, count = skip(infile)
		print "Skipped %d flag entries" % count

opfile.close()
infile.close()





