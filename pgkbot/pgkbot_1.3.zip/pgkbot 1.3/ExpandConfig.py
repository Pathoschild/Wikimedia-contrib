import cPickle, sys, re
from bz2 import BZ2File
import CVUBot.ListManager as ListManager

def writeitems(list, infile):
	count = 0
	line = infile.readline()
	while line.startswith("key:"):
		item = line[4:].rstrip()
		value = cPickle.load(infile)
		list[item]=value
		line = infile.readline()
		count = count + 1
		
	list.close()
	return line, count

lang = sys.argv[1]
filename = sys.argv[2]
infile = BZ2File(filename,"r")

line = infile.readline()
if not line.startswith("Config for "):
	infile.close()
	print "Doesn't look like a flat config file"
	sys.exit(1)
print "Config file was originally for %s" % line[11:13]

line = infile.readline()
while line != "":
	if line.startswith("#<editors>#"):
		line, count = writeitems(ListManager.getlist(lang,'UserList'), infile)
		print "Processed %d editors" % count
	if line.startswith("#<articles>#"):
		line, count = writeitems(ListManager.getlist(lang,'ArticleList'), infile)
		print "Processed %d articles" % count
	if line.startswith("#<new users watch words>#"):
		line, count = writeitems(ListManager.getlist(lang,'NewUserWatchWord'), infile)
		print "Processed %d bnu expressions" % count
	if line.startswith("#<new article watch words>#"):
		line, count = writeitems(ListManager.getlist(lang,'NewArticleWatchWord'), infile)
		print "Processed %d bna expressions" % count
	if line.startswith("#<wheeler words>#"):
		line, count = writeitems(ListManager.getlist(lang,'WheelerWords'), infile)
		print "Processed %d wheeler words" % count
	if line.startswith("#<image list>#"):
		line, count = writeitems(ListManager.getlist(lang,"ImageList"),infile)
		print "Processed %d images" % count
	if line.startswith("#<acl>#"):
		line, count = writeitems(ListManager.getlist(lang,"Acl"),infile)
		print "Processed %d ACL" % count
	if line.startswith("#<aclo>#"):
		line, count = writeitems(ListManager.getlist(lang,"Aclo"),infile)
		print "Processed %d ACLO" % count
	if line.startswith("#<flag list>#"):
		line, count = writeitems(ListManager.getlist(lang,"Flaglist"),infile)
		print "Processed %d flag list" % count


infile.close()


