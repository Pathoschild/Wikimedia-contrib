#
# Main program for CVUBot on UNIX like platforms
# Brings the components together and starts the Twisted reactor
#
from twisted.internet import reactor
from IRCRCReader import ReaderFactory
from IRCConsole import ConsoleFactory
from Processor import Processor
from twisted.python import log
import ListManager as ListManager
import sys, logging, signal, os, platform, ConfigParser, time

def signalled(sn, sf):
        if sn == signal.SIGHUP:
                print "Got hup signal, ignoring"
                return
        if sn == signal.SIGTERM:
                print "Got term signal, stopping"
        reactor.stop()
        return

def main():
        # Fork into two processes the master writes the pid of it's child and returns
        pid = os.fork()
        if pid != 0:
          pidfile = open("pid","w")
          pidfile.write("%i\n" % pid)
          pidfile.close()
          return

        signal.signal(signal.SIGTERM,signalled)
        signal.signal(signal.SIGINT,signalled)
        signal.signal(signal.SIGHUP,signalled)

        logfile = open("run.log","a")

        log.startLogging(logfile)
        print "Starting CVUBot : %s" % platform.platform()

        processors = {}
        langs=set()
        if len(sys.argv) > 1:
                langs = set(sys.argv[1:])
        else:
                cp = ConfigParser.SafeConfigParser()
                cp.read("systems.ini")
                langs=set(cp.get("systems","list").split(","))
        
        for lang in langs:
                print "Creating processor for language/system : %s" % lang
                processors[lang]=Processor(lang)

        if len(langs) > 0:
                reader = ReaderFactory(processors)
                console = ConsoleFactory(processors)

                reactor.run()
        else:
                print "No language/system selected to run"

	print "Unloading all processors"
	for processor in processors.itervalues():
		processor.unload()

        print "Closing all lists"
        ListManager.closeall()

        print "Shutting down logging"
        logging.shutdown()

        print "Stopped"
        logfile.close()

