#
# Main program for CVUBot on Windows like platforms
# Brings the components together and starts the Twisted reactor
#
from twisted.internet import reactor
from IRCRCReader import ReaderFactory
from IRCConsole import ConsoleFactory
from Processor import Processor
from twisted.python import log
import ListManager as ListManager
import sys, logging, signal, platform, ConfigParser
# Make this optional
try:
	import SysTray
	stray = True
except:
	stray = False

def signalled(sn, sf):
	if sn == signal.SIGINT:
		print "Got kb interrupt, stopping"
		reactor.stop()
	return


def main():
	signal.signal(signal.SIGINT,signalled)

	logfile = open("run.log","a")
	log.startLogging(logfile)
	print "Starting CVUBot : %s" % platform.platform()

	cp = ConfigParser.SafeConfigParser()
	try:
		cp.read("systems.ini")
	except:
		pass

	processors = {}
	langs=set()
	if len(sys.argv) > 1:
		langs = set(sys.argv[1:])
	elif cp.has_option("systems","list"):
		if len(cp.get("systems","list").strip()) > 0:
			langs=set(cp.get("systems","list").split(","))

	for lang in langs:
		print "Creating processor for language/system : %s" % lang
		processors[lang]=Processor(lang)

	if len(langs) > 0:
		reader = ReaderFactory(processors)
		console = ConsoleFactory(processors)
		if stray:
			x = SysTray.SysTray(reader, console, processors)
			x.setName("System tray")
			x.setDaemon(True)
			x.start()
			
		if cp.has_section("control"):
			control = Control.control(reader, console, processors, cp.get("control","bindaddress"), cp.get("control","bindport"),cp.get("control","username"), cp.get("control","password"))

		reactor.run()
	else:
		print "No language/system selected to run"

	print "Unloading all processors"
	for processor in processors.itervalues():
		processor.unload()

	print "Closing all lists"
	ListManager.closeall()

	print "Shutting down logging"
	logging.shutdown()

	print "Stopping"
	logfile.close()
