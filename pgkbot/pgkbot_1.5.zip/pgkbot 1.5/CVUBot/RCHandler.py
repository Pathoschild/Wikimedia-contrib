import RCPLists, getdate, ListManager, re, time
from urllib import quote

class StandardHandler:
	
	allevents = set((
		"once","newuser","wwuser","block","delete","move","upload","wheeler","blockconflict",
		"grey","cvi","cvp","watched","bigremove","bigedit","bignew","tinynew","black",
		"-white","-admin","-bot","cmds","cmdsq","bna","ip","iptmp","ipcat","unblock","protect","unprotect"))

	def __init__(self, Lists, lang, getMsg):
		self.Lists = Lists
		self.getMsg = getMsg
		self.blocks = ListManager.getlist(lang,'Blocklist')  # Not a shelf since we might bugger up over down periods of the bot
		self.config = ListManager.getlist(lang,'Config')
		self.reOldid = re.compile("oldid=(\d+)")
		self.reNewid = re.compile("diff=(\d+)")
		
	def unload(self):
		pass

	def process_rcNew(self, rcevent, resultlist):

		sizeattrib=""
		sizereset=""
		classes = set()
		msgno = -1
		editortype, item = self.Lists.classifyeditor(rcevent.editor)
		articletype, artitem = self.Lists.classifyarticle(rcevent.articlename)
		classes.add(RCPLists.c_editor_events[editortype])

		# Don't care about users creating their own page or talk page nor admins or whitelisted users
		if (rcevent.userpage or rcevent.usertalk) and (rcevent.user == rcevent.editor or editortype in (RCPLists.c_adminlist, RCPLists.c_whitelist)):
			return
		
		if editortype in (RCPLists.c_blacklist, RCPLists.c_greylist):
			msgno = 5000+editortype
			
		if rcevent.namespace == 10 and editortype == RCPLists.c_anon:
			msgno = 5000+editortype
			classes.add("iptmp")

		if rcevent.namespace == 14 and editortype == RCPLists.c_anon:
			msgno = 5000+editortype
			classes.add("ipcat")

		if rcevent.size > eval(self.config["newbig"]):
			msgno = 5010+editortype
			classes.add("bignew")
			sizeattrib=self.getMsg(100)
			sizereset=self.getMsg(102)
		if rcevent.size < eval(self.config["newsmall"]):
			msgno = 5020 + editortype
			classes.add("tinynew")
			sizeattrib=self.getMsg(100)
			sizereset=self.getMsg(102)
			
		reason = ""
		word = ""
		if self.config["bnubnasame"] == "yes":
			wwlist = self.Lists.newuserWW
		else:
			wwlist = self.Lists.newarticleWW

		for word, item in wwlist.iteritems():

			word = word.lower()
			reason = item.reason
			result = re.search(word, rcevent.articlename,re.I)
			if result != None:
				msgno = 5040+editortype
				classes.add("bna")
				break
			
		if articletype == RCPLists.c_watchlist:
			msgno = 5030+editortype
			classes.add("watched")
			classes.add("cvp")

		if msgno == -1:
			return
		
		if rcevent.minor:
			minor = "M"
		else:
			minor = ""
		
		msg = self.getMsg(msgno, {
			"article": rcevent.articlename,
			"earticle": quote(rcevent.articlename.replace(' ','_')),
			"editor": rcevent.editor,
			"eeditor": quote(rcevent.editor.replace(' ','_')),
			"size": "%d" % rcevent.size,
			"reason": rcevent.summary,
			"minor": minor,
			"sizeattrib": sizeattrib,
			"sizereset": sizereset,
			"watchword": word,
			"wwreason" : reason
			})

		resultlist.append((msg, classes))

	def process_rcEdit(self, rcevent, resultlist):
		sizeattrib=""
		sizereset=""
		classes = set()
		msgno = -1
		articletype, artitem = self.Lists.classifyarticle(rcevent.articlename)

		if articletype == RCPLists.c_ignorelist:
			return

		editortype, item = self.Lists.classifyeditor(rcevent.editor)
		
		if editortype == RCPLists.c_adminlist and self.config["glonrollback"] not in ("0","00") and rcevent.rbuser != None:
			if rcevent.rbuser != rcevent.editor:  # Don't concern with users rolling back themselves
				editortype2, item2 = self.Lists.classifyeditor(rcevent.rbuser)
				if editortype2 in (RCPLists.c_anon, RCPLists.c_normal, RCPLists.c_whitelist, RCPLists.c_greylist):
					item = RCPLists.ListEntry(rcevent.rbuser.replace("_"," "), rcevent.editor, RCPLists.c_greylist, "admin rollback on [[%s]]" % rcevent.articlename , eval(self.config["glonrollback"]), 60)
					self.Lists.greylist[rcevent.rbuser.replace(" ","_")] = item
		
		# Ignore smaller edits by the owner of the page, but do concerning blanking and large additions 
		if (rcevent.userpage or rcevent.usertalk) and (rcevent.user == rcevent.editor):
			if editortype not in (RCPLists.c_blacklist, RCPLists.c_greylist):
				return
			if not (rcevent.size > eval(self.config["editbig"]) or rcevent.size < eval(self.config["editblank"])):
				return

		classes.add(RCPLists.c_editor_events[editortype])
		
		if editortype in (RCPLists.c_blacklist, RCPLists.c_greylist):
			msgno = 5100+editortype
			
		if rcevent.namespace == 10 and editortype == RCPLists.c_anon:
			msgno = 5100+editortype
			classes.add("iptmp")

		if rcevent.namespace == 14 and editortype == RCPLists.c_anon:
			msgno = 5100+editortype
			classes.add("ipcat")

		if rcevent.size > eval(self.config["editbig"]):
			msgno = 5110+editortype
			classes.add("bigedit")
			sizeattrib=self.getMsg(100)
			sizereset=self.getMsg(102)
		if articletype == RCPLists.c_watchlist:
			msgno = 5130+editortype
			classes.add("watched")
			classes.add("cvp")
		if rcevent.size < eval(self.config["editblank"]):
			msgno = 5120+editortype
			classes.add("bigremove")
			sizeattrib=self.getMsg(101)
			sizereset=self.getMsg(103)

		if msgno == -1:
			return
		if rcevent.minor:
			minor = "M"
		else:
			minor = ""
		
		res = self.reOldid.search(rcevent.difflink)
		if res == None:
			oldid="0"
		else:
			oldid=res.group(1)

		res = self.reNewid.search(rcevent.difflink)
		if res == None:
			newid="0"
		else:
			newid=res.group(1)


		reason = rcevent.summary
		# self.reWikiTidy.replace("\1]]",rcevent.summary)

		msg = self.getMsg(msgno, {
			"article": rcevent.articlename,
			"earticle": quote(rcevent.articlename.replace(' ','_')),
			"oldid": oldid,
			"newid": newid,
			"editor": rcevent.editor,
			"eeditor": quote(rcevent.editor.replace(' ','_')),
			"size": "%d" % rcevent.size,
			"reason": reason,
			"minor": minor,
			"sizeattrib": sizeattrib,
			"sizereset": sizereset
			})

		resultlist.append((msg, classes))

	def process_rcNewEditor(self, rcevent, resultlist):
		classes = set(["newuser"])
		msgno = 5200
		word = ""
		reason = ""
		for word, item in self.Lists.newuserWW.iteritems():
			word = word.lower()
			reason = item.reason
			result = re.search(word, rcevent.editor,re.I)
			if result != None:
				msgno = 5201
				classes.add("wwuser")
				break
				
		if rcevent.editor != rcevent.creator:
			msgno = msgno + 10

		msg = self.getMsg(msgno,{
			"editor": rcevent.editor,
			"eeditor": quote(rcevent.editor.replace(" ","_")),
			"creator": rcevent.creator,
			"ecreator": quote(rcevent.creator.replace(" ","_")),
			"watchword": word,
			"wwreason": reason
			})

		resultlist.append((msg, classes))
		if "wwuser" in classes:
			item = RCPLists.ListEntry(rcevent.editor.replace(" ","_"), "CVUBot", RCPLists.c_greylist, "new user matching bnu", eval(self.config["glonbnu"]),60)
			self.Lists.greylist[rcevent.editor.replace(" ","_")]=item

		if eval(self.config["flagnewuser"]) > 0:
			item = RCPLists.ListEntry(rcevent.editor.replace(" ","_"), "CVUBot", RCPLists.c_flagged, "New user created %s" % time.strftime("%d-%b-%Y %H:%M:%S UTC", time.gmtime()) , eval(self.config["flagnewuser"]),3600)
			self.Lists.flaglist[rcevent.editor.replace(" ","_")]=item

	def process_rcDelArticle(self, rcevent, resultlist):
		classes=set(("delete",))
		msgno=5300
		articletype, artitem = self.Lists.classifyarticle(rcevent.articlename)
		if articletype == RCPLists.c_ignorelist:
			return
		if articletype == RCPLists.c_watchlist:
			classes.add("watched")
			classes.add("cvp")
			msgno=5301
		
		msg = self.getMsg(msgno, {
			"earticle": quote(rcevent.articlename.replace(' ','_')),
			"article": rcevent.articlename,
			"editor": rcevent.admin,
			"eeditor": quote(rcevent.admin.replace(' ','_')),
			"reason": rcevent.reason
			})

		resultlist.append((msg, classes))

	def process_rcUnblockEditor(self, rcevent, resultlist):
		editortype, item = self.Lists.classifyeditor(rcevent.editor, True)

		if editortype == RCPLists.c_iprange:
			msgno = 5701
		else:
			msgno = 5700
			self.blocks.deleteitem(rcevent.editor,rcevent.admin,'Unblocked:%s' % rcevent.reason)

		classes = set(("unblock",))
		msg = self.getMsg(msgno, {
			"blockname": rcevent.editor,
			"eblockname": quote(rcevent.editor.replace(' ','_')),
			"editor": rcevent.admin,
			"eeditor": quote(rcevent.admin.replace(' ','_')),
			"reason": rcevent.reason
			})
		resultlist.append((msg, classes))
		
		editor = rcevent.editor.replace(" ","_")
		
		# Autoblacklist if being unblocked and not on the blacklist (e.g. those indef blocked..)
		item = self.Lists.editors.get(editor,None) # Don't care aboute greylist
		if item == None:
			item = RCPLists.ListEntry(editor, rcevent.admin, RCPLists.c_blacklist, "Autoblacklist UNBLOCKED: %s" % rcevent.reason, 48, 3600)
			self.Lists.editors[editor]=item

		
	def process_rcBlockEditor(self, rcevent, resultlist):
		
		editortype, item = self.Lists.classifyeditor(rcevent.editor, True)
		
		if editortype == RCPLists.c_iprange:
			msgno = 5401
		else:
			msgno = 5400
			
		ipcat = self.Lists.getipcat(rcevent.editor)
		if ipcat:
			ipcat = "(%s)" % ipcat.reason
		else:
			ipcat =""

		classes = set(("block",))
		msg = self.getMsg(msgno, {
			"blockname": rcevent.editor,
			"eblockname": quote(rcevent.editor.replace(' ','_')),
			"editor": rcevent.admin,
			"eeditor": quote(rcevent.admin.replace(' ','_')),
			"reason": rcevent.reason,
			"length": rcevent.length,
			"ipcat": ipcat
			})

		if editortype == RCPLists.c_iprange:   # Was a range so the rest of this is irrelevant
			resultlist.append((msg, classes))
			return
		
		# Blocked they won't be vandalising again so remove from greylist
		if rcevent.editor.replace(" ","_") in self.Lists.greylist:
			self.Lists.greylist.deleteitem(rcevent.editor.replace(" ","_"),"system","User blocked")
				
		if rcevent.length != None:
			if rcevent.length.lower() in ("indefinite","infinite"):
				expiresecs = 0
			else:
				expiresecs = getdate.getdate(rcevent.length)
				if expiresecs == -1:
					expiresecs=None
					print "Couldn't work out blocklength %s" % rcevent.length
				else:
					expiresecs=expiresecs-time.time()

		if rcevent.length != None and expiresecs != None:
			newitem = RCPLists.ListEntry(rcevent.editor, rcevent.admin, 0, rcevent.reason, expiresecs, 1)

			oldblock = self.blocks.get(rcevent.editor)
			if oldblock == None:
				self.blocks[rcevent.editor] = newitem
			else:
				if not self.checkBlockConflict(newitem, oldblock, resultlist):
					return # wasn't conflicting so don't bother reporting or autoblacklisting

		resultlist.append((msg, classes))
	
		blacklist = True
		
		blacklistlength=0
		onehour = 60 * 60 
		oneday = 24 * onehour
		
		if rcevent.length != None:
			if expiresecs > 0:   # not indef, less than 12 hours, blacklist for 1 day after expiry
				blacklistlength = oneday
			if expiresecs > 12 * onehour:
				blacklistlength=3 * oneday
			if expiresecs > 36 * onehour:
				blacklistlength=14 * oneday
			if expiresecs > 4 * oneday:
				blacklistlength=30 * oneday
			if expiresecs > 28 * oneday:
				blacklistlength = 60 * oneday
			blacklistlength = blacklistlength + expiresecs
		else:
			blacklistlength = 7 * oneday
		
		if blacklistlength == 0:
			return
		
		editor = rcevent.editor.replace(" ","_")
	
		item = self.Lists.editors.get(editor,None) # Don't care aboute greylist
		if item != None:
			if item.type != RCPLists.c_blacklist:
				msg = self.getMsg(60+item.type, {"editor": editor})
				resultlist.append((msg, classes))
				return

		if item == None or (item.expiry != 0 and ((item.expiry * item.expiryconvsecs) + item.timestamp) < (time.time() + blacklistlength)):
			item = RCPLists.ListEntry(editor, rcevent.admin, RCPLists.c_blacklist, "Autoblacklist: %s" % rcevent.reason, blacklistlength, 1)
			self.Lists.editors[editor]=item

		msg = self.getMsg(10000+(item.type*100)+22,item)

		resultlist.append((msg, classes))

		
	def checkBlockConflict(self, newitem, olditem, resultlist):
		classes = set(("blockconflict",))
		msgno = 0

		if newitem.expiry == 0 and olditem.expiry != 0:
			msgno = 5800

		if olditem.expiry == 0 and newitem.expiry != 0:
			self.blocks[newitem.what] = newitem # take the shortest
			msgno = 5801

		if olditem.expiry != 0 and newitem.expiry != 0:
			diff = (newitem.timestamp+newitem.expiry) - (olditem.timestamp+olditem.expiry)
			if diff < 0:
				self.blocks[newitem.what] = newitem # take the shortest
				if abs(diff) > eval(self.config["blockconflict"]) * 3600:
					msgno = 5802
			else:
				if diff > eval(self.config["blockconflict"]) * 3600:
					msgno = 5803

		if msgno == 0:
			return False

		msg = self.getMsg(msgno, {
			"blockname": newitem.what,
			"eblockname": quote(newitem.what.replace(' ','_')),
			"oldadmin": olditem.who,
			"newadmin": newitem.who,
			"oldtime": olditem['expiry'],
			"newtime": newitem['expiry'],
			"oldreason": olditem['reason'],
			"newreason": newitem['reason'],
			})
		resultlist.append((msg, classes))
		return True
		
	def process_rcProtect(self, rcevent, resultlist):
		if rcevent.namespace in (2,3):
			return
		
		classes = set(("protect",))
		
		msg = self.getMsg(5900, {
			"editor": rcevent.editor,
			"eeditor": quote(rcevent.editor.replace(' ','_')),
			"article": rcevent.itemname,
			"earticle": quote(rcevent.itemname.replace(' ','_')),
			"comment": rcevent.comment
			})

		resultlist.append((msg, classes))

	
	def process_rcUnprotect(self, rcevent, resultlist):
		if rcevent.namespace in (2,3):
			return
		
		classes = set(("unprotect",))
		
		msg = self.getMsg(5901, {
			"editor": rcevent.editor,
			"eeditor": quote(rcevent.editor.replace(' ','_')),
			"article": rcevent.itemname,
			"earticle": quote(rcevent.itemname.replace(' ','_')),
			"comment": rcevent.comment
			})

		resultlist.append((msg, classes))
		
	def process_rcMovePage(self, rcevent, resultlist):
		classes = set(("move",))
		editortype, item = self.Lists.classifyeditor(rcevent.editor)
		classes.add(RCPLists.c_editor_events[editortype])
		
		msgno = 5500+editortype
		for word in self.Lists.moveWW:
			word = word.lower()
			result = re.search(word, rcevent.nameto, re.I)
			if result != None:
				msgno = 5510+editortype
				classes.add("wheeler")
				break
			else:
				result = re.search(word, rcevent.namefrom, re.I)
				if result != None:
					msgno = 5520+editortype
					classes.add("wheeler")
					break

		msg = self.getMsg(msgno, {
			"editor": rcevent.editor,
			"eeditor": quote(rcevent.editor.replace(' ','_')),
			"fromname": rcevent.namefrom,
			"efromname": quote(rcevent.namefrom.replace(' ','_')),
			"toname": rcevent.nameto,
			"etoname": quote(rcevent.nameto.replace(' ','_')),
			"reason": rcevent.reason
			})

		resultlist.append((msg, classes))

	def process_rcUploaded(self, rcevent, resultlist):
		classes = set(("upload",))
		editortype, item = self.Lists.classifyeditor(rcevent.editor)
		imagetype, imgitem = self.Lists.classifyimage(rcevent.itemname)
		classes.add(RCPLists.c_editor_events[editortype])
		msgno = 5600+editortype
		
		if imagetype == RCPLists.c_img_watchlist:
			msgno = 5610+editortype
			classes.add("cvi")

		msg = self.getMsg(msgno,{
			"editor": rcevent.editor,
			"eeditor": quote(rcevent.editor.replace(' ','_')),
			"reason": rcevent.comment,
			"uploaditem": rcevent.itemname,
			"euploaditem": quote(rcevent.itemname.replace(' ','_')),
			})

		resultlist.append((msg, classes))

	def handleRCEvent(self, rcEvent, resultlist):
		handler = getattr(self,"process_"+rcEvent.__class__.__name__,None)
		if handler != None:
			handler(rcEvent, resultlist)

