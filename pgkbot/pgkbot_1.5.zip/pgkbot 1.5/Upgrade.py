#!/usr/bin/python
import sys, shelve, CVUBot.Utils, os.path, imp, CVUBot.Processor, os, NewLang, CVUBot.ListManager, platform, ConfigParser
try:
  import getdate
  gdate = True
except:
  gdate = False

names=["Acl", "ArticleList", "Config","ImageList", "NewUserWatchWord","Routes","Stats","UserList","WheelerWords", "AclO","Flaglist","NewArticleWatchWord"]

def copyfile(filenamein, filenameout):
  filein = file(filenamein,"r")
  fileout = file(filenameout,"w")
  for line in filein:
    fileout.write(line)
  filein.close()
  fileout.close()

def mergeconfig2(src1, src2, dest):
  inconf1 = ConfigParser.SafeConfigParser()
  if os.path.isfile(src1):
    inconf1.read(src1)
  inconf2 = ConfigParser.SafeConfigParser()
  if os.path.isfile(src2):
    inconf2.read(src2)
  for section in inconf1.sections():
    if not inconf2.has_section(section):
      inconf2.add_section(section)
    for item in inconf1.items(section):
      if not inconf2.has_option(section, item[0]):
        inconf2.set(section, item[0], item[1])
  outfile = file(dest,"w")
  inconf2.write(outfile)
  outfile.close()

  
def mergeconfig(filename, olddict, renames={}, commentout=[]):
  mergewith = open(filename,"r")
  alllines = list(mergewith)
  mergewith.close()
  mergeto = open(filename,"w")
  for line in alllines:
    if line == "" or line.startswith("#"):
      mergeto.write(line)
      continue
    try:
      items = line.split('=',1)
      oldname = renames.get(items[0], items[0])
      if oldname.lower() in olddict:
        mergeto.write("%s=%s\n" % (items[0], olddict[oldname.lower()]))
      else:
        if items[0] in commentout:
          mergeto.write("#")
        mergeto.write(line)
      continue
    except ValueError:
      mergeto.write(line)
      continue
  # Copy across plugin keys
  for key, item in olddict.iteritems():
    if key.startswith("plugin_"):
      mergeto.write(key+"="+item+"\n")
  mergeto.close()

if not gdate:
  print "The getdate python extension is missing, please install this before proceeding"
  if platform.system == "Windows":
    print "For windows you can run the installer in the getdate directory, getdate_inst.exe or build from scratch (complex)"
  else:
    print "You will need to build the module from scratch, this requires a suitably configured python environment and c compiler, run the setup.py file with the install parameter in the getdate directory"
  system.exit(1)

if len(sys.argv) < 2:
  print "Usage: python Upgrade.py <olddirectory> [<lang>*]  - uses systems.ini in old directory if no langs specified"
  sys.exit(2)

oldpath = os.path.abspath(sys.argv[1])
if not os.path.isdir(oldpath):
  print "%s is not a directory" % sys.argv[1]
  sys.exit(2)

#try:
#  olddets = imp.find_module("Version",[oldpath+"/CVUBot"])
#except:
#  print "Couldn't work out old version, the old directory maybe wrong or maybe incompatible with the upgrade process"
#  sys.exit(2)
#try:
#  oldver = imp.load_module("Version",olddets[0],olddets[1],olddets[2])
#except:
#  print "Couldn't work out old version, the old directory maybe wrong or maybe incompatible with the upgrade process"
#  try: 
#   olddets[0].close()
#  finally:
#    sys.exit(2)

#try:
#  oldver = oldver.VERSION
#except:
#  print "Couldn't work out old version, the old directory maybe wrong or maybe incompatible with the upgrade process"
#  sys.exit(2)
    
#print "Upgrading from version %2.2f to %2.2f" % (oldver, CVUBot.Version.VERSION)
#print ""
print "Processing basic config"
oldconf1 = CVUBot.Utils.readConfig(oldpath + "/Config/IRCConsole.conf")
oldconf2 = CVUBot.Utils.readConfig(oldpath + "/Config/RCReader.conf")

print "Updating IRCConsole.conf"
mergeconfig("Config/IRCConsole.conf", oldconf1,{},("operpassword","password","nickoload"))
print "Updating RCReader.conf"
mergeconfig("Config/RCReader.conf", oldconf2)

namemap={}
for name in names:
 namemap[name.lower()]=name

if len(sys.argv) > 2:
	langs = set(sys.argv[2:])
else:
	cp = ConfigParser.SafeConfigParser()
	cp.read(oldpath+"/systems.ini")
	langs=set(cp.get("systems","list").split(","))

copyfile(oldpath+"/systems.ini","systems.ini")

for lang in langs:
  print "Initial processing lang %s " % lang
  if not os.path.isdir("Config/%s" % lang):
    NewLang.newlang(lang)

for lang in langs:
  print ""
  print "Processing lang %s " % lang
  oldstatic = CVUBot.Utils.readConfig(oldpath + "/Config/%s/StaticConfig" % lang)
  mergeconfig("Config/%s/StaticConfig" % lang, oldstatic, {}, ("dumpfreq","mysql_user","mysql_password","mysql_dbase","mysql_host"))  
  newstatic = CVUBot.Utils.readConfig("Config/%s/StaticConfig" % lang)
  mergeconfig2(oldpath+"Config/%s/Commands.ini" %lang ,"Config/%s/Commands.ini" %lang ,"Config/%s/Commands.ini" %lang)
  print "Copying message files"

  if os.path.isfile(oldpath+"Config/%s/Console.msgs"):
    copyfile(oldpath+"Config/%s/Console.msgs","Config/%s/Console.msgs")
  if os.path.isfile(oldpath+"Config/%s/Console.help"):
    copyfile(oldpath+"Config/%s/Console.help","Config/%s/Console.help")

  print "Copying list files"
  for key, value in oldstatic.iteritems():
    if key.startswith("list_") and value in ("LMShelf", "LMSimpleShelf"):
      if key in newstatic:
        shelfname = namemap[key[5:]]+".dbm"
        oldshelf = shelve.open(oldpath+"/Config/%s/%s" %(lang, shelfname),"c")
        newlist = CVUBot.ListManager.getlist(lang, namemap[key[5:]])
        for key,item in oldshelf.iteritems():
          if value == "LMShelf":
            if not item.expired():
              newlist[key]=item
          else:
            newlist[key]=item
        newlist.close()
print "Finished processing all files, remember to check config file Config/IRCConsole.conf and Config/*/StaticConfig as new options have been added to these files"
