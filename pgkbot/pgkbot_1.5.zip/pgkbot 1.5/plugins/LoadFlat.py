import CVUBot.bz2url, CVUBot.FlatConfig, traceback, threading


class loadconfig:
	
	TITLE = "Load config from a URL"
	VERSION = 2
	PIVERSION = 2
	
	def __init__(self, lang, lists, reportEvent):
		self.reportEvent = reportEvent
		self.lang = lang
		self.lists = lists
		self.threadstop = threading.Event()
		self.threadstop.clear()
		self.loadthread = None
		
	def unload(self):
		try:
			self.threadstop.set()
			self.loadthread.join()
		except:
			pass
		
	def commands(self):
		return {
				"cl_load" : [self.cmdLoad, "C", "!",False],
				"cl_status" : [self.cmdStatus, "C", "",False],
				"cl_cancel" : [self.cmdCancel, "C", "!", False]}

	def status(self):
		if self.loadthread != None:
			if not self.loadthread.stopped:
				return "Currently loading a flat config : %s" % self.loadthread.lasterr
		return None

	def cmdLoad(self, source, subcommand, data, user, channel):
		if self.loadthread != None:
			if not self.loadthread.stopped:
				return "Cannot start a new load, previous load still running"
				
		self.threadstop.clear() # Make sure it's not going to stop immediately
		self.loadthread = loader(self.threadstop, subcommand + " " + data, self.lists, self.lang)
		self.loadthread.setDaemon(True)
		self.loadthread.setName("Load flat config for %s" % self.lang)
		self.loadthread.start()
		return "Started thread to load config from: " + subcommand + " " + data
		
	def cmdStatus(self, source, subcommand, data, user, channel):
		if self.loadthread == None:
			return "No status to report, no loads initiated"
		if self.loadthread.stopped:
			return "Last load finished with message: %s" % self.loadthread.lasterr
		
		return "Last load running, last message %s" % self.loadthread.lasterr
	
	def cmdCancel(self, source, subcommand, data, user, channel):
		if self.loadthread != None:
			if self.loadthread.stopped:
				return "No current load to cancel"
			else:
				self.threadstop.set()
				return "Cancelling config load..."
		return "No current load to cancel"
		
class loader(threading.Thread):
	
	def __init__(self, stopevent, url, lists, lang):
		self.stopped = False 
		self.stopevent = stopevent
		self.url = url
		self.lang = lang
		self.lasterr = "Not started"
		self.lists = lists
		threading.Thread.__init__(self)
		
	def msghandler(msg):
		self.lasterr = msg
		
	def run(self):
		try:
			infile = CVUBot.bz2url.bz2url(self.url)
			completed = CVUBot.FlatConfig.loadconfig(self.lang, infile, self.msghandler, self.stopevent)
			if not completed:
				self.lasterr = 'Cancelled'
			else:
				self.lasterr = 'Finished'
		except:
			self.lasterr = 'Failed, unhandled exception'
			traceback.print_exc()
			self.stopped = True
		infile = None # The object can be destroyed now
		self.stopped = True

