import CVUBot.ListManager as ListManager
import sys
# maps for editor types
editortype={
	0:"Whitelist",
	1:"Blacklist",
	2:"Adminlist",
	5:"Bot"}
		
articletype = {
	0:"CVP",
	1:"CNVP"}

imagetype = {
	0:"CVI"}

def processlist(maintype, list, typemap, outfile):
	for key, item in list.iteritems():
		type = typemap.get(item.type,"Unknown")
		outfile.write("%s,%s,%s,%s,%s,%s,%s\n" % (maintype,type, item['itemname'], item['editor'], item['timestamp'],item['expiry'], item['reason']))

if len(sys.argv) != 3:
	print "Usage: ExtractCSV.py <lang> <outputfilename>"
	sys.exit(2)

lang=sys.argv[1]
opfile=open(sys.argv[2],"w")
opfile.write("Type,Sub type,Name,Who Added,When Added,Expiry Date,Reason\n")
processlist("User",ListManager.getlist(lang,'UserList'), editortype, opfile)
processlist("User",ListManager.getlist(lang,'UserListIP'), editortype, opfile)
processlist("Article",ListManager.getlist(lang,'ArticleList'), articletype, opfile)
processlist("Image",ListManager.getlist(lang,'ImageList'), imagetype, opfile)
opfile.close()


