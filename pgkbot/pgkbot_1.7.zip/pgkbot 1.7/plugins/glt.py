import CVUBot.RCPLists, shelve, re

class GreyListTWINKLE:

	TITLE = "Greylist users reverted by Whitelisted/Admin using TWINKLE"
	VERSION = 1
	PIVERSION = 2

	def __init__(self, lang, lists, reportEvent):
		self.reportEvent = reportEvent
		self.lang = lang
		self.lists = lists
		self.myconfig = shelve.open("plugins/Config/GLTWINKLE-%s.dbm" % lang,"c")
		if "gltwinkle_mins" not in self.myconfig:
			self.myconfig["gltwinkle_mins"] = "15"
			self.myconfig.sync()
		if "gltwinkle_regex" not in self.myconfig:
			self.myconfig["gltwinkle_regex"] = "Reverted.*?edits? by \[\[Special:Contributions\/(?P<user>.*?)\|.*?\]\].*?identified as .*?vandalism.*?TWINKLE"
			self.myconfig.sync()
		self.reTWINKLEmsg = re.compile(self.myconfig["gltwinkle_regex"])
		self.reIP = re.compile("^(\d{1,3}\.\d{1,3}.\d{1,3}.\d{1,3})$")
	
	def config(self, item, value=None):
		if item == "list":
			return "gltwinkle_mins = %s\ngltwinkle_regex = %s" % (self.myconfig["gltwinkle_mins"], self.myconfig["gltwinkle_regex"])
			
		if item == "gltwinkle_mins":

			if re.search("^\d{1,2}$", value) == None:
				return "Error in value must be 0 to 99"
			self.myconfig["gltwinkle_mins"] = value
			self.myconfig.sync()
			return "Config updated"

		elif item == "gltwinkle_regex":

			if re.search("\(\?P<user>", value) == None:
				return "Error regex doesn't contain a user group"
			try:
				x = re.compile(value)
			except re.error:
				return "Error not a valid python regex"
			self.myconfig["gltwinkle_regex"] = value
			self.reTWINKLEmsg = x

		else:
			return "Error, that isn't a config item for this plugin"

	def configitems(self):
		return ("gltwinkle_mins","gltwinkle_regex")

	def rcPriority(self):
		return set((50,)) # Just justafter the main bot processes
		
	def handleRCEvent(self, rcEvent, resultlist, priority):
		if not rcEvent.__class__.__name__  == "rcEdit": # not an edit
			return rcEvent
			
		editortype, editoritem = self.lists.classifyeditor(rcEvent.editor)

#		if priority == 49:   # Pre the main processing
#			if editortype in (CVUBot.RCPLists.c_whitelist, CVUBot.RCPLists.c_adminlist):   # Was it a rollback by a good user?
#				rcEvent.rbuser = None   # Fiddle pretend it wasn't a revert really
#			return rcEvent

		if editortype not in (CVUBot.RCPLists.c_whitelist, CVUBot.RCPLists.c_adminlist): # is the editor a good user?
			return rcEvent

		if eval(self.myconfig["gltwinkle_mins"]) == 0: # No time for greylisting
			return rcEvent
		res = self.reTWINKLEmsg.search(rcEvent.summary)


		if res == None:
			return rcEvent # Couldn't work it out

		try:
			revertededitor = res.group("user")

			editortype, editoritem = self.lists.classifyeditor(revertededitor)
			if editortype in (CVUBot.RCPLists.c_anon, CVUBot.RCPLists.c_normal, CVUBot.RCPLists.c_greylist):
				item = CVUBot.RCPLists.ListEntry(
						revertededitor.replace("_"," "),
						rcEvent.editor, 
						CVUBot.RCPLists.c_greylist,  
						"%s, vandalism rollback using TWINKLE on [[%s]]" % (rcEvent.editor, rcEvent.articlename),
						eval(self.myconfig["gltwinkle_mins"]), 
						60
						)
				if self.reIP.search(revertededitor):
					self.lists.ipgreylist[revertededitor] = item
				else:
					self.lists.greylist[revertededitor.replace(" ","_")] = item
		except:
			pass
		
		return rcEvent
