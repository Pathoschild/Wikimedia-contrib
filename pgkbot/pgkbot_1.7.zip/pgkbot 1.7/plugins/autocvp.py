import CVUBot.RCPLists, threading, urllib2, time, calendar, re

class AutomaticCVP:

	TITLE = "Auto CVP Frontpage for en wikipedia"
	VERSION = 1
	PIVERSION = 2

	def __init__(self, lang, lists, reportEvent):
		self.reportEvent = reportEvent
		self.lang = lang
		self.lists = lists
		self.threadstop = threading.Event()
		self.threadstop.clear()
		self.mainthread = ACVPThread(lists, self.threadstop)
		self.mainthread.setDaemon(True)
		self.mainthread.setName("Auto cvp frontpage for %s" % lang)
		self.mainthread.start()
		
	def status(self):
		if self.mainthread.isAlive():
			return "Auto CVP thread running"
		else:
			return "Auto CVP thread failed"
			
	def unload(self):
		try:
			self.threadstop.set() # signals any running threads to shutdown
			self.mainthread.join()
		except:
			pass
		

class ACVPThread(threading.Thread):
		
	def __init__(self, lists, stopevent):
		threading.Thread.__init__(self)
		self.lists = lists
		self.stopevent = stopevent
		
	def run(self):
		while not self.stopevent.isSet():

			# Process the dates and FA for today
			self.processToday()
			
			# Work out how long to wait so we get to the next 23:10 UTC
			basetime = time.time()
			currtime = list(time.gmtime(basetime))
			if currtime[3] >= 23:
				currtime = list(time.gmtime(basetime+86400)) # move to tomorrow
			
			currtime[3] = 23
			currtime[4] = 10
			newtime = calendar.timegm(currtime)
			# Sleep
			print "Waiting %s" % str(newtime-basetime)
			print "Which is %s" % time.strftime("%Y-%B-%d %HH:%MM:%SS",time.gmtime(newtime))
			self.stopevent.wait(newtime-basetime)
	
	def processToday(self):
			
		basetime = time.time()
		currtime = time.gmtime(basetime)

		if currtime[3] < 23:
			self.cvpFrontPage(basetime)
		else:
			self.cvpFrontPage(basetime+86400)

	def cvpFrontPage(self, basetime):
		# work out here what urls we need to check
		currmonth = time.strftime("%B",time.gmtime(basetime))
		currmonth2 = int(time.strftime("%m",time.gmtime(basetime))) 
		currday = int(time.strftime("%d",time.gmtime(basetime)))
		curryear = time.strftime("%Y",time.gmtime(basetime))
		print "%s %s %s" % (currmonth, currday, curryear)
		self.cvpURLLinks("http://en.wikipedia.org/w/index.php?title=Wikipedia:Today%%27s_featured_article/%s_%s%%2C_%s&action=raw" % (currmonth, currday, curryear))
		self.cvpURLLinks("http://en.wikipedia.org/w/index.php?title=Template:POTD_protected/%s-%02d-%02d&action=raw" % (curryear, currmonth2, currday))
		self.cvpURLLinks("http://en.wikipedia.org/w/index.php?title=Wikipedia:Selected_anniversaries/%s_%s&action=raw" % (currmonth, currday))
		# self.cvpURLLinks("http://en.wikipedia.org/w/index.php?title=Wikipedia:Recent_additions&action=raw") # Needs some filtering?
		
	def cvpURLLinks(self, url):
		req = urllib2.Request(url,headers={"user-agent":"pgkbot"})
		data = urllib2.urlopen(req)
		reWikilink = re.compile("\[\[(.*?)(\|.*?)?\]\]")
		
		for line in data:
			for match in reWikilink.finditer(line):
				articlename = match.group(1)
				articletype, item = self.lists.classifyarticle(articlename)
				if articletype == CVUBot.RCPLists.c_normalarticle:
					item = CVUBot.RCPLists.ListEntry(articlename.replace(" ","_"), "cvubot", CVUBot.RCPLists.c_watchlist, "Linked from main page" , 72, 3600)
					self.lists.articles[articlename.replace(" ","_")] = item
				else:
					exptime = item.expiry_time()
					if exptime != None:
						if time.time() + (72 * 3600) > exptime:
							item = CVUBot.RCPLists.ListEntry(articlename.replace(" ","_"), "cvubot", CVUBot.RCPLists.c_watchlist, "linked from main page" , 72, 3600)
							self.lists.articles[articlename.replace(" ","_")] = item







