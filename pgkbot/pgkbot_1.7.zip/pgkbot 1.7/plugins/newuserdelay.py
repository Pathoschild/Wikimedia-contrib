import CVUBot.RCPLists, shelve, re, time, CVUBot.ListManager, Queue, threading

class DelayLine:

	TITLE = "Delayed new user reporting/block suppression"
	VERSION = 1
	PIVERSION = 2
	
	def __init__(self, lang, lists, reportEvent):
		self.reportEvent = reportEvent
		self.lang = lang
		self.lists = lists
		self.myconfig = shelve.open("plugins/Config/DelayLine-%s.dbm" % lang,"c")
		if "dl_secs" not in self.myconfig:
			self.myconfig["dl_secs"] = "60"
			self.myconfig.sync()
		self.secs = int(self.myconfig["dl_secs"])
		# Normal supression of duplicate take effect
		self.newusers = CVUBot.ListManager.LMSimpleMemory(None, None) # User as a temporary store of new user details
		self.nuqueue = Queue.Queue(2000) # 2000 should be more than enough since the max delay is 999 seconds we need more than 2000 users created in that time
		self.threadstop = threading.Event()
		self.mainthread = processqueue(reportEvent, self.newusers, self.nuqueue, self.threadstop)
		self.mainthread.setDaemon(True)
		self.mainthread.setName("New user delay line for %s" % lang)
		self.mainthread.start()

	def unload(self):
		try:
			self.threadstop.set()
			self.mainthread.join()
		except:
			pass
		self.newusers.close()

	def status(self):
		if self.mainthread.isAlive():
			return "Delayed new user thread running, approx waiting %s" % self.nuqueue.qsize() 
		else:
			return "Delayed new user thread failed"

	def config(self, item, value=None):
		if item == "list":
			return "dl_secs = %s" % self.myconfig["dl_secs"]
			
		if item == "dl_secs":
			if re.search("^\d{1,3}$", value) == None:
				return "Error in value must be 0 to 999"
			self.myconfig["dl_secs"] = value
			self.myconfig.sync()
			self.secs = int(value)
			return "Config updated"
		else:
			return "Error, that isn't a config item for this plugin"

	def configitems(self):
		return ("dl_secs",)
		
	def events(self):
		return set(("dl_wwuser","dl_newuser","dl_block"))

	def rcPriority(self):
		return set((99,)) # As the final thing 
		
	def handleRCEvent(self, rcEvent, resultlist, priority):
		if rcEvent.__class__.__name__  not in ("rcBlockEditor","rcNewEditor"):
			return rcEvent

		# For blocks, if it's a block message and it's not in our new user list or it's not indefinite add dl_block as a type and remove
		if rcEvent.__class__.__name__  == "rcBlockEditor":
			if rcEvent.editor not in self.newusers or rcEvent.length.lower() not in ("indefinite","infinite"):
				for item in resultlist:
					if "block" in item[1]:
						item[1].add("dl_block")
			self.newusers.deleteitem(rcEvent.editor,None,None)
			return rcEvent # Pass it through regardless

		if rcEvent.__class__.__name__  == "rcNewEditor":
			se = storedevent()
			se.timestamp = time.time() + self.secs
			se.who = rcEvent.editor
			se.detail = []
			# Work through the result list so far, only interested in those messages of newuser or wwuser events.
			for item in resultlist:
				if "newuser" in item[1] or "wwuser" in item[1]:
					newitem = (item[0],set(item[1]))
					if "newuser" in item[1]:
						newitem[1].remove("newuser")
						newitem[1].add("dl_newuser")
					if "wwuser" in item[1]:
						newitem[1].remove("wwuser")
						newitem[1].add("dl_wwuser")
					se.detail.append(newitem)
			if len(se.detail) > 0:
				self.newusers[rcEvent.editor]=se
				try:
					self.nuqueue.put(se)
				except:
					self.newusers.deleteitem(rcEvent.editor,None,None)# Should only occur if the queue is full, in which case stop the list filling up...
		
		return rcEvent
		


class storedevent:
	pass
		
class processqueue(threading.Thread):
	
	def __init__(self, reportEvent, newusers, nuqueue, stopevent):
		self.reportEvent = reportEvent
		self.newusers = newusers
		self.nuqueue = nuqueue
		self.stopevent = stopevent
		threading.Thread.__init__(self)
	
	def run(self):
		while True:
			if self.stopevent.isSet(): # Shutting down
				break
			try:
				se = None
				se = self.nuqueue.get(True,2.0) # Give it two seconds at a time when the queue is empty
			except:
				pass
			if self.stopevent.isSet():
				break
			if se == None:
				continue
			waittime = se.timestamp - time.time() # Wait until we're ready
			if waittime > 0:
				self.stopevent.wait(waittime)
			if self.stopevent.isSet(): # Shutting down
				break
			if se.who not in self.newusers: # Already gone from the newusers list, must have been blocked
				continue	
			self.newusers.deleteitem(se.who,None,None) # Remove from the newusers list we're reporting now
			for item in se.detail:
				self.reportEvent(item[0],item[1])
