import Utils, ListManager, RCHandler, Version, ConfigParser, traceback, random
from RCEvents import *
import RCPLists

import sys, time, re, logging, logging.handlers
from string import Template


# Main class of interest, this gets the commands from the IRC Channel and
# processes them.  Receives the RCEvents and hands them onto the handler to deal with
#
class Processor:

	def __init__(self, lang):

		self.lang = lang
		
		self.logger = logging.getLogger("processor.%s" % lang)
		fh = logging.handlers.TimedRotatingFileHandler("Logs/%s/RCProcessor.log" % lang,"W0",2,26)
		fh.setFormatter(logging.Formatter("%(levelname)s %(asctime)s %(message)s"))
		self.logger.propogate = False
		self.logger.addHandler(fh)
		self.logger.setLevel(logging.DEBUG)
		self.logger.info("Processor for %s started" % lang)

		self.configitems = {
		"newbig"   : re.compile("^\d{1,6}$"),
		"newsmall" : re.compile("^\d{1,2}$"),
		"editbig"  : re.compile("^\d{1,6}$"),
		"editblank": re.compile("^-\d{1,6}$"),
		"blockconflict": re.compile("^\d{1,2}$"),
		"glonrollback": re.compile("^\d{1,2}$"),
		"gloncreateextraaccount": re.compile("^\d{1,2}$"),
		"glonbnu": re.compile("^\d{1,4}$"),
		"flagnewuser" : re.compile("\d{1,3}$"),
		"pseudonym": re.compile("^\w{0,10}$"),
		"startupquiet": re.compile("^(?:yes|no)$"),
		"bnubnasame" : re.compile("^(?:yes|no)$")
		}

		self.console = None
		self.reader = None
		self.firsteventtime = 0
		self.silent={}

		self.lasteventtime = time.time()
		self.lasteventtype = "Reset"

		self.help = Utils.readHelp(lang,Utils.readHelp('Base'))
		self.staticconfig=Utils.readConfig("Config/%s/StaticConfig" % self.lang)
		self.readMessages()
		
		self.remapCommands = {}
		self.readRemapCommands()

		self.Lists = RCPLists.Lists(lang, self.getMsg, self.staticconfig, self.remapCommands)
		self.RCHandler = RCHandler.StandardHandler(self.Lists,  lang, self.getMsg)

		self.routes = ListManager.getlist(lang,'Routes')
		self.stats = ListManager.getlist(lang,'Stats') # Probably a shelf to gather long term stats
		self.config = ListManager.getlist(lang,'Config')
		Utils.mergeConfig("Config/Default.conf", self.config, False)
	
		for channel in self.routes:
			self.silent[channel] = ((self.config["startupquiet"] == "yes"), time.time(), '')
		cc = self.staticconfig["controlchannel"]
		self.silent[cc]=((self.config["startupquiet"] == "yes"), time.time(),'')

	# The commands the bot accepts as a dictionary mapping to array of 
	# four values. 
	# 1st the method to process the msg.
	# 2nd the destination of the response. either "C" for channel, "P" for private, "N" for notice to users
	# 3rd the privilege level required to run either "" for none, "+" for voiced or "@" for op'd (^ = local control) 
	# 4th if this command should be accepted on channels without a "cmdsq" or "cmds" event

		self.botCommands = {
				"dest"    : [self.cmdDest, "C", "!",False],
				"help"    : [self.cmdHelp, "P", "",False],
				"nhelp"   : [self.cmdHelp, "N", "",False],
				"wl"      : [self.cmdWL, "C","+",False],
				"al"      : [self.cmdAL,"C","!",False],
				"bl"      : [self.cmdBL,"C","+",False],
				"gl"      : [self.cmdGL,"C","+",False],
				"fl"      : [self.cmdFL,"C","+",False],
				"acl"     : [self.cmdACL, "C", "+",False],
				"aclo"    : [self.cmdACLO,"C","@",False],
				"bot"     : [self.cmdBot,"C","!",False],
				"cvp"     : [self.cmdCVP,"C","+",False],
				"cvi"     : [self.cmdCVI,"C","+",False],
				"cnvp"    : [self.cmdCNVP,"C","@",False],
				"bnu"     : [self.cmdBNU,"C","+",False],
				"bna"     : [self.cmdBNA,"C","+",False],
				"wheels"  : [self.cmdWheels,"C","+",False],
				"config"  : [self.cmdConfig,"C","!",False],
				"intel"   : [self.cmdBCL, "C", "",False],
				"aintel"  : [self.cmdAIntel, "C", "",False],
				"iintel"  : [self.cmdIIntel, "C", "",False],
				"quiet"   : [self.cmdQuiet,"C","+",True],
				"speak"   : [self.cmdSpeak,"C","+",True],
				"shutdown": [self.cmdShutdown,"C","@",False],
				"reader"  : [self.cmdReader,"C","!",False],
				"status"  : [self.cmdStatus,"C","",True],
				"quietall": [self.cmdQuietAll,"C","!",False],
				"info"    : [self.cmdInfo,"C","",True],
				"stats"   : [self.cmdStats,"C","",False],
				"plugin"  : [self.cmdPlugin,"C","@",False],
				"ipcat"   : [self.cmdIPCAT,"C","+",False],
				"ip"      : [self.cmdIP,"C","",True]
				}
		
		self.plugins = {}
		self.pibefore = []
		self.piafter = []

		self.build_plugins()
		self.shuttingdown = False
		
	def unload(self):
		self.shuttingdown = True

		con = self.console
		if con != None:
			for channel in self.routes:
				if channel.startswith('#'):
					con.leave(channel,self,"unloading")
			con.leave(self.staticconfig['controlchannel'],self,"unloading")

		self.logger.info("Processor for %s unloading" % self.lang)
		self.Lists.unload()
		self.RCHandler.unload()
		for piclass, plugin in self.plugins.iteritems():
			if hasattr(plugin,"unload"):
				try:
					plugin.unload()
				except:
					print "Problems in unload of %s" % piclass
					traceback.print_exc()
		self.plugins = None
		
	def build_plugins(self):
		
		for key, item in self.staticconfig.iteritems():
			if not key.startswith("plugin_"):
				continue
			error = self.pi_load(item)
			if error != None:
				self.logger.info(error)
		
		self.pi_priorities()
			
	def pi_load(self, classname, reloadmod=False):
		parts = classname.rsplit(".",1) # split into the module and class
		mod = self.pi_import(parts[0]) 
		if mod == None:
			return "Couldn't load plugin %s " % classname 
		if reloadmod:
			reload(mod)
		cls = getattr(mod, parts[1], None)
		if cls == None:
			return "No class in plugin %s " % classname
		try: 
			plugin = cls(self.lang, self.Lists, self.reportEvent)
		except:
			print "Problems instancing plugin %s" % classname
			traceback.print_exc()
			return "Couldn't instance plugin %s" % classname
		ver = getattr(cls,"PIVERSION", None)
		if ver == None:
			return "Doesn't look like a valid plugin %s " % classname
		if ver not in  (2,3):
			return "Plugin version not supported %s " % classname 
		
		self.plugins[classname]=plugin
		return None
			
	def pi_import(self, name):
		try:
			mod = __import__(name)
			components = name.split('.')
			for comp in components[1:]:
				mod = getattr(mod, comp)
		except:
			print "Trouble loading plugin %s" % name
			traceback.print_exc()
			mod = None
		return mod
		
	def pi_priorities(self):
		piordered_build = {}
		for classname, plugin in self.plugins.iteritems():
			try:
				if hasattr(plugin,"rcPriority") and hasattr(plugin,"handleRCEvent"):
					for priority in plugin.rcPriority():
						if priority in piordered_build:
							piordered_build[priority].add(classname)
						else:
							piordered_build[priority]=set((classname,))
			except:
				print "Problems computing plugin priorities for %s" % classname
				traceback.print_exc()

		pibefore_build = []
		for i in range(0,50):
			if i in piordered_build:
				for item in piordered_build[i]:
					pibefore_build.append((item,i))
		piafter_build = []
		for i in range(50,100):
			if i in piordered_build:
				for item in piordered_build[i]:
					piafter_build.append((item,i))

		self.pibefore = pibefore_build
		self.piafter = piafter_build
	
	def readRemapCommands(self):
		commands = ConfigParser.SafeConfigParser()
		commands.read("Config/%s/Commands.ini" % self.lang)

		for section in commands.sections():
			print section
			newmap={}
			for cmd in commands.items(section):
				newmap[cmd[0]]=cmd[1]
			self.remapCommands[section]=newmap
		
	def readMessages(self):
		msgs = Utils.readConfig("Config/%s/Console.msgs" % self.lang, Utils.readConfig("Config/Base/Console.msgs"));
		bu = self.staticconfig["baseurl"]
		pr = self.staticconfig["prefixwikilinks"]

		for msgno, msg in msgs.iteritems():
			msg = msg.replace("${baseurl}",bu).replace("[[","[[%s" % pr).replace("%c","\x03").replace("%o","\x0f").replace("%b","\x02").replace("%u","\x1f")
			msgs[msgno] = Template(msg)
		self.msgs = msgs

	def getMsg(self, msgno, dict={}):
		if "%05u" % msgno not in self.msgs:
			return "Message %05u missing from message file" % msgno
		return self.msgs["%05u" % msgno].substitute(dict)

	def setConsole(self, console):
		if not self.shuttingdown:
			console.join(self.staticconfig['controlchannel'],self)
			for channel in self.routes:
				if channel.startswith('#'):
					console.join(channel,self)
			self.console = console

	def delConsole(self):
		if not self.shuttingdown:
			self.console = None

	def setReader(self, reader):
		self.reader = reader

	def delReader(self):
		self.reader = None


#*****************First Part - Deals with IRC Commands *************************
#*******************************************************************************

	def cmdShutdown(self, source, subcommand, data, user, channel):
		self.logger.info("Shutdown initiated by %s on %s" % (user, channel))
		source.shutdown()
		return ""
		
	def cmdInfo(self, source, subcommand, data, user, channel):
		msg = self.getMsg(90,{"owner":self.console.getowner(), "version": "%2.2f" % Version.VERSION})
		for plugin in self.plugins.itervalues():
			msg = msg + "\n"+self.getMsg(92,{"pititle":plugin.TITLE, "piversion": "%2.2f" % plugin.VERSION})
		return msg
	
	def cmdSpeak(self, source, subcommand, data, user, channel):
		if self.silent[channel][0]:
			self.silent[channel]=(False, time.time(), user)
			return self.getMsg(5)
		
		return ""

	def cmdQuietAll(self, source, subcommand, data, user, channel):
		reason = "%s %s" % (subcommand, data)
		msg = self.getMsg(80,{"user":user, "channel": channel, "reason": reason})
		for channel2, value in self.silent.iteritems():
			if not value[0]:
				self.silent[channel2] = (True, time.time(), user)
				if channel != channel2:
					source.msg(channel2, msg)
		return self.getMsg(81)

	def cmdQuiet(self, source, subcommand, data, user, channel):
		if not self.silent[channel][0]:
			self.silent[channel]=(True, time.time(), user)
			return self.getMsg(7)
		return ""

	def cmdStatus(self, source, subcommand, data, user, channel):
		pilines=""
		for piclass, plugin in self.plugins.iteritems():
			if hasattr(plugin,"status"):
				try:
					pistat = plugin.status()
				except:
					print "Failure in status request for plugin %s " % piclass
					traceback.print_exc()
					pistat = None
				if pistat != None:
					pilines = pilines + "\n" + pistat

		if self.reader == None:
				return self.getMsg(41) + pilines
		else:
			lasttime = "%.2f" % (time.time() - self.lasteventtime)
			lasttype = self.lasteventtype
			msg = self.getMsg(42,{"lastrcevent": lasttime, "lastrceventtype" : lasttype})

		sildets = self.silent[channel]
		if sildets[0]:
			msgno = 43
		else:
			msgno = 44
		msg = self.getMsg(msgno, {"silentwho":sildets[2], "silentwhen":time.strftime("%H:%M:%S %d-%b-%Y UTC", time.gmtime(sildets[1]))}) + " : " + msg
		return msg + pilines
		
	def cmdPlugin(self, source, subcommand, data, user, channel):
		subcommand = subcommand.lower()
		subcommand2 = self.remapCommands["plugin"].get(subcommand,subcommand)
		
		if subcommand2 == "list":
			msg = self.getMsg(300)
			for classname, plugin in self.plugins.iteritems():
				msg = msg + "\n" + "%s : %s" % (classname, self.getMsg(92,{"pititle":plugin.TITLE, "piversion": "%2.2f" % plugin.VERSION}))
			return msg
		
		if subcommand2 == "unload":
			if data not in self.plugins:
				return self.getMsg(302)
			msgno=305
			try:
				if hasattr(self.plugins[data],"unload"):
					self.plugins[data].unload()
				del self.plugins[data]
				self.pi_priorities()
			except:
				print "Trouble unloading plugin %s " % data
				traceback.print_exc()
				msgno=308
			return self.getMsg(msgno)

		if subcommand2 == "reload":
			if data not in self.plugins:
				return self.getMsg(301)
			msgno=304
			try:
				if hasattr(self.plugins[data],"unload"):
					self.plugins[data].unload()
				del self.plugins[data]
				error = self.pi_load(data, reloadmod=True)
				self.pi_priorities()
				if error != None:
					return self.getMsg(303,{"detail": error})
			except:
				print "Trouble reloading plugin %s " % data
				traceback.print_exc()
				msgno=309
			return self.getMsg(msgno)

		if subcommand2 == "load":
			if data in self.plugins:
				return self.getMsg(307)
			error = self.pi_load(data, reloadmod=True)
			if error != None:
				return self.getMsg(303,{"detail": error})
			self.pi_priorities()
			return self.getMsg(306)
		
		return self.getMsg(2,{"command":subcommand})

	def cmdReader(self, source, subcommand, data, user, channel):
		subcommand = subcommand.lower()
		subcommand2 = self.remapCommands["reader"].get(subcommand,subcommand)
		if subcommand2 == "reset" and self.reader != None:
			self.reader.reset()
			self.lasteventtime = time.time()
			self.lasteventtype = "Reset"
			self.firsteventtime = 0
			return self.getMsg(40)
		if subcommand2 == "reset":
			return self.getMsg(41)
		if subcommand2 == "status":
			if self.reader == None:
				return self.getMsg(41)
			else:
				lasttime = str(time.time() - self.lasteventtime)
				lasttype = self.lasteventtype
				return self.getMsg(42,{"lastrcevent": lasttime, "lastrceventtype" : lasttype})
		return getMsg(2,{"command": subcommand})
			
	def cmdStats(self, source, subcommand, data, user, channel):
		subcommand = subcommand.lower()
		subcommand2 = self.remapCommands["stats"].get(subcommand,subcommand)

		if subcommand2 == "full":
			return self.fullstats()
			
		endtime = long(time.time())
		begtime = endtime-3600
		total = self.stats["total"]
		msg = self.getMsg(200,
			{"total":total.get("total",0),
			 "totale":total.get("rcEdit",0)+total.get("rcNew",0),
			 "totalb":total.get("rcBlockEditor",0),
			 "totald":total.get("rcDelArticle",0),
			 "totalu":total.get("rcNewEditor",0)})
		
		if self.firsteventtime == 0 or time.time() < self.firsteventtime + 3600:
			msg = msg + "\n" + self.getMsg(203)
			return msg
		
		runtot = {}
		for mintime in range(int(begtime), int(endtime), 60):
			mintotal = self.stats.get(time.strftime("%Y%m%d%H%M",time.gmtime(mintime)),{})
			for key in mintotal:
				runtot[key]=runtot.get(key,0)+mintotal[key]
		
		msg = msg + "\n" + self.getMsg(201,
			{"total":runtot.get("total",0),
			 "totale":runtot.get("rcEdit",0)+runtot.get("rcNew",0),
			 "totalb":runtot.get("rcBlockEditor",0),
			 "totald":runtot.get("rcDelArticle",0),
			 "totalu":runtot.get("rcNewEditor",0)})
		
		msg = msg + "\n" + self.getMsg(202,
			{"total":runtot.get("total",0)/60,
			 "totale":(runtot.get("rcEdit",0)+runtot.get("rcNew",0))/60,
			 "totalb":runtot.get("rcBlock",0)/60,
			 "totald":runtot.get("rcDelArticle",0)/60,
			 "totalu":runtot.get("rcNewEditor",0)/60})
		
		return msg
		
	def fullstats(self):
		endtime = time.time()
		begtime = endtime-3600
		msg = self.getMsg(210) + self.statsbreakdown(self.stats.get("total",{}),1)
		
		if self.firsteventtime == 0 or time.time() < self.firsteventtime + 3600:
			msg = msg + "\n" + self.getMsg(203)
			return msg
		
		runtot = {}
		for mintime in range(begtime, endtime, 60):
			mintotal = self.stats.get(time.strftime("%Y%m%d%H%M",time.gmtime(mintime)),{})
			for key in mintotal:
				runtot[key]=runtot.get(key,0)+mintotal[key]

		msg = msg + "\n" + self.getMsg(211) + self.statsbreakdown(runtot)
		msg = msg + "\n" + self.getMsg(212) + self.statsbreakdown(runtot,60)

		return msg
		
	def statsbreakdown(self, map, divisor=1):
		if len(map) == 0:
			return "\n" + self.getMsg(214)
		retval = ""
		for event in sorted(map.keys()):
			retval = retval +"\n" + self.getMsg(213,{"event":event,"number":map.get(event,0)/divisor})
		return retval
		
	def cmdIP(self, source, subcommand, data, user, channel):
		item = self.Lists.getipcat(" ".join((subcommand, data)))
		if item == None:
			return self.getMsg(500)
		else:
			return self.getMsg(501,item)

	def cmdIPCAT(self, source, subcommand, data, user, channel):
			return self.Lists.updateList(RCPLists.c_ipcats, 0, subcommand, data, user)

	def cmdWL(self, source, subcommand, data, user, channel):
			return self.Lists.updateList(RCPLists.c_editorlist, RCPLists.c_whitelist, subcommand, data, user)

	def cmdBL(self, source, subcommand, data, user, channel):
			return self.Lists.updateList(RCPLists.c_editorlist, RCPLists.c_blacklist, subcommand, data, user)

	def cmdAL(self, source, subcommand, data, user, channel):
			return self.Lists.updateList(RCPLists.c_editorlist, RCPLists.c_adminlist, subcommand, data, user)

	def cmdGL(self, source, subcommand, data, user, channel):
			return self.Lists.updateList(RCPLists.c_grey, RCPLists.c_greylist, subcommand, data, user)

	def cmdFL(self, source, subcommand, data, user, channel):
			return self.Lists.updateList(RCPLists.c_flag, RCPLists.c_flagged, subcommand, data, user)

	def cmdBot(self, source, subcommand, data, user, channel):
			return self.Lists.updateList(RCPLists.c_editorlist, RCPLists.c_bot, subcommand, data, user)

	def cmdACL(self, source, subcommand, data, user, channel):
			return self.Lists.updateList(RCPLists.c_acl, 0, subcommand, data, user)
			
	def cmdACLO(self, source, subcommand, data, user, channel):
			return self.Lists.updateList(RCPLists.c_aclo, 0, subcommand, data, user)

	def cmdCVI(self, source, subcommand, data, user, channel):
		return self.Lists.updateList(RCPLists.c_imagelist, RCPLists.c_img_watchlist, subcommand, data, user)

	def cmdCVP(self, source, subcommand, data, user, channel):
		return self.Lists.updateList(RCPLists.c_articlelist, RCPLists.c_watchlist, subcommand, data, user)

	def cmdCNVP(self, source, subcommand, data, user, channel):
		return self.Lists.updateList(RCPLists.c_articlelist, RCPLists.c_ignorelist, subcommand, data, user)

	def cmdBNU(self, source, subcommand, data, user, channel):
		return self.Lists.updateList(RCPLists.c_watchwords, 0, subcommand, data, user)

	def cmdBNA(self, source, subcommand, data, user, channel):
		if self.config["bnubnasame"] == "yes":
			return self.Lists.updateList(RCPLists.c_watchwords, 0, subcommand, data, user)
		else:
			return self.Lists.updateList(RCPLists.c_bna, 0, subcommand, data, user)

	def cmdWheels(self, source, subcommand, data, user, channel):
		return self.Lists.updateList(RCPLists.c_wheelerwords, 0, subcommand, data, user)

	def cmdDest(self, source, subcommand, data, user, channel):
		subcommand = subcommand.lower()
		subcommand2 = self.remapCommands["dest"].get(subcommand,subcommand)
		
		if subcommand2 == "list":
			space = " "
			tempchans=[]
			temppres=[]
			for channel in sorted(self.routes.keys()):
				if channel[0] == '#':
					tempchans.append(channel)
				else:
					temppres.append(channel)
			if len(tempchans) != 0:
				output = self.getMsg(110) 
				for channel in tempchans:
					output=output+"\n"+self.getMsg(114,{"channel":channel, "events": space.join(sorted(self.routes[channel]))})
			else:
				output = self.getMsg(112)

			if len(temppres) != 0:
				output = output + "\n" +self.getMsg(111) 
				for channel in temppres:
					output=output+"\n"+self.getMsg(114,{"channel":channel, "events": space.join(sorted(self.routes[channel]))})
			else:
				output = output + "\n" +self.getMsg(113)
			
			return output

		if subcommand2 == "swap":
			channels = data.split()
			if len(channels) != 2:
				return self.getMsg(11)
			channel1 = channels[0]
			channel2 = channels[1]
			if channel1.startswith("!") or channel2.startswith("!"):
				return self.getMsg(11)
			if not channel1.startswith("#"):
				channel1 = "#"+channel1
			if not channel2.startswith("#"):
				channel2 = "#"+channel2
			
			if channel1 not in self.routes and channel2 not in self.routes:
				return self.getMsg(19)
			
			routes2 = None
			
			routes1 = self.routes.pop(channel1,None)
			routes2 = self.routes.pop(channel2,None)

			if routes1 != None:
				self.routes[channel2] = routes1
				if routes2 == None:
					self.console.join(channel2,self)
					self.silent[channel2]=((self.config["startupquiet"] == "yes"),time.time(),user)
			else:
				if routes2 != None:
					source.leave(channel2,self, "swapped with %s" % channel1)
					if channel2 != self.staticconfig["controlchannel"]:
						del self.silent[channel2]
			
			if routes2 != None:
				self.routes[channel1] = routes2
				if routes1 == None:
					self.console.join(channel1,self)
					self.silent[channel1]=((self.config["startupquiet"] == "yes"),time.time(),user)
			else:
				if routes1 != None:
					source.leave(channel1,self,"swapped with %s" % channel2)
					if channel1 != self.staticconfig["controlchannel"]:
						del self.silent[channel1]

			return self.getMsg(28, {"channel1" : channel1, "channel2" : channel2})
		
		if subcommand2 not in ("add","del","set"):
			return self.getMsg(2,{"command":subcommand})

		words = data.split()
		channel = words[0]
		if not (channel.startswith("#") or channel.startswith("!")):
			channel = "#"+channel
		events = words[1:]
			
		if subcommand2 == "set":
			if len(events) != 1:
				return self.getMsg(4,{"command" : "dest set"})
			if events[0] not in self.routes:
				return self.getMsg(27,{"channel1":channel, "channel2": events[0]})
			if channel.startswith("#") and channel not in self.routes:
				self.console.join(channel,self)
				self.silent[channel]=((self.config["startupquiet"] == "yes"), time.time(), user)
			self.routes[channel]=set(self.routes[events[0]])
			return self.getMsg(29,{"channel1":channel, "channel2": events[0]})
		
		badevents = set()
		badstr = ""
		okevents = set()
		okstr = ""
		if subcommand2 == 'add':
			for eventtype in events:
				if eventtype not in self.RCHandler.allevents:
						for piclass, plugin in self.plugins.iteritems():
							if hasattr(plugin,"events"):
								try:
									if eventtype in plugin.events():
										okevents.add(eventtype)
										break
								except:
									print "Trouble processing events for plugin %s" % piclass
									traceback.print_exc()
						else:
							badevents.add(eventtype)
				else:
					okevents.add(eventtype)
		else:
			okevents = events
			
		badstr = " ".join(sorted(badevents))
		okstr = " ".join(sorted(okevents))

		if len(okevents) == 0:
			return self.getMsg(10,{"events":badstr})
			
		if subcommand2 == "add":
			if channel in self.routes:
				self.routes[channel]=self.routes[channel].union(okevents)
			else:
				self.routes[channel]=okevents
				if channel.startswith("#"):
					self.console.join(channel,self)
					self.silent[channel]=((self.config["startupquiet"] == "yes"), time.time(), user)
			return self.getMsg(6,{"events":okstr, "channel":channel})
		
		if subcommand2 == "del":
			if channel in self.routes:
				self.routes[channel]=self.routes[channel].difference(okevents)
				if len(self.routes[channel]) == 0:
					if channel.startswith("#"):
						source.leave(channel, self, "No longer needed")
						if channel != self.staticconfig["controlchannel"]:
							del self.silent[channel]
					del self.routes[channel]
			return self.getMsg(8,{"events":okstr, "channel":channel})

	def cmdConfig(self, source, subcommand, data, user, channel):

		subcommand = subcommand.lower()
		subcommand2 = self.remapCommands["config"].get(subcommand,subcommand)

		if subcommand2 == "list":
			msg = self.getMsg(13)
			for item, value in self.config.iteritems():
				msg = msg +"\n%s = %s" % (item, value)
			for piclass, plugin in self.plugins.iteritems():
				if hasattr(plugin,"config"):
					try:
						resp = plugin.config("list")
						if resp != None:
							msg = msg + "\n" + resp
					except:
						print "Trouble getting config from plugin %s" % piclass
						traceback.print_exc()
			return msg
		if subcommand == "unkick":
			if not data.startswith('#'):
				data="#"+data
			if self.console.unkick(data, user):
				return self.getMsg(70,{"channel":data})
			else:
				return self.getMsg(71,{"channel":data})
		
		if subcommand2 == "readmsgs":
			self.readMessages()
			return self.getMsg(0)
			
		if subcommand2 == "readcmds":
			self.readRemapCommands()
			return self.getMsg(17)
			
		if subcommand2 == "getadmins":
			self.Lists.getEditors(user, RCPLists.c_adminlist, self.staticconfig["baseurl"] + "/w/index.php?title=Special:Listusers&limit=2000&offset=0&group=sysop")
			return self.getMsg(91)

		if subcommand2 == "getbots":
			self.Lists.getEditors(user, RCPLists.c_bot, self.staticconfig["baseurl"] + "/w/index.php?title=Special:Listusers&limit=2000&offset=0&group=bot")
			return self.getMsg(91)
		
		if subcommand not in self.configitems:
			for piclass, plugin in self.plugins.iteritems():
				if hasattr(plugin,"configitems") and hasattr(plugin,"config"):
					try:
						if subcommand in plugin.configitems():
							return plugin.config(subcommand, data)
					except:
						print "Trouble passing config command to plugin %s" % piclass
						traceback.print_exc()
			return self.getMsg(14,{"configname":subcommand})

		checkformat = self.configitems[subcommand].search(data.strip())
		if checkformat == None:
			return self.getMsg(15,{"configname": subcommand, "configvalue": data})
		self.config[subcommand]=data.strip()
		return self.getMsg(16,{"configname": subcommand, "configvalue": data})

	def cmdBCL(self, source, subcommand, data, user, channel):
		ed = (subcommand + " " + data).strip() # .replace(" ","_")
		if self.staticconfig["user_initcap"].lower().startswith("y"):
			ed = ed[0].upper() + ed[1:]

		flagitem, glitem, olitem, ip, iprange, ipcat = self.Lists.classifyeditorall(ed)

		msg = ""
		if glitem != None:
			msg = self.getMsg(10000+(glitem.type*100)+22, glitem)
		if olitem != None:
			msg = msg + "\n" + self.getMsg(10000+(olitem.type*100)+22, olitem)
		if flagitem != None:
			msg = msg+"\n"+self.getMsg(10822, flagitem)

		if not (flagitem or olitem or glitem):
			edtype = RCPLists.c_normal
			if ip: edtype = RCPLists.c_anon
			if iprange: edtype = RCPLists.c_iprange
			msg = self.getMsg(20+edtype-RCPLists.c_anon,{"editor":ed})

		if ipcat:
			msg = msg + "\n" + self.getMsg(20022,ipcat)
			
		return (msg + "\n" + self.getMsg(30,{"editor":ed})).strip()

	def cmdAIntel(self, source, subcommand, data, user, channel):
		art = (subcommand + " " + data).strip()
		if self.staticconfig["article_initcap"].lower().startswith("y"):
			art = art[0].upper() + art[1:]
		articletype, artitem = self.Lists.classifyarticle(art)
		if articletype in (RCPLists.c_watchlist, RCPLists.c_ignorelist):
			msg = self.getMsg(11000+(artitem.type*100)+22, artitem)
		else:
			msg = self.getMsg(35,{"article": art})
		return msg

	def cmdIIntel(self, source, subcommand, data, user, channel):
		img = (subcommand + " " + data).strip()
		imagetype, imgitem = self.Lists.classifyimage(img)
		if imagetype == RCPLists.c_img_watchlist:
			msg = self.getMsg(15000+(imgitem.type*100)+22, imgitem)
		else:
			msg = self.getMsg(36,{"image": img})
		return msg

	def cmdHelp(self, source, subcommand, data, user, channel):
		if subcommand in self.help:
			return self.help[subcommand]

		for piclass, plugin in self.plugins.iteritems():
			if hasattr(plugin,"helpitems") and hasattr(plugin,"help"):
				try:
					if subcommand in plugin.helpitems(): 
						return plugin.help(subcommand)
				except:
						print "Trouble getting help from plugin %s" % piclass
						traceback.print_exc()

		return self.getMsg(3,{"command":subcommand})

# Does the basic command processing, uses botCommands to route to the right
# method and takes the response and routes to the right destination.

	def processMessage(self, source, channel, user, msg, usermode, identified):
		if self.shuttingdown:  # in process of unloading, don't bother
			return

		origmsg = msg
		if usermode != "^":
			pseudonym = self.config["pseudonym"]
			if pseudonym == "":
				pseudonym = source.nickname
		
			checknick = re.search("^(%s|%s)(?: |:|>)(.*)" % (source.nickname, pseudonym),msg,re.I)
			if checknick == None:
				return
	
			self.logger.info("Got a message on %s by <%s> \"%s\"" % (channel, user, msg))

			if checknick.group(1).lower() == source.nickname.lower():
				usednick = True
			else:
				usednick = False
		
			msg = checknick.group(2)

			if usednick or not self.silent[channel][0]:
				reply=True
			else:
				reply=False

			fullcommands=False # Only accept a subset of commands in this channel
			eventset = self.routes.get(channel,set())
			if channel == self.staticconfig["controlchannel"] or len(eventset.intersection(("cmds","cmdsq"))) > 0:
				fullcommands=True # Accept all commands
				
			if (not usednick) and (not channel == self.staticconfig['controlchannel']) and "cmdsq" in eventset:
					reply=False # only listening for commands in this channel, say nothing
					
		else:
			self.logger.info("Got a local message \"%s\"" % msg)
			usednick = True
			reply = True
			fullcommands = True


		try:
			(command, subcommand, data) = msg.split(None,2)
		except ValueError:
			data = ""
			try: 
				(command, subcommand) = msg.split(None,1)
			except ValueError:
				command = msg
				subcommand = ""
				
		command2=self.remapCommands["main commands"].get(command.lower(), command.lower())
	
		commandAction = None	
		for piclass, plugin in self.plugins.iteritems():
			if hasattr(plugin,"commands"):
				try:
					commandAction = plugin.commands().get(command2, None)
					if commandAction != None:
						break
				except:
					print "Trouble getting commands from plugin %s" % piclass
					traceback.print_exc()
					
		if commandAction == None:
			commandAction = self.botCommands.get(command2)

		if commandAction == None:
			if reply and fullcommands:
				source.notice(user,self.getMsg(2,{"command":msg})) 
			return

		if usermode == "" or usermode == None:
			aclentry = self.Lists.acl.get(user.lower())
			usermode=""

			if aclentry != None:
				usermode="+"
		
		if usermode not in  "@^" and identified and user.lower() in self.Lists.aclo:
			usermode = "!"
					
		self.logger.info("user has mode <%s> " % (usermode))

		# Check we are interested in all commands on this channel or it's a command we are interested in 
		if not (commandAction[3] or fullcommands):
			self.logger.info("Not processing not fullcommands")
			return

		if commandAction[2] == "+" and usermode == "":
			self.logger.info("Not processing command requires voice")
			if reply:
				source.notice(user,self.getMsg(120))
			return
			
		if commandAction[2] == "!" and usermode in ("", "+"):
			if identified == None and user in self.Lists.aclo:
				self.logger.info("Checking if user identitified")
				source.checkIdentified(user, channel, origmsg, self)
				return
			self.logger.info("Not processing command requires bot operator")
			if user in self.Lists.aclo and reply:
				source.notice(user,self.getMsg(129))
				return
			if reply:
				source.notice(user,self.getMsg(121))
			return
		
		if commandAction[2] == "@" and usermode not in  "@^":
			self.logger.info("Not processing command requires ops")
			if reply:
				source.notice(user,self.getMsg(122))
			return
			
		if commandAction[2] == "^" and usermode != "^":
			self.logger.info("Not processing command requires console")
			return

		
		response = commandAction[0](source, subcommand, data, user, channel)
		if not reply and not command.lower() == 'speak':  # Check silent in case is was the speak command
			return
	
		if commandAction[1] == "N":
			for line in response.splitlines():
				source.notice(user,line)
		elif commandAction[1] == "P":
			for line in response.splitlines():
				source.msg(user, line)
		else:
			return response


	def processMe(self, source, channel, user, data):
		
		if "mefactor" not in self.staticconfig:
			return
		res = re.search("(?:^|\s)(?P<act>slaps|kicks|punches|hits|boots|kisses|hugs|stabs)\s",data,re.I)
		if res == None:
			return
		num = int (random.random()*int(self.staticconfig["mefactor"]))
		if num == 1:
			num = int (random.random()*10)
			if num < 3:
				source.me(channel,"Helps %s" % user)
			else:
				source.me(channel,"%s %s" % (res.group("act"),user))


#*****************Second Part - Deals with RC Events *************************
#*****************************************************************************
	
	# Called by the Handler to report the results of its dealing with the revents
	def reportEvent(self, msg, classes, overridequiet=False):
		
		if self.console == None:
			return
			
		destlist=set()

		for channel, routes in self.routes.iteritems():
			if channel.startswith("!"):
				continue
			if self.silent[channel][0] and not overridequiet:
				continue
			skipit=False
			for check in (("-white","white"),("-admin","admin"),("-bot","bot")):
				if check[0] in routes and check[1] in classes:
					skipit=True
			if skipit:
				continue
			if len(routes.intersection(classes)) > 0:
				destlist.add(channel)
					
		if self.console == None or len(destlist) == 0:
			return
		else:
			self.console.multimsg(destlist, msg)
			

	def doRCEvent(self, rcevent):
		if self.shuttingdown:  # in process of unloading, don't bother
			return
			
	# Update the stats
		self.lasteventtime = time.time()
		if self.firsteventtime == 0:
			self.firsteventtime = self.lasteventtime
		
		cname = rcevent.__class__.__name__
		self.lasteventtype = cname
		
		thetime = time.strftime("%Y%m%d%H%M",time.gmtime(self.lasteventtime))
		if thetime not in self.stats:
			self.stats[thetime]={}

		timestats=self.stats[thetime]
		timestats[self.lasteventtype]=timestats.get(self.lasteventtype,0)+1
		timestats["total"]=timestats.get("total",0)+1
		self.stats[thetime]=timestats

		if "total" not in self.stats:
			self.stats["total"]={}

		timestats=self.stats["total"]

		timestats[self.lasteventtype]=timestats.get(self.lasteventtype,0)+1
		timestats["total"]=timestats.get("total",0)+1

		self.stats["total"]=timestats
		
		resultlist = []

		rcevent = self.pi_doevent(self.pibefore, rcevent, resultlist)
		
		if rcevent != None:
			# Let our main handler now have a bash
			self.RCHandler.handleRCEvent(rcevent, resultlist)
			# Finally the post main handler routines
			rcevent = self.pi_doevent(self.piafter, rcevent, resultlist)

		# Now report the results
		for res in resultlist:
			self.reportEvent(res[0],res[1])

	def pi_doevent(self, pilist, rcevent, resultlist):
		for item in pilist:
			plugin = self.plugins.get(item[0], None)
			if plugin != None:
				try:
					rcevent = plugin.handleRCEvent(rcevent, resultlist, item[1])
					if rcevent == None:
						break
				except:
					print "Problem processing event by plugin %s" % item[0]
					traceback.print_exc()
		return rcevent
