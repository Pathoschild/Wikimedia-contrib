import urllib2, bz2

class bz2url:
	
	def __init__(self, url):
		self.buffoff = 0
		self.buffer = ""
		self.data = urllib2.urlopen(url)
		self.decomp = bz2.BZ2Decompressor( ) 
		self.eof = False
		self.closed = False
	
	def close(self):
		self.closed = True
	
	def read(self, size=-1):
		if self.closed:
			raise ValueError
			
		if self.buffoff == len(self.buffer):
			self.buffoff = 0
			self.buffer = ""
			if self.eof:
				return ""
			
		if (len(self.buffer)-self.buffoff) < size:
			sizex = 32768 * 8
			if sizex < size:
				sizex = size
			self.decompress(sizex)
		if size == -1:
			sizex = 0 
			while not self.eof:
				sizex = sizex + (37268 * 8)
				self.decompress(sizex)	
		if (len(self.buffer)-self.buffoff) <= size:
			temp = self.buffoff
			self.buffoff=len(self.buffer)
			return self.buffer[temp:] 
		else:
			temp = self.buffoff
			self.buffoff = temp+size 
			return self.buffer[temp:self.buffoff] 

	def next(self):
		line = self.readline()
		if line == "":
			raise StopIteration
		return line

	def readline(self, size=-1):
		if self.closed:
			raise ValueError

		readsize = len(self.buffer) - self.buffoff
		if readsize == 0:
			self.buffoff = 0
			self.buffer = ""
		while True:
			if len(self.buffer) == self.buffoff and self.eof:
				return ""
			x = self.buffer.find("\n", self.buffoff) - self.buffoff
			
			if x <=-1 and size != -1 and size <= (len(self.buffer) - self.buffoff):
				temp = self.buffoff
				self.buffoff = temp + size
				return self.buffer[temp:self.buffoff] 
				
			if x > -1  and (x < size or size == -1):
				temp = self.buffoff
				self.buffoff = temp+x+1
				return self.buffer[temp:self.buffoff] 
					
			if self.eof:
				temp = self.buffoff
				self.buffoff=len(self.buffer)
				return self.buffer[temp:] 

			readsize=readsize+(32768*8)
			self.decompress(readsize)
	
	def decompress(self,size):
		if self.buffoff != 0:
			self.buffer = self.buffer[self.buffoff:]
			self.buffoff = 0
		while len(self.buffer) < size or size == -1:
			temp = self.data.read(32768*4)
			if temp == "":
				self.eof=True
				break
			try:
				self.buffer = "".join((self.buffer,self.decomp.decompress(temp)))
			except bz2.EOFError:
				self.eof = True
				break
