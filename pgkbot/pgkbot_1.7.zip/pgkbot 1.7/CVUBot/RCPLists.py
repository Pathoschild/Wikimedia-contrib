import ListManager, threading, cPickle, time, bz2, os, logging, re, urllib2, os.path, weakref, struct, socket, FlatConfig
# Constants for editor types
c_whitelist=0
c_blacklist=1
c_adminlist=2
c_anon=3
c_normal=4
c_bot=5
c_greylist=6
c_iprange=7
c_flagged=8

c_editor_events=["white","black","admin","ip","normal","bot","grey"]

# Constants for articles types
c_watchlist=0
c_ignorelist=1
c_normalarticle=2

# Constants for images types
c_img_watchlist=0
c_img_normalimage=2

# Constants for list types
c_editorlist = 0
c_articlelist = 1
c_watchwords = 2
c_wheelerwords = 3
c_acl = 4
c_imagelist = 5
c_grey = 6
c_aclo = 7
c_bna = 8
c_flag = 9
c_ipcats = 10

userlists = (c_editorlist, c_grey, c_flag)
articlelists = (c_articlelist, c_imagelist)

# maximum time value support (limited by unix to a 32bit integer...)
c_maxtime = (2**31) - 1  # (2038 sometime)


class Lists:
	def __init__(self, lang, getMsg, sconf, remapCommands):

		self.getMsg = getMsg
		self.logger = logging.getLogger("processor.%s" % lang)
		self.threadstop = threading.Event()
		
		self.reListCmd = re.compile("(?P<item>.*?)(?:\sx=(?P<x>\d*?))?\s*?(?:\sr=(?P<r>.*))?$",re.I)
		self.reListCmd2 = re.compile("(?P<item>.*?)(?:\scs=(?P<cs>y|n))?\s*?(?:\sx=(?P<x>\d*?))?\s*?(?:\sr=(?P<r>.*))?$",re.I)
		
		self.editors = ListManager.getlist(lang,'UserList')
		self.ipeditors = ListManager.getlist(lang,'UserListIP')
		self.articles = ListManager.getlist(lang,'ArticleList')
		self.images = ListManager.getlist(lang,'ImageList')
		self.newuserWW = ListManager.getlist(lang,'NewUserWatchWord')
		self.newarticleWW = ListManager.getlist(lang,'NewArticleWatchWord')
		self.moveWW = ListManager.getlist(lang,'WheelerWords')
		self.acl = ListManager.getlist(lang,'Acl')
		self.aclo = ListManager.getlist(lang,'AclO')
		self.greylist = ListManager.getlist(lang,'Greylist')  # Could be a shelf but probably need not, since items expire after a few minutes
		self.ipgreylist = ListManager.getlist(lang,'GreylistIP')  # Could be a shelf but probably need not, since items expire after a few minutes
		self.flaglist = ListManager.getlist(lang,'Flaglist')
		self.ipflaglist = ListManager.getlist(lang,'FlaglistIP')
		self.ipcats = ListManager.getlist(lang,'IPClassify')
		self.staticconfig = sconf
		self.lang = lang
		
		self.reIP = re.compile("^(\d{1,3}\.\d{1,3}.\d{1,3}.\d{1,3})(\/\d{1,2})?$")
		self.buildipcat()

		self.remapCommands = remapCommands
		
		# map of list types, including the list itself, case sensitive, regex format, delonly, convert space to _
		self.listmap = {
			c_editorlist    : [self.editors, True, False, False, True,self.ipeditors],
			c_articlelist   : [self.articles, True, False, False, True],
			c_watchwords    : [self.newuserWW, True, True, False, False],
			c_wheelerwords  : [self.moveWW, True, True, False, False],
			c_bna           : [self.newarticleWW, True, True, False, False],
			c_acl           : [self.acl, False, False, False, False],
			c_aclo          : [self.aclo, False, False, False, False],
			c_imagelist     : [self.images, True, False, False, True],
			c_grey          : [self.greylist, True, False, True, True,self.ipgreylist],
			c_flag          : [self.flaglist, True, False, False, True,self.ipflaglist],
			c_ipcats        : [self.ipcats, False, False, False, False]}
		
		self.allthreads = weakref.WeakValueDictionary()

		if "dumpfreq" in sconf:
			if eval(sconf["dumpfreq"]) > 0:
				dumper = ListDumper(lang, eval(sconf["dumpfreq"]), sconf["postdump"], self.threadstop)
				dumper.setName("List dumper for %s" % lang)
				dumper.start()
				try:
					self.allthreads[id(dumper)]=dumper
				except:
					pass
				
	def unload(self):
		try:
			self.threadstop.set()
			currentthreads = dict(self.allthreads)
			for thread in currentthreads:
				try:
					thread.join()
				except:
					pass
		except:
			pass

	def getEditors(self, requestor, type, url):
		edGet = UserListBuilder(self.editors, url , requestor, type, self.logger, self.threadstop)
		#edGet.setDaemon(True)
		edGet.setName("Retrieve \"%s\" for %s" % (self.lang, url))
		edGet.start() # kick off thread
		try:
			self.allthreads[id(edGet)]=edGet
		except:
			pass

		
	def updateList(self, list, type, subcommand, data, user):

		subcommand2 = self.remapCommands["lists"].get(subcommand.lower(),subcommand.lower())
		
		if subcommand2 not in ("add","del","show","test","testall"):
			data = subcommand + " " + data
			subcommand2 = "add"
		
		ldetails = self.listmap[list]
		thelist = ldetails[0]
		
		lcase = not ldetails[1]
		regexp = ldetails[2]
		delonly = ldetails[3]
		spaceto_ = ldetails[4]
		if regexp:
			parse=self.reListCmd2
		else:
			parse=self.reListCmd
			

		msgbase=((list*1000)+10000) + (type*100)

		# Split up item, should be the item key, optionally cs=y|n x=<hours> and r=<reason>
		result = parse.search(data)
		if result == None:
			return self.getMsg(4,{"command": subcommand})
		if spaceto_:
			key = result.group("item").strip().replace(" ","_")
		else:
			key = result.group("item").strip()
			
		# Split the ips into separate lists
		if list in userlists:
			resip = self.reIP.search(key)
			if resip:
				thelist = ldetails[5]
		
		if lcase:
			key = key.lower()
		if (list in userlists and self.staticconfig["user_initcap"].lower().startswith("y")) or (list in articlelists and self.staticconfig["article_initcap"].lower().startswith("y")) :
			if len(key) > 1:
				key = key[0].upper() + key[1:]
			else:
				key = key.upper()
			
		if result.group("x") != None:
			expire = eval(result.group("x"))
		else:
			expire = -1
		
		reason = result.group("r")
		
		cs = None
		if regexp:
			cs = result.group("cs")
			if not cs:
				cs = "n"
				
			if cs == "n":
				key = key.lower()
		
		item=thelist.get(key)
				
		if subcommand2 == "add" and not delonly:
			if item != None:
				if item.type == type:
					if reason:
						item.reason = reason
					if expire != -1:
						item.expiry = expire
						item.timestamp = time.time()
						item.expiryconvsecs=3600
					if cs:
						item.casesensitive=cs
					if reason or expire != -1 or cs:
						item.who = user
						if list == c_ipcats:
							self.updateipcat(item)
						thelist[key]=item
					return self.getMsg(msgbase+1,item)
				return self.getMsg(msgbase+10+item.type,item)
			if regexp:
				try:
					tempre = re.compile(key)
				except re.error:
					return self.getMsg(50)

			if expire == -1:
				expire = 0
			if reason == None:
				reason = self.getMsg(1) # No reason
			if not cs:
				cs="n"
				
			newitem = ListEntry(key, user, type, reason, expire,cs=cs)
			if list == c_ipcats:
				if not self.addipcat(newitem):
					return self.getMsg(msgbase+50,newitem)
			
			thelist[key] = newitem
			return self.getMsg(msgbase,newitem)

		if subcommand2 == "del":
			if item == None:
				return self.getMsg(msgbase+21,{"itemname":key})
			if item.type != type:
				return self.getMsg(msgbase+21,item)
			if list == c_ipcats:
				self.delipcat(item)
			thelist.deleteitem(key,user,reason)
			return self.getMsg(msgbase+20, item)

		if subcommand2 == "show":
			if item == None:
				return self.getMsg(msgbase+21, {"itemname":key})
			if item.type != type:
				return self.getMsg(msgbase+21, item)
			else:
				return self.getMsg(msgbase+22,item)

		if subcommand2 == "test" and regexp:
			for exp, item in thelist.iteritems():
				cs = "n"
				if item.casesensitive:
					cs = item.casesensitive.lower()
				if cs == "n":
					res = re.search(exp, key, re.I)
				else:
					res = re.search(exp, key)
				if res:
					return self.getMsg(52,{"word":key})+"\n"+self.getMsg(msgbase+22,item)
			return self.getMsg(54,{"word":key})


		if subcommand2 == "testall" and regexp:
			matches = []
			for exp, item in thelist.iteritems():
				cs = "n"
				if item.casesensitive:
					cs = item.casesensitive.lower()
				if cs == "n":
					res = re.search(exp, key, re.I)
				else:
					res = re.search(exp, key)
				if res:
					matches.append("\"%s\"" % exp)
			if len(matches) > 0:
				
				return self.getMsg(53,{"word":key,"exps":", ".join(matches)})
			return self.getMsg(54,{"word":key})

		return self.getMsg(2,{"command":subcommand})
			
	def buildipcat(self):
		self.ipchecklist = []
		for cat, value in self.ipcats.iteritems():
			self.addipcat(value, False)
		self.ipchecklist.sort(cmp=lambda x,y: cmp(y[3],x[3]))
	
	def delipcat(self, item):
		for value in self.ipchecklist:
			if value[2].what == item.what:
				self.ipchecklist.remove(value)
				return
				
	def updateipcat(self, item):
		for value in self.ipchecklist:
			if value[2].what == item.what:
				self.ipchecklist[self.ipchecklist.index(value)]=(value[0],value[1],item,value[3])
				return
	
	def addipcat(self, item, keepsorted=True):
		result = self.reIP.search(item.what)
		if result == None:
			return False
		masklen = 32
		if result.group(2) != None:
			if result.group(2).startswith("/"):
				masklen = int(result.group(2)[1:])

		if masklen > 32 or masklen < 0:
			return False

		mask=((2**32) - 1) << (32-masklen)

		try:
			bin = struct.unpack("!L",socket.inet_aton(result.group(1)))[0]
			if keepsorted and len(self.ipchecklist) > 0: 
					
				for i in range(0,len(self.ipchecklist)):
					if self.ipchecklist[i][3] < masklen:
						self.ipchecklist.insert(i,(bin, mask, item, masklen))
						break
			else:
				self.ipchecklist.append((bin, mask, item, masklen))
		except:
			return False
		return True

	def getipcat(self, ip):
	
		result = self.reIP.search(ip.strip())
		if result == None:
			return None
		masklen = 32 
		if result.group(2) != None:
			if result.group(2).startswith("/"):
				masklen = int(result.group(2)[1:])
				if masklen > 32 or masklen < 0:
					masklen = 32
		
		mask=((2**32) - 1) << (32-masklen)
		try:
			bin = struct.unpack("!L",socket.inet_aton(result.group(1)))[0]
			for check in self.ipchecklist:
				if (bin & check[1]) == check[0]:
					return check[2]
		except:
			return None

	def classifyeditor(self, ed, iprange=False, flag=False):
		ed = ed.replace(" ","_")
		resip = self.reIP.search(ed)
		if not resip:
			return self.classifyeditor2(ed, iprange, flag)

		if flag:
			flagitem = self.ipflaglist.get(ed)
			
		editor = self.ipgreylist.get(ed,self.ipeditors.get(ed)) 
		
		if editor != None:
			if flag:
				return editor.type, editor, flagitem
			else:
				return editor.type, editor
		
		if resip.group(2) != None:
			if resip.group(2).startswith("/") and iprange:
				if flag:
					return c_iprange, editor, flagitem
				else:
					return c_iprange, editor
		if flag:
			return c_anon, editor, flagitem
		return c_anon, editor
		
	def classifyeditor2(self, ed, iprange=False, flag=False):

		if flag:
			flagitem = self.flaglist.get(ed)
			
		editor = self.greylist.get(ed,self.editors.get(ed)) 
		
		if editor != None:
			if flag:
				return editor.type, editor, flagitem
			else:
				return editor.type, editor
		
		if flag:
			return c_normal, editor, flagitem  # Know if must be none since we wouldn't have got this far...
		else:
			return c_normal, editor

	def classifyeditorall(self, ed):
		ed = ed.replace(" ","_")

		flagitem = self.flaglist.get(ed,self.ipflaglist.get(ed))
		glitem = self.greylist.get(ed,self.ipgreylist.get(ed)) 
		olitem = self.editors.get(ed,self.ipeditors.get(ed))

		ip = False
		iprange = False
	
		result = self.reIP.search(ed)
		if result:
			ip = True
			if result.group(2) != None:
				if result.group(2).startswith("/"):
					iprange = True

		ipcat = self.getipcat(ed)

		return flagitem, glitem, olitem, ip, iprange, ipcat

	def classifyarticle(self, art):
		art = art.replace(" ","_")
		article = self.articles.get(art)

		if article == None:
			return c_normalarticle, article

		return article.type, article
			
	def classifyimage(self, img):
		img = img.replace(" ","_")

		image = self.images.get(img)

		if image == None:
			return c_img_normalimage, image

		return image.type, image


class ListEntry:

	expiryconvsecs=3600
	casesensitive="n"

	def __init__(self, what, who, type, reason, expiry, expiryconvsecs=3600, cs=None):
		self.what = what
		self.who = who
		self.type = type
		self.reason = reason
		self.expiry = expiry
		self.timestamp = time.time()
		self.expiryconvsecs=expiryconvsecs
		self.casesensitive=cs
		#if ((expiry * expiryconvsecs) + self.timestamp) > c_maxtime:
		#	print (expiry*expiryconvsecs)+self.timestamp
		
	def dbitems(self):
		return (("editor","C","255"), ("reason","C","255"), ("type","N","3"))
		
	def __getitem__(self, key):
		if key == "type":
			return self.type
		if key == "itemname":
			return self.what
		if key == "editor":
			return self.who
		if key == "reason":
			return self.reason
		if key == "expiry":
			if (self.expiry == 0) or ((self.timestamp + (self.expiry * self.expiryconvsecs)) > c_maxtime):
				return "indefinite"
			if (self.timestamp + (self.expiry * self.expiryconvsecs)) < time.time():
				return "expired"
			return time.strftime("%H:%M:%S %d-%b-%Y UTC", time.gmtime(self.timestamp + (self.expiry * self.expiryconvsecs)))
		if key == "timestamp":
			return time.strftime("%H:%M:%S %d-%b-%Y UTC", time.gmtime(self.timestamp))
		if key == "expired":
			if (self.expiry == 0):
				return False
			if (self.timestamp + (self.expiry * self.expiryconvsecs)) < time.time():
				return True
			return False
		if key == "casesensitive":
			return self.casesensitive
		raise KeyError

	def expired(self):
		return self.__getitem__("expired")

	def expiry_time(self):
		if (self.expiry == 0) or ((self.timestamp + (self.expiry * self.expiryconvsecs)) > c_maxtime):
			return None
		else:
			return self.timestamp + (self.expiry * self.expiryconvsecs)

	def __contains__(self, item):
		return item in ("itemname","editor","reason","expiry","timestamp","expired","regexflags")
		
class ListDumper(threading.Thread):
	def __init__(self, lang, frequency, postdump, stopevent):
		self.lang = lang
		self.frequency = frequency
		self.postdump = postdump
		self.stopevent = stopevent
		threading.Thread.__init__(self)
	
	def run(self):
		while True:
			stime = (self.frequency*3600) - (time.time() % (self.frequency*3600))
			self.stopevent.wait(stime) # Wait until the hour is up
			if self.stopevent.isSet():
				break
			outfile = bz2.BZ2File("flatconfig/temp-%s" % self.lang,"w")
			FlatConfig.saveconfig(self.lang, outfile, None, self.stopevent)
			outfile.close()
			if self.stopevent.isSet():
				break
			newfile = "flatconfig/dump-%s-%s" % (self.lang, time.strftime("%Y%m%d%H",time.gmtime()))
			os.rename("flatconfig/temp-%s" % self.lang, newfile)
			# If we have a postdump program configured, then spawn it off now passing it the name of the file
			if self.postdump != "":
				result = os.spawnl(os.P_WAIT, self.postdump, os.path.basename(self.postdump),newfile) # Wait to avoid zombies

class UserListBuilder(threading.Thread):
	def __init__(self, userlist, url, user, type, log, stopevent):
		self.userlist = userlist
		self.url = url
		self.user = user
		self.type = type
		self.log = log
		self.stopevent = stopevent
		threading.Thread.__init__(self)
	
	def run(self):
		# Work out currentlist
		currentlist=set()
		count = 0
		for key, item in self.userlist.iteritems():
			count = count + 1
			if count % 100 == 0:
				self.stopevent.wait(0.1) # Short pause so we don't lockup the list
				if self.stopevent.isSet():
					return
			if item.type == self.type:
				currentlist.add(key)
		self.log.info("Existing list has %i entries" % len(currentlist))
		
		req = urllib2.Request(self.url,headers={"user-agent":"pgkbot"})
		reUser=re.compile("\<li\>\<a href\=\"\/wiki\/.+?\" title=\".*?\"\>(.*?)\</a\>")
		data = urllib2.urlopen(req)
		count=0
		newlist=set()
		for line in data:
			print line
			for result in reUser.finditer(line):
				if result == None:
					continue
				luser = result.group(1).replace(" ","_")
				count=count+1
				newlist.add(luser)
				entry = self.userlist.get(luser, None)
				if entry != None:
					if entry.type == self.type:  # already a whatever
						continue
				entry = ListEntry(luser,self.user, self.type, "Auto download from wiki",0)
				self.userlist[luser]=entry # Overwrite current entry with new entry
				if count % 100 == 0: 
					self.stopevent.wait(0.1) # Every 100 have a short pause (makes sure the list isn't locked up)
					if self.stopevent.isSet():
						return
		self.log.info("New list has %i entries" % len(newlist))
		self.log.info("Added %i new entries" % len(newlist.difference(currentlist)))
		dellist=currentlist.difference(newlist)
		count = 0
		for user in dellist:
			count = count + 1
			if count % 100 == 0:
				self.stopevent.wait(0.1)
				if self.stopevent.isSet():
					return
			self.userlist.deleteitem(user, self.user, "Auto download from wiki")
		self.log.info("Deleted %i old entries" % len(dellist))

