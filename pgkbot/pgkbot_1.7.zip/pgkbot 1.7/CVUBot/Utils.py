import time

def readConfig(filename, master={}):
	result = {}
	file = open(filename, "r")
	for line in file:
		line = line.strip()
		if line == "" or line.startswith("#"):
			continue
		try:
			items = line.split('=',1)
			result[items[0].lower()]=items[1]
		except ValueError:
			None
	file.close()

	# Now merge in any missing items from the given master
	for item in master:
		if item not in result:
			result[item]=master[item]
	
	return result
	
def mergeConfig(filename, mergeto, master):
		newconfig = readConfig(filename);
		for item in newconfig:
			if item not in mergeto or master:
				mergeto[item]=newconfig[item]

def readHelp(lang, master={}):
	result = {}
	file = open("Config/%s/Console.help" % lang,"r")
	sect = None
	for line in file:
		if line.startswith(":"):
			if sect != None:
				result[sect]=text
			sect = line[1:].strip()
			text = ""
		else:
			text = text + "\n" + line.strip()
	if sect != None:
		result[sect]=text
	# Now merge in any missing sections from the given master
	for sect in master:
		if sect not in result:
			result[sect]=master[sect]
	return result
