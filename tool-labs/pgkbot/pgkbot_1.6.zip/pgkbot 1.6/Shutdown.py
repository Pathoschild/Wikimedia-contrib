import os, signal, platform

if platform.system() == 'Windows':
	print "Sorry doesn't work on windows"
else:
	pidfile=open("pid","r")
	for line in pidfile:
		pid = eval(line.lstrip())
		os.kill(pid,signal.SIGTERM)
		print "Sent %i the term signal" % pid
