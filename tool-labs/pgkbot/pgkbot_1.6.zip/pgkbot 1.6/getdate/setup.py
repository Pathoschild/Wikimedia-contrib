from distutils.core import setup, Extension

module1 = Extension('getdate',
                    sources = ['getdate.c'])

setup (name = 'getdate',
       version = '1.0',
       description = 'Package for gnu getdate',
       ext_modules = [module1])
