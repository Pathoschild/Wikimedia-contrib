import CVUBot.FlatConfig, threading, sys
from bz2 import BZ2File


def msghandler(msg):
	print msg

lang = sys.argv[1]
filename = sys.argv[2]
outfile = BZ2File(filename,"w")

CVUBot.FlatConfig.saveconfig(lang, outfile, msghandler, threading.Event())

outfile.close()


