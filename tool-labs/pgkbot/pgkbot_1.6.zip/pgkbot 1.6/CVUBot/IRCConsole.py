# Twisted imports
from twisted.words.protocols import irc
from twisted.internet import reactor, protocol
from twisted.python import log

# system imports
import time, sys, re, shelve, threading, logging, logging.handlers

# CVUBot imports
from Utils import readConfig

reRPL1 = "([\+\@])(.*?)\s"
reRPL2 = "^([\+\@])?(#.*)"
c_maxlen = 400

class IRCConsole(irc.IRCClient):
	"""A logging IRC bot."""

	nickname=""
	threadcontrol = threading.RLock() # Use this to lock the lists, since we might be run in two threads concurrently
	logger = logging.getLogger("console")
	overload = False
		
	def __init__(self):
		fh = logging.handlers.TimedRotatingFileHandler("Logs/IRCConsole.log","W0",2,26)
		fh.setFormatter(logging.Formatter("%(levelname)s %(asctime)s %(message)s"))
		self.logger.propogate = False
		self.logger.addHandler(fh)
		self.logger.setLevel(logging.DEBUG)
				
		self.channelsjoined={}
		self.channelskicked=set()
		self.trackchannels = {}
		self.stopping = False
		self.channeltoprocessor={}
		self.nickidentified=set()
		self.idqueue = {}
		self.signedon = False

		# irc.IRCClient.__init__(self)
		
	def irc_NOTICE(self, prefix, params):
		message = params[-1]
		if not message: # Fix problem with empty notices, temporary fix until Twisted is fixed also
			return
		irc.IRCClient.irc_NOTICE(self, prefix, params)


	def channels(self):
		resp = []
		for channel in self.channelsjoined:
			kicked = (channel in self.channelskicked)
			langs = set()
			for proc in self.channeltoprocessor[channel]:
				langs.add(proc.lang)
			resp.append((channel,kicked,langs))
		return resp

	def connectionMade(self):
		self.nickname = self.factory.config['nick']
		self.lineRate = eval(self.factory.config['linerate']) # This limits the rate at which lines will be sent to IRC, be sociable!
		self.logger.info("Connection rate is %0.1f" % self.lineRate)
		irc.IRCClient.connectionMade(self)
		self.logger.info("Connected")

	def connectionLost(self, reason):
		self.signedon = False
		irc.IRCClient.connectionLost(self, reason)
		self.threadcontrol.acquire()
		try:
			for processor in self.factory.RCProcessors:
				self.factory.RCProcessors[processor].delConsole()
		finally:
			self.threadcontrol.release()
		self.logger.info("Disconnected")
		if self.stopping:
			reactor.stop()

	# callbacks for events

	def signedOn(self):
		"""Called when bot has succesfully signed on to server."""
		self.factory.resetDelay()
		self.logger.info("Signed on")
		if "password" in self.factory.config:
			self.logger.info('Sending nickserv password')
			self.msg("NickServ","identify %s" % self.factory.config['password'])
		else:
			self.initProcessors()
		if 'operpassword' in self.factory.config:
			self.logger.info('Sending oper password')
			self.sendLine("OPER %s %s" % (self.nickname, self.factory.config['operpassword']))

	def initProcessors(self):

	# Need to loop through each processor then get the processor to
	# init
		self.signedon = True
		for processor in self.factory.RCProcessors.itervalues():
			processor.setConsole(self)
			
	def addProcessor(self, lang): 
		if self.signedon:
			processor = self.factory.RCProcessors[lang]
			processor.setConsole(self)
			
	def delProcessor(self, lang, processor):
		processor.delConsole()
		
	def noticeall(self, msg):
		self.threadcontrol.acquire()
		try:
			for channel in self.channelsjoined:
				if channel in self.channelskicked:
					pass
				self.notice(channel, msg)
		finally:
			self.threadcontrol.release()

	def join(self, channel, processor):

		self.threadcontrol.acquire()
		try:
			if channel in self.channeltoprocessor:
				self.channeltoprocessor[channel].add(processor)
			else:
				self.channeltoprocessor[channel]=set((processor,))

			if channel in self.channelskicked:
				return  # Don't try and rejoin channels we were kicked from

			if channel in self.channelsjoined:
				self.channelsjoined[channel] = self.channelsjoined[channel]+1
			else:
				self.trackchannels[channel]={}
				self.channelsjoined[channel] = 1
				self.logger.info("Joining channel %s" % channel)
				irc.IRCClient.join(self, channel, None)
		finally:
			self.threadcontrol.release()

	def leave(self, channel, processor, reason=None):
		
		self.threadcontrol.acquire()
		try:
			if channel in self.channeltoprocessor:
				self.channeltoprocessor[channel].discard(processor)
				if len(self.channeltoprocessor[channel]) == 0:
					del self.channeltoprocessor[channel]

			if channel in self.channelsjoined:
				self.channelsjoined[channel] = self.channelsjoined[channel] -1
				if self.channelsjoined[channel] == 0:
					self.logger.info("Leaving channel %s" % channel)
					irc.IRCClient.leave(self, channel, reason)
					del self.channelsjoined[channel]
					del self.trackchannels[channel]
		finally:
			self.threadcontrol.release()

	def joined(self, channel):
		"""This will get called when the bot joins the channel."""
		self.logger.info("joined %s" % channel)
		
	def left(self, channel):
		self.logger.info("left %s" % channel)

	def kickedFrom(self, channel, kicker, message):
		self.logger.warn("kicked from %s by %s reason %s" % (channel, kicker, message))

		self.threadcontrol.acquire()
		try:
			self.channelskicked.add(channel)
			self.trackchannels[channel]={} # No longer reliable
		finally:
			self.threadcontrol.release()
	
	def unkick(self, channel, user):
		self.threadcontrol.acquire()
		try:
			if channel in self.channelskicked:
				self.logger.info("unkicked from %s by %s " % (channel, user))
				self.channelskicked.discard(channel)
				if channel in self.channelsjoined:
					irc.IRCClient.join(self, channel, None)
				return True
		finally:
			self.threadcontrol.release()
		self.logger.warn("attempt to unkick non kicked %s by %s " % (channel, user))
		return False
		
	def getowner(self):
		return self.factory.config.get('owner','Unknown')

	def splitmsg(self, msg):
		if len(msg) <= c_maxlen:
			return msg, None

		pos = msg.rfind(" ", 0, c_maxlen)
		if pos == -1:
			return msg, None  # couldn't split it
		msg1 = msg[:pos]
		msg2 = msg[pos:]
		if msg2[0] == '\x03': # was split conveniently on a colour change?
			return msg1, "    "+msg2
		pos = msg1.rfind("\x03")
		if pos == -1:
			return msg1, "    "+msg2
		
		res = re.search("(\d{1,2})", msg1[pos:])
		if res == None:
			return msg1, "    "+msg2
		return msg1, "    "+"\x03"+res.group(1)+msg2

	def msg(self, user, message, length = None):
		self.threadcontrol.acquire()
		try:
			if user[0] == '#':
				if user in self.channelskicked: 
					return
				joincount=self.channelsjoined.get(user,0)
				if joincount == 0:
					self.logger.warn("Couldn't msg channel I am not joined to %s with %s" % (user, message))
					return
		finally:
			self.threadcontrol.release()
			
		if len(self._queue) < eval(self.factory.config["lowater"]) and self.overload:
			self.overload = False
			self.setNick(self.factory.config["nick"])
			
		msg1, msg2 = self.splitmsg(message)
		irc.IRCClient.msg(self, user, msg1, length)
		if msg2 != None:
			irc.IRCClient.msg(self, user, msg2, length)

	def multimsg(self, destlist, message, length = None):
		dest = []
		self.threadcontrol.acquire()
		try:
			for user in destlist:
				if user[0] == '#':
					if user in self.channelskicked: 
						continue
					joincount=self.channelsjoined.get(user,0)
					if joincount == 0:
						self.logger.warn("Couldn't msg channel I am not joined to %s with %s" % (user, message))
				dest.append(user)
		finally:
			self.threadcontrol.release()

		msg1, msg2 = self.splitmsg(message)

		for channel in dest: 
			if "nickoload" in self.factory.config:
				if not self.overload:
					if len(self._queue) > eval(self.factory.config["hiwater"]):
						self.overload = True
						self.setNick(self.factory.config["nickoload"])
				elif len(self._queue) < eval(self.factory.config["lowater"]):
					self.overload = False
					self.setNick(self.factory.config["nick"])
			
				if len(self._queue) <= eval(self.factory.config["hiwater"]):
					irc.IRCClient.msg(self, channel, msg1, length)
					if msg2 != None:
						irc.IRCClient.msg(self, channel, msg2, length)
			else:
				irc.IRCClient.msg(self, channel, msg1, length)
				if msg2 != None:
					irc.IRCClient.msg(self, channel, msg2, length)

	def resetoq(self):
		retval = len(self._queue)
		self._queue = []
		return retval
		
	def reset(self):
		self.quit("Resetting")

	def shutdown(self):
		self.quit("Shutting down")
		self.stopping = True
		
	def checkIdentified(self, user, channel, msg, processor):
		stuff = (channel, msg, processor)
		self.threadcontrol.acquire()
		try:
			if user in self.idqueue:
				self.idqueue[user].add(stuff)
			else:
				self.idqueue[user]=set()
				self.idqueue[user].add(stuff)
		finally:
			self.threadcontrol.release()
		self.sendLine("WHOIS %s" % user)
		
	def processidqueue(self, user, status):
		self.threadcontrol.acquire()
		try:
			if user in self.idqueue:
				toprocess=self.idqueue[user]
				del self.idqueue[user]
			else:
				return
		finally:
			self.threadcontrol.release()
		for details in toprocess:
			response = details[2].processMessage(self, details[0], user, details[1], "", status)
			if response:
				for line in response.splitlines():
					self.msg(details[0],line)
			
	def action(self, user, channel, data):
		""" Gets called when a user does a /me """
		
		user = user.split('!', 1)[0]
		
		# Ignore own messages ASAP
		if user == self.nickname:
			return
			
		# Shouldn't be needed as these are notices, but just to be safe!
		if user in ["NickServ", "MemoServ", "ChanServ", ""]:
			self.logger.info("me <%s> \"%s\"" % (user, msg))
			return

		self.threadcontrol.acquire()
		try:
			if channel not in self.channeltoprocessor:
				return
			tempset = set(self.channeltoprocessor[channel])
		finally:
			self.threadcontrol.release()

		# Now route to the required processors
		for processor in tempset:
			processor.processMe(self, channel, user, data.strip())
	
	def privmsg(self, user, channel, msg):
		"""This will get called when the bot receives a message."""
		
		user = user.split('!', 1)[0]
		
		# Ignore own messages ASAP
		if user == self.nickname:
			return
			
		# Shouldn't be needed as these are notices, but just to be safe!
		if user in ["NickServ", "MemoServ", "ChanServ", ""]:
			self.logger.info("message <%s> \"%s\"" % (user, msg))
			return

		self.threadcontrol.acquire()
		try:
			if channel not in self.channeltoprocessor:
				return

			usermode = ""
			if channel in self.trackchannels:   # This should always be the case
				usermode=self.trackchannels[channel].get(user,"")
	
			tempset = set(self.channeltoprocessor[channel])
		finally:
			self.threadcontrol.release()
			
		if user in self.nickidentified:
			id = True
		else:
			id = None
			
		# Now route to the required processors

		if len(tempset) == 1:
			for processor in tempset:
				reply = processor.processMessage(self, channel, user, msg.strip(), usermode, id)
				if reply:
					for line in reply.splitlines():
						self.msg(channel, line)
		else:
			responses = {}
			for processor in tempset:
				reply = processor.processMessage(self, channel, user, msg.strip(), usermode, id)
				if reply:
					for line in reply.splitlines():
						if line in responses:
							responses[line] = responses[line] + ", " + processor.lang
						else:
							responses[line] = processor.lang
			for line, langs in responses.iteritems():
				self.msg(channel, "\x02" + langs + "\x0F: " + line)
			

	def noticed(self, user, channel, msg):
		# When I get notices, do nothing with them
		self.logger.info("noticed <%s> \"%s\"" % (user, msg))
		if user.startswith('NickServ') and msg.startswith("Password accepted") and not self.signedon:
			self.initProcessors()

	def usermodeset(self, channel, nick, mode):
		self.threadcontrol.acquire()
		try:
			if channel in self.trackchannels:
				channelusers = self.trackchannels[channel]
				if mode == None:
					if nick in channelusers:
						del channelusers[nick]
				else:
					channelusers[nick] = mode
		finally:
			self.threadcontrol.release()

	def userKicked(self, kickee, channel, kicker, message):
		self.logger.info("%s was kicked by %s from %s with reason \"%s\"" % (kickee, kicker, channel, message))
		self.usermodeset(channel, kickee, None)
		self.nickidentified.discard(kickee)

	def userQuit(self, user, channel):
		self.usermodeset(channel, user, None)
		self.nickidentified.discard(user)

	def userLeft(self, user, channel):
		self.usermodeset(channel, user, None)
		self.nickidentified.discard(user)

	def userJoined(self, user, channel):
		self.usermodeset(channel, user, None)
		self.sendLine("WHOIS %s" % user)
		self.nickidentified.discard(user)
	
	def userRenamed(self, oldname, newname):
		self.nickidentified.discard(oldname)
		self.nickidentified.discard(newname)
		self.threadcontrol.acquire()
		try:
			for channel in self.trackchannels:
				channelusers = self.trackchannels[channel]
				if oldname in channelusers:
					channelusers[newname]=channelusers[oldname]
					del channelusers[oldname]
		finally:
			self.threadcontrol.release()

	# When I join a channel I get details of who is on and voice or op
	def irc_RPL_NAMREPLY(self, prefix, params):
		channel = params[2]
		for result in re.finditer(reRPL1,params[3]):
			mode = result.group(1)
			nick = result.group(2)
			self.usermodeset(channel, nick, mode)
			# self.sendLine("WHOIS %s" % nick)

	def irc_RPL_WHOISCHANNELS(self, prefix, params):
		nick = params[1]
		channels = params[2].split(None)
		for channel in channels:
			result = re.search(reRPL2,channel)
			if result != None:
				self.usermodeset(result.group(2), nick, result.group(1))
				
	def irc_320(self, prefix, params):
		self.nickidentified.add(params[1])
		self.processidqueue(params[1],True)
	
	def irc_RPL_ENDOFWHOIS(self, prefix, params):
		if params[1] not in self.nickidentified:
			self.processidqueue(params[1],False)
		
	def modeChanged(self, user, channel, set, modes, args):
		for nick in args:
			self.nickidentified.discard(nick)
			self.sendLine("WHOIS %s" % nick)


class ConsoleFactory(protocol.ReconnectingClientFactory):

	# A factory for IRCConsoleBots - contains the config as the main bot
	# class goes when connection is lost

	# the class of the protocol to build when new connection is made
	protocol = IRCConsole

	def __init__(self, processors):
		self.config = readConfig("Config/IRCConsole.conf")
		self.RCProcessors = processors
		reactor.connectTCP(self.config['server'], eval(self.config['port'].strip()), self)

	#def clientConnectionLost(self, connector, reason):
	#	"""If we get disconnected, reconnect to server."""
	#	connector.connect()

	#def clientConnectionFailed(self, connector, reason):
	#	print "connection failed:", reason
	#	reactor.stop()
	def buildProtocol(self, addr):
		p = self.protocol()
		self.lastp = p
		p.factory = self
		return p
