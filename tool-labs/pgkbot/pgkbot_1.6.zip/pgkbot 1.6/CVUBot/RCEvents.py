import time

class rcEdit:
	def __init__(self, article, namespace, editor, diff, summary, size, minor, user, rbuser = None):
		self.difflink=diff
		self.articlename=article
		self.editor=editor
		self.summary=summary
		self.size=size
		self.minor = minor
		self.problem = None
		self.timestamp = time.time()
		self.namespace = namespace
		if self.namespace == 2:
			self.userpage= True
		else:
			self.userpage=False
		if self.namespace == 3:
			self.usertalk = True
		else:
			self.usertalk = False
		self.user = user
		self.rbuser = rbuser
	
	def content_checked(self, problem): # The content checker will fill in problem details if there are some
		self.problem=problem
	
	def __str__(self):
		return "Edit of article %s by %s summary %s (user page %s)" % (self.articlename, self.editor, self.summary, self.user)

class rcNew(rcEdit):
	def __init__(self, article, namespace, editor, diff, summary, size, minor, user):
		rcEdit.__init__(self,article, namespace, editor, diff, summary, size, minor, user)
	def __str__(self):
		return "New article %s by %s summary %s (user page %s)" % (self.articlename, self.editor, self.summary, self.user)

class rcNewEditor:
	def __init__(self, editor, creator):
		self.editor = editor
		self.creator = creator
	def __str__(self):
		return "New Editor %s" % self.editor

class rcDelArticle:
	def __init__(self, name, namespace, admin, reason):
		self.articlename = name
		self.admin = admin
		self.reason = reason
		self.namespace = namespace
	def __str__(self):
		return "Deletion of article %s by %s summary %s" % (self.articlename, self.admin, self.reason)

class rcRestoreArticle(rcDelArticle):
	def __init__(self, name, namespace, admin, reason):
		rcDelArticle.__init__(self, name, namespace, admin, reason)
	def __str__(self):
		return "Restoration of article %s by %s summary %s" % (self.articlename, self.admin, self.reason)

class rcBlockEditor:
	def __init__(self, editor, admin, length, reason):
		self.admin = admin
		self.editor = editor
		self.reason = reason
		self.length = length
	def __str__(self):
		return "Block of editor %s by %s for %s summary %s" % (self.editor, self.admin, self.length, self.reason)

class rcUnblockEditor(rcBlockEditor):
	def __init__(self, editor, admin, reason):
		rcBlockEditor.__init__(self, editor, admin, "", reason)
	def __str__(self):
		return "Unblock of editor %s by %s summary %s" % (self.editor, self.admin, self.reason)

class rcMovePage:
	def __init__(self, editor, namefrom, namespacefrom, nameto, namespaceto,  reason):
		self.editor=editor
		self.namefrom=namefrom
		self.namespacefrom=namespacefrom
		self.nameto=nameto
		self.namespaceto=namespaceto
		self.reason=reason
	def __str__(self):
		return "Move of %s to %s by %s summary %s" % (self.namefrom, self.nameto, self.editor, self.reason)

class rcUploaded:
	def __init__(self, editor, itemname, namespace, comment):
		self.editor = editor
		self.itemname = itemname
		self.comment = comment
		self.namespace = namespace
	def __str__(self):
		return "Upload %s by %s summary %s" % (self.itemname, self.editor, self.comment)

class rcProtect:
	def __init__(self, editor, itemname, namespace, comment):
		self.editor = editor
		self.itemname = itemname
		self.namespace = namespace
		self.comment = comment
	def __str__(self):
		return "Protect %s by %s summary %s" % (self.itemname, self.editor, self.comment)

class rcUnprotect(rcProtect):
	def __init__(self, editor, itemname, namespace, comment):
		rcProtect.__init__(self, editor, itemname, namespace, comment)
	def __str__(self):
		return "Unprotect %s by %s summary %s" % (self.itemname, self.editor, self.comment)
	
class rcRenameUser:
	def __init__(self, bureaucrat, namefrom, nameto):
		self.bureaucrat = bureaucrat
		self.namefrom = namefrom
		self.nameto = nameto
	def __str__(self):
		return "Rename user %s to %s by %s" % (self.namefrom, self.nameto, self.bureaucrat)

class rcRights:
	def __init__(self, editor, bureaucrat, rights):
		self.bureaucrat = bureaucrat
		self.editor = editor
		self.rights = rights
	def __str__(self):
		return "User %s rights set %s by %s" % (self.editor, self.rights, self.bureaucrat)
