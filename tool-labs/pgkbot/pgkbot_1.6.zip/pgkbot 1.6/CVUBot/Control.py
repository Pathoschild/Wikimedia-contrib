# Provide a control interface through telnet to allow a local application to control the bot

import traceback, re, threading
import Version, Processor
from twisted.internet import protocol, reactor
from twisted.conch.protocols import telnet

class controlsession(telnet.Telnet):
 
  currentchannel = ""

  def connectionMade(self):
        telnet.Telnet.connectionMade(self)
  
  def welcomeMessage(self):
    return "\r\nCVUBot %s telnet console\r\n" % Version.VERSION
  
  def loginPrompt(self):
    return "Login Username: "

  def checkUserAndPass(self, username, passwd):
    return ((username == self.factory.username) and (passwd == self.factory.password))
    return True # Whatever
    
  def loggedIn(self):
    self.transport.write("Logged on \r\nCVUBot>")
  
  def telnet_Command(self, cmd):
    try:
      command, rest = cmd.split(None,1)
    except:
      command = cmd
      rest = ""
      
    command = command.capitalize()
    
    if not hasattr(self,"cmd_"+command):
      self.transport.write("No such command \"%s\"\r\n" % command)
      return "Command"
    
    try:
      rc = getattr(self,"cmd_"+command)(rest)
      if rc == "Command":
        self.transport.write("CVUBot>")
      return rc
    except:
      self.transport.write("Problem executing command %s\r\n" % command)
      self.transport.write(re.sub("([^\r]{1})\n",r"\1\r\n",traceback.format_exc()))
      self.transport.write("CVUBot>")
    return "Command"

  def cmd_Quit(self, msg):
    self.transport.write("Quitting\r\n")
    return "Done"
    
  def cmd_Help(self, msg):
    msg = """
Available commands:
help - This help
quit - Disconnect telnet control
list - show languages currently being run
start - start a language
stop - stop a language
restart - stop then start a language
reload - reload a python module
reset - reset both IRC connections (the RC feed and the IRC Console)
threadlist - list the currently active threads
threadstop - those from the list with a flag of s can be stopped. Use with care.
cmd - send a command line direct to the given language
channel - set the channel for the following messaging commands
send - Send a message to the current channel
me - Send a me to the current channel
notice - send a notice to the current channel
noticeall - send a notice to all channels the bot is connected to
channellist - list all channels joined and which language(s) they relate to
"""
    self.transport.write(re.sub("([^\r]{1})\n",r"\1\r\n",msg))
    return "Command"

  def cmd_Shutdown(self, msg):  # Shutdown
    self.transport.write("Shutting down\r\n")
    reactor.stop()
    return "Done"
  
  def cmd_List(self, msg):  # list langs
    msg = "Currently running \"languages\"\r\n" + "\r\n".join(self.factory.processors) + "\r\n"
    self.transport.write(msg)
    return "Command"
    
  def cmd_Start(self, lang):  # add lang
    processor = self.factory.processors.get(lang, None)
    if processor != None:
      self.transport.write("\"language\" %s already running\r\n" % lang)
      return "Command"
    processor = Processor.Processor(lang)
    self.factory.processors[lang]=processor
    self.factory.console.lastp.addProcessor(lang)
    self.factory.reader.lastp.addlang(lang)
    self.transport.write("Started \"language\" %s\r\n" % lang)
    return "Command"

  def cmd_Stop(self, lang):  # del lang
    processor = self.factory.processors.get(lang, None)
    if processor == None:
      self.transport.write("\"language\" %s not running\r\n" % lang)
      return "Command"
    self.factory.reader.lastp.removelang(lang, processor)
    processor.unload()
    self.factory.console.lastp.delProcessor(lang, processor)
    self.factory.processors.pop(lang, None)
    self.transport.write("\"language\" %s stopped\r\n" % lang)
    return "Command"
    
  def cmd_Restart(self, lang): # restart a give lang
    processor = self.factory.processors.get(lang, None)
    if processor == None:
      self.transport.write("\"language\" %s not running\r\n" % lang)
      return "Command"
    self.factory.reader.lastp.removelang(lang, processor)
    processor.unload()
    self.factory.console.lastp.delProcessor(lang, processor)
    self.factory.processors.pop(lang, None)
    self.transport.write("\"language\" %s stopped\r\n" % lang)
    processor = Processor.Processor(lang)
    self.factory.processors[lang]=processor
    self.factory.console.lastp.addProcessor(lang)
    self.factory.reader.lastp.addlang(lang)
    self.transport.write("Started \"language\" %s\r\n" % lang)
    return "Command"

  def cmd_Reload(self, modname):  # reload module
    mod = self.mod_import(modname)
    reload(mod)
    self.transport.write("Reloaded module \"%s\"\r\n" % modname)
    return "Command"

  def cmd_Reset(self, msg):  # reset console and reader
    self.factory.console.lastp.reset()
    self.factory.reader.lastp.reset()
    self.transport.write("Reset sent to console and reader\r\n")
    return "Command"

  def cmd_Threadlist(self, msg):  # List threads
    msg = ""
    allthreads = threading.enumerate()
    for thread in allthreads:
      
      if hasattr(thread, "stopevent"):
        flags = "S"
      else:
        flags = ""
      
      if thread.isDaemon():
        flags = flags + "D"
        
      msg = msg + "%s\t%s\t%s\r\n" % (hex(id(thread)),  flags, thread.getName())
    
    self.transport.write("Thread id\tFlags\tName\r\n"+msg)
    return "Command"

  def cmd_Threadstop(self, threadid):  # Stop thread
    allthreads = threading.enumerate()
    for thread in allthreads:
      
      if hasattr(thread, "stopevent") and hex(id(thread)) == msg.strip():
        getattr(thread, "stopevent").set()
        self.transport.write("Set stopevent for thread\r\n")
        return "Command"
      
    self.transport.write("Cannot find stoppable thread with that ID\r\n")
    return "Command"
    
  def notice(self,channel,line):
    self.resp = self.resp + ("<notice %s> " %channel)+line+"\r\n"
  
  def msg(self,channel,line):
    self.resp = self.resp + ("<msg %s>"%channel)+line+"\r\n"
    
  def cmd_Cmd(self, msg): # Inject command
    self.resp = ""
    lang, rest = msg.split(None,1)
    self.factory.processors[lang].processMessage(self,'console','console',rest,'^',True)
    self.transport.write("Response received\r\n"+self.resp)
    return "Command"
    
  def cmd_Channel(self,channel):
    if channel.strip() == "":
      self.transport.write("Channel is %s\r\n" % self.currentchannel) 
    else:
      self.currentchannel = channel.strip()
      self.transport.write("Set channel\r\n")

    return "Command"
      
  def cmd_Send(self, msg):
    if self.currentchannel == None:
      self.transport.write("No current channel\r\n")
      return "Commmand"
    self.factory.console.lastp.msg(self.currentchannel,msg)
    self.transport.write("Sent\r\n")
    return "Command"

  def cmd_Me(self, msg):
    if self.currentchannel == None:
      self.transport.write("No current channel\r\n")
      return "Commmand"
    self.factory.console.lastp.me(self.currentchannel,msg)
    self.transport.write("Sent\r\n")
    return "Command"

  def cmd_Notice(self, msg):
    if self.currentchannel == None:
      self.transport.write("No current channel\r\n")
      return "Commmand"
    self.factory.console.lastp.notice(self.currentchannel,msg)
    self.transport.write("Sent\r\n")
    return "Command"
    
  def cmd_Noticeall(self, msg):
    self.factory.console.lastp.noticeall(msg)
    self.transport.write("Sent\r\n")
    return "Command"

  def cmd_Channellist(self, msg):
    msg = "Channel\t\t\tLanguages\r\n"
    for channel in self.factory.console.lastp.channels():
      if channel[1]: 
        msg = msg + "%s (kicked)\t%s\r\n" % (channel[0], ",".join(channel[2]))
      else:
        msg = msg + "%s\t%s \r\n" % (channel[0], ",".join(channel[2]))
    self.transport.write(msg)
    return "Command"
    

  def mod_import(self, name):
    mod = __import__(name)
    components = name.split('.')
    for comp in components[1:]:
       mod = getattr(mod, comp)
    return mod

class control(protocol.ServerFactory):

  protocol=controlsession
  
  def __init__(self, reader, console, processors, bindaddress, bindport, username, password):
    self.reader = reader
    self.console = console
    self.processors = processors
    self.username = username
    self.password = password
    reactor.listenTCP(int(bindport), self, interface=bindaddress)
