import threading, shelve, time, cPickle

try:
	import MySQLdb
except ImportError:
	pass
	
import Utils 

class LMSimpleBase:
	
	def __init__(self, dict):
		self.dict = dict
		self.lock = threading.RLock()
		self.stopevent = threading.Event()
	
	def __getitem__(self, key):
		self.lock.acquire()
		try:
			return self.dict[key]
		finally:
			self.lock.release()

	def get(self, key, default=None):
		self.lock.acquire()
		try:
			return self.dict.get(key, default)
		finally:
			self.lock.release()
		
	def __setitem__(self, key, value):
		self.lock.acquire()
		try:
			self.dict[key]=value
		finally:
			self.lock.release()
		
	def __delitem__(self, key):
		self.lock.acquire()
		try:
			del self.dict[key]
		finally:
			self.lock.release()
		
	def deleteitem(self, key, who, reason):
		self.lock.acquire()
		try:
			temp = self.dict.pop(key, None)
		finally:
			self.lock.release()
		return
		
	def __contains__(self, key):
		self.lock.acquire()
		try:
			return self.dict.__contains__(key)
		finally:
			self.lock.release()
		
	def __iter__(self):
		return self.iterkeys()
		
	def iterkeys(self):
		currentkeys = self.keys()
		for key in currentkeys:
			yield key
			
	def keys(self):
		self.lock.acquire()
		try:
			return self.dict.keys()
		finally:
			self.lock.release()

	def iteritems(self):
		currentkeys = self.keys()
		for key in currentkeys:
			try:
				item = self.dict[key]
			except:
				continue
			yield key, item

	def close(self):
		#print "Setting stopevent"
		self.stopevent.set()

class LMBase(LMSimpleBase):
	
	def __init__(self, dict):
		LMSimpleBase.__init__(self,dict)
	
	def __getitem__(self, key):
		self.lock.acquire()
		try:
			item = self.dict[key]
		finally:
			self.lock.release()
		if item.expired():
			raise IndexError
		return item

	def get(self, key, default=None):
		self.lock.acquire()
		try:
			item = self.dict.get(key,default)
		finally:
			self.lock.release()
		if item != default:
			if item.expired():
				item = default
		return item
		
	def __delitem__(self, key):
		raise IndexError # Don't want them to delete stuff this way
		
	def __contains__(self, key):
		self.lock.acquire()
		try:
			item = self.dict.get(key)
		finally:
			self.lock.release()
		if item == None:
			return False
		if item.expired():
			return False
		return True

	def iterkeys(self):
		currentkeys = self.keys()
		for key in currentkeys:
			item = self.dict.get(key,None)
			if item == None:
				continue
			if item.expired():
				continue
			yield key

	def iteritems(self):
		currentkeys = self.keys()
		for key in currentkeys:
			item = self.dict.get(key,None)
			if item == None:
				continue
			if item.expired():
				continue
			yield key, item

class LMMemMaint(threading.Thread):
	
	def __init__(self, dict, lock, stopevent):
		self.dict = dict
		self.lock = lock
		self.stopevent = stopevent
		threading.Thread.__init__(self)
	
	def run(self):
		while True and self.dict != None:
			self.stopevent.wait(1800) # 30 minutes
			if self.stopevent.isSet():
				return	
			self.lock.acquire()
			try:
				if self.dict != None:
					keys = self.dict.keys()
					for key in keys:
						item = self.dict.get(key,None)
						if item != None:
							if item.expired():
								self.dict.pop(key, None)
			finally:
				self.lock.release()

class LMMemory(LMBase):
	def __init__(self, lang, key):
		LMBase.__init__(self, {})
		self.maint=LMMemMaint(self.dict,self.lock, self.stopevent)
		#self.maint.setDaemon(True)
		self.maint.setName("Memory list maintenance %s.%s" % (lang,key))
		self.maint.start()

class LMSimpleMemory(LMSimpleBase):
	def __init__(self, lang, key):
		LMSimpleBase.__init__(self, {})
		
	def __len__(self):
		return len(self.dict)

class LMSimpleShelfMaint(threading.Thread):

	def __init__(self, dict, lock, stopevent):
		self.dict = dict
		self.lock = lock
		self.stopevent = stopevent
		threading.Thread.__init__(self)

	def run(self):
		while True and self.dict != None:
			self.stopevent.wait(120) # 2 minutes
			if self.stopevent.isSet():
				return	
			self.lock.acquire()
			try:
				if self.dict != None:
					self.dict.sync()
			finally:
				self.lock.release()

class LMShelfMaint(threading.Thread):
	
	def __init__(self, dict, keys, lock, stopevent):
		self.dict = dict
		self.lock = lock
		self.allkeys = keys
		self.stopevent = stopevent
		threading.Thread.__init__(self)
	
	def run(self):
		self.count = 0
		while True and self.dict != None:
			self.stopevent.wait(120) # 2 minutes
			if self.stopevent.isSet():
				return	
			self.lock.acquire()
			try:
				if self.dict != None:
					self.dict.sync()
					self.count = self.count + 1
					if self.count == 10:
						keys = list(self.allkeys)
			finally:
				self.lock.release()
			
			if self.count == 10:
				self.count = 0
				stepsize = 100
				while len(keys) > 0 and self.dict !=None:
					if len(keys) > stepsize:
						processkeys = keys[0:stepsize-1]
						keys = keys[stepsize:]
					else:
						processkeys=keys
						keys=[]
					self.lock.acquire()
					try:
						if self.dict != None:
							for key in processkeys:
								item = self.dict.get(key, None)
								if item != None:
									if item.expired():
										del self.dict[key]
										self.allkeys.discard(key)
					finally:
						self.lock.release()
					self.stopevent.wait(0.1)
					if self.stopevent.isSet():
						return	
				
				if self.stopevent.isSet():
						return	

				self.lock.acquire()
				try:
					if self.dict != None:
						self.dict.sync()
				finally:
					self.lock.release()


class LMShelf(LMBase):
	
	def __init__(self, lang, key):
		LMBase.__init__(self, shelve.open("Config/%s/%s.dbm" % (lang, key),'c'))
		self.dictkeys = set(self.dict.keys())  # Maintain a copy of the keys, for faster access. Will be a hit at startup
		self.maint=LMShelfMaint(self.dict,self.dictkeys,self.lock,self.stopevent)
		#self.maint.setDaemon(True)
		self.maint.setName("Shelf list maintenance %s.%s" % (lang,key))
		self.maint.start()
		
	def deleteitem(self, key, who, reason):
		self.lock.acquire()
		try:
			self.dict.pop(key, None)
			self.dictkeys.discard(key)
		finally:
			self.lock.release()
		return

	def close(self):
		self.stopevent.set()
		self.lock.acquire()
		try:
			if self.dict != None:
				self.dict.close()
				self.dict = None
		finally:
			self.lock.release()

	def __setitem__(self, key, value):
		self.lock.acquire()
		try:
			self.dict[key]=value
			self.dictkeys.add(key)
		finally:
			self.lock.release()

	def keys(self):
		self.lock.acquire()
		try:
			return list(self.dictkeys)
		finally:
			self.lock.release()

class LMSimpleShelf(LMSimpleBase):
	def __init__(self, lang, key):
		LMSimpleBase.__init__(self, shelve.open("Config/%s/%s.dbm" % (lang, key),'c'))
		self.maint=LMSimpleShelfMaint(self.dict,self.lock, self.stopevent)
		#self.maint.setDaemon(True)
		self.maint.setName("Simple shelf list maintenance %s.%s" % (lang,key))
		self.maint.start()

	def close(self):
		self.stopevent.set()
		self.lock.acquire()
		try:
			if self.dict != None:
				self.dict.close()
				self.dict = None
		finally:
			self.lock.release()

class LMDBBase:

	def __init__(self):
		self.lock = threading.RLock()
		self.stopevent = threading.Event()
		self.usetime = {}
		self.cache = {}
		self.allkeys = self.getallkeys()

	def __getitem__(self, key):
		self.lock.acquire()
		try:
			item = self.cache.get(key, None)
			if item == None:
				item = self.dbget(key,None)
				if item != None:
					self.cache[key]=item
			if item != None:
				if item.expired():
					self.deleteitem(key, "auto", "expired")
					item=None
				else:
					self.usetime[key]=time.time()
					
		finally:
			self.lock.release()
		if item == None:
			raise IndexError
		return item

	def get(self, key, default=None):
		try:
			return self.__getitem__(key)
		except IndexError:
			return default
		
	def __setitem__(self, key, value):
		self.lock.acquire()
		try:
			self.cache[key]=value
			self.usetime[key] = time.time()
			self.dbput(key,value)
			self.allkeys.add(key)
		finally:
			self.lock.release()
		
	def __delitem__(self, key):
		raise IndexError # Don't want them to delete stuff this way
		
	def deleteitem(self, key, who, reason):
		self.lock.acquire()
		try:
			self.cache.pop(key, None)
			self.usetime.pop(key, None)
			self.dbdelete(key,who,reason)
			self.allkeys.remove(key)
		finally:
			self.lock.release()
		return
		
	def __contains__(self, key):
		return self.get(key,None) != None
		
	def keys(self):
		return list(self.allkeys)

		
	def __iter__(self):
		return self.iterkeys()

	def iterkeys(self):
		self.lock.acquire()
		try:
			currentkeys = self.keys()
		finally:
			self.lock.release()
		for key in currentkeys:
			item = self.get(key,None)
			if item == None:
				continue
			yield key

	def iteritems(self):
		self.lock.acquire()
		try:
			currentkeys = self.keys()
		finally:
			self.lock.release()
		for key in currentkeys:
			item = self.get(key,None)
			if item == None:
				continue
			yield key, item
			
	def close(self):
		#print "hello"
		self.stopevent.set()
			
class LMDBMaint(threading.Thread):
	def __init__(self, dict, stopevent):
		self.dict = dict
		self.stopevent = stopevent
		threading.Thread.__init__(self)
	
	def run(self):
		# every 2 minutes, see if our cache has exceeded the high-water mark, if so clear out the oldest used items
		# and expired items, until we are below the low-water mark
		while True:
			self.stopevent.wait(120) # 2 minutes
			if self.stopevent.isSet():
				return	
			self.dict.lock.acquire()
			try:
				currtime = time.time()
				if len(self.dict.cache) > self.dict.high_water_mark:
					for key, value in self.dict.cache.iteritems():
						if value.expired():
							self.dict.usetime.pop(key, None)
							self.dict.cache.pop(key, None)
					if len(self.dict.cache) > self.dict.low_water_mark:
						oldest = sorted(self.dict.usetime, cmp=lambda x,y: cmp(self.dict.usetime[y], self.dict.usetime[x]))
						for key in oldest:
							self.dict.usetime.pop(key, None)
							self.dict.cache.pop(key, None)
							if len(self.dict.usetime) < self.dict.low_water_mark:
								break
					self.dict.dbdelexpired("auto","expired")
			finally:
				self.dict.lock.release()

class LMDBMysql(LMDBBase):
	
		low_water_mark = 800
		high_water_mark = 1000
		formats = {"C":"varchar", "N":"numeric"}
				
		def __init__(self, lang, key):
			global allconf

			dbuser=allconf[lang]["mysql_user"]
			dbpassword=allconf[lang]["mysql_password"]
			dbase=allconf[lang]["mysql_dbase"]
			dbhost=allconf[lang]["mysql_host"]
			self.db = MySQLdb.connect(host=dbhost,user=dbuser,passwd=dbpassword,db=dbase)
			self.cursor = self.db.cursor()
			self.cursor.execute("set session transaction isolation level read committed")
			self.lang = lang
			self.key = key
			self.tabname = lang + "_" + key
			
			self.checktable()
			LMDBBase.__init__(self)
			self.maint=LMDBMaint(self, self.stopevent)
			#self.maint.setDaemon(True)
			self.maint.setName("Mysql list maintenance %s.%s" % (lang,key))
			self.maint.start()
			
		def checktable(self):
			# check table exists, poplate self.dbcols with columns in table,
			# create base table if it doesn't already exist
			self.dbcols = set()
			sql = "create table if not exists %s " % self.tabname
			sql = sql + "(lm_id bigint auto_increment primary key, lm_key varchar(255) not null, "
			sql = sql + "lm_delete char(1) default 'n',"
			sql = sql + "lm_delreason varchar(255), "
			sql = sql + "lm_delby varchar(255), "
			sql = sql + "lm_expiry datetime, "
			sql = sql + "lm_pickledata text, "
			sql = sql + "index main (lm_key, lm_delete) ) "
			sql = sql + "engine innodb"
			
			self.cursor.execute(sql)
			
			self.cursor.execute("describe %s" % self.tabname)
			row = self.cursor.fetchone()
			while row != None:
				if row[0].startswith("obj_"):
					self.dbcols.add(row[0])
				row = self.cursor.fetchone()
			
		def addCol(self, item):
			# Add a column to the table required for the item data.
			colname = "obj_"+item[0]
			format = self.formats[item[1]]+"(%s)" % item[2]
			
			self.dbcols.add(colname)
			self.cursor.execute("alter table %s add column %s %s" % (self.tabname, colname, format))

		def close():
			self.stopevent.set()
			self.lock.acquire()
			try:
				self.cursor.close()
				self.db.close()
			finally:
				self.lock.release()
		
		def dbget(self, key, default):
			if key not in self.allkeys:
				return default
			# Delete expired versions of this key first
			sql = "update "+self.tabname + " set lm_delete = 'Y', lm_delreason = 'expired', lm_delby = 'sys' where lm_delete = 'N' and lm_expiry <= now() and lm_key = %s"
			self.cursor.execute(sql, (key,))
			sql = "select lm_pickledata from " + self.tabname + " where lm_key = %s and (lm_expiry > now() or lm_expiry is null) and lm_delete = 'N' LIMIT 1"
			self.cursor.execute(sql, (key,))
			x = self.cursor.fetchone()
			self.db.commit()
			if x == None:
				return default
			return cPickle.loads(x[0])
			
		def getallkeys(self):
			sql = "select lm_key from %s where lm_delete = 'N' and lm_expiry > now() or lm_expiry is null" % self.tabname
			self.cursor.execute(sql)
			x = self.cursor.fetchall()
			if x == None:
				return set()
			result = set()
			for row in x:
				result.add(row[0])
			return result

		def dbput(self, key, value):
			sql = "update %s set lm_delete = 'Y', lm_delreason = 'superceded', lm_delby = 'sys' where " % self.tabname
			sql = sql + "lm_key = %s and lm_delete = 'N'" 
			self.cursor.execute(sql, (key,))
			extrakeys = value.dbitems()
			sql = "insert into %s (lm_delete, lm_key, lm_pickledata, lm_expiry " % self.tabname
			
			values = "'N', %s, %s, from_unixtime(%s)" 
			vals = list()
			vals.append(key)
			vals.append(cPickle.dumps(value))
			vals.append(value.expiry_time())
			for extraitem in extrakeys:
				itemkey = extraitem[0]
				if "obj_"+itemkey not in self.dbcols:
					self.addCol(extraitem)
				sql = sql + ", obj_%s" % itemkey
				values = values + ", %s" 
				vals.append(value[itemkey])
				
			sql = sql + ") values (%s)" % values
			self.cursor.execute(sql, vals)
			self.db.commit()
			return 
			
		def dbdelete(self, key, who, reason):
			sql = "update " + self.tabname +" set lm_delete = 'Y', lm_delreason = %s, lm_delby = %s where lm_key = %s and lm_delete = 'N'" 
			self.cursor.execute(sql, (reason, who,key))
			self.db.commit()
			return
			
		def dbdelexpired(self):
			sql = "update %s set lm_delete = 'Y', lm_delreason = 'expired', lm_delby = 'sys' where lm_delete = 'N' and em_expiry <= now()" % self.tabname
			self.cursor.execute(sql)
			self.db.commit()
			return
		
		#def close(self):
		#	self.db.close()
	

config={}
itemcache={}
allconf={}

def getlist(lang,key):
	key2=key.lower()
	if lang not in config:
		allconf[lang] = Utils.readConfig("Config/%s/StaticConfig" % lang)
		config[lang]={}
		itemcache[lang]={}
		for keyx, value in allconf[lang].iteritems():
			if keyx.startswith("list_"):
				config[lang][keyx[5:]]=value
		if len(config[lang]) == 0:
			del config[lang]
			raise KeyError

	if key2 not in config[lang]:
		raise KeyError
	if key2 in itemcache[lang]:
		return itemcache[lang][key2]
	exec("object = %s(lang,key)" % config[lang][key2])
	itemcache[lang][key2]=object
	return object

def closeall():
	for lang,keys in itemcache.iteritems():
		for key,list in keys.iteritems():
			list.close()


