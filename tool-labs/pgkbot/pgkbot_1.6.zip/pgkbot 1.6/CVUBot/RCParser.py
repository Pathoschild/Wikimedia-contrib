from twisted.internet import reactor
import urllib2, ConfigParser, re, logging, xml.dom.minidom
from RCEvents import *

# The messages mediawiki uses is obtained from the wiki and translated into a regular expression. However the message on mediawiki maybe ambiguous,
# so this is not 100% , updates to the wiki's messages maybe required to enable them to be unambiguously recognised e.g. containing variable items in "s or [[s

wikisource = { 
	"restored" : ["MediaWiki:Undeletedarticle",1,True],
	"deleted" : ["MediaWiki:Deletedarticle",1,True],
	"protected" : ["MediaWiki:Protectedarticle",1,True],
	"unprotected" : ["MediaWiki:Unprotectedarticle",1,True],
	"uploaded" : ["MediaWiki:Uploadedimage",0,True],
	"moved1" : ["MediaWiki:1movedto2",2,True],
	"moved2" : ["MediaWiki:1movedto2_redir",2,True],
	"renameuser" : ["MediaWiki:Renameuserlog",2,True],
	"rights" : ["MediaWiki:Bureaucratlogentry",0,True],
	"blocked" : ["MediaWiki:Blocklogentry",2,True],
	"unblocked" : ["MediaWiki:Unblocklogentry",0,True],
	"rollback" : ["MediaWiki:Revertpage",2,False],
	"newuser" : ["MediaWiki:Revertpage",0,True]
	}
	
rechars = r"\.()[]^*+?{}|"   #\ must be first, $ isn't here since it also has another meaning, we'll deal with that separately

class NotParseable(Exception):
	def __init__(self, message):
		self.message = message
	def __str__(self):
		return self.message

class RCParser:
	
	logger = logging.getLogger("rcreader")
	
	def __init__(self,processor):
		self.reStripColours = re.compile("\x04\d{0,2}\*?")
		self.reStripMisc = re.compile("\x02")
		self.simplerestring = "\x0302(?P<item1>.+?)\x0310.*?(?:: (?P<comment>.*?))?$"
		self.simplerecompiled = re.compile(self.simplerestring)
		self.reStripColours2 = re.compile("\x03\d{0,2}")
	
		self.baseurl = processor.staticconfig["baseurl"]
		
		self.config = ConfigParser.SafeConfigParser()
		self.config.read("Config/%s/RCParser.ini" % processor.lang)

		if not self.config.has_section(self.baseurl):
			self.config.add_section(self.baseurl)

		self.namespaces={}

		if not self.config.has_option(self.baseurl,"ns_-1"):
			self.getNamespaces()
		
		for key, value in self.config.items(self.baseurl):
			if key.startswith("ns_"):
				self.namespaces[key]=value
				self.namespaces[value]=int(key[3:])

		self.reMatchLog = re.compile(self.namespaces["ns_-1"]+":Log/(.+?)$")
		self.reMatchUser = re.compile("^(?:"+self.namespaces["ns_2"]+"|"+self.namespaces["ns_3"]+"):(?P<username>.+?)(?:/|$)")
		
		self.regex = {}
		for item in wikisource:
			if not self.config.has_option(self.baseurl,item):
				restring, recompiled = self.getre(item)
			else:
				restring = self.config.get(self.baseurl, item)
				if restring != "":
					try:
						recompiled = re.compile(restring)
					except:
						raise NotParseable("Regular expression for %s does not compile" % item)
				else:
					recompiled = None
			
			self.config.set(self.baseurl,item,restring)
			self.regex[item]=recompiled
		
		writeback = file("Config/%s/RCParser.ini" % processor.lang,"w")
		
		self.config.write(writeback)
		writeback.close()
			
	def getNamespaces(self):
		
		url = self.baseurl + "/wiki/Special:Export/.cvubot"  # should never be an article should it? (Not that it matters)
		req = urllib2.Request(url,headers={"user-agent":"cvubot"})
		data = urllib2.urlopen(req)
		
		dom = xml.dom.minidom.parse(data)
		
		allns = dom.getElementsByTagName ("siteinfo")[0].getElementsByTagName ("namespaces")[0].getElementsByTagName ("namespace")
		
		for ns in allns:
			nsid = ns.getAttribute("key")
			nstext = ""
			for node in ns.childNodes:
				if node.nodeType == node.TEXT_NODE:
					nstext = nstext + node.data
			nstext = nstext.encode("UTF-8")
			nsid = nsid.encode("UTF-8")	
			self.namespaces["ns_%s" % nsid]=nstext
			self.namespaces[nstext]=nsid
			self.config.set(self.baseurl,"ns_%s" % nsid,nstext)
		
		dom.unlink()
		
	def getre(self, item):
		if wikisource[item][1] == 0:
			return self.simplerestring, self.simplerecompiled
			
		url = self.baseurl + "/w/index.php?title=" + wikisource[item][0] + "&action=raw"
		req = urllib2.Request(url,headers={"user-agent":"pgkbot"})
		try:
			data = urllib2.urlopen(req)
		except:
			print "Problem opening %s" % url
			return "",None
		count = 0
		reqitems = wikisource[item][1]
		for line in data:
			count = count + 1
		if count != 1:
			print "Error retrieving %s, no data returned by wiki possibly requires that message to be edited" % url
			return "", None
		
		restring = line
		for char in rechars:
			restring	= restring.replace(char,"\\" + char)
		
		if wikisource[item][2]:
			restring	= restring.replace("$1","\x0302(?P<item1>.+?)\x0310",1)
		else:
			restring	= restring.replace("$1","(?P<item1>.+?)",1)
		restring	= restring.replace("$2","(?P<item2>.+?)",1)
		restring	= restring.replace("$3","(?P<item3>.+?)",1)
		restring	= restring.replace("$1","(?:.+?)")
		restring	= restring.replace("$2","(?:.+?)")
		restring	= restring.replace("$3","(?:.+?)")
		
		restring	= restring.replace("$",r"\$")
		restring	= "^" + restring + "(?:: (?P<comment>.*?))?$"
		try:
			recompiled = re.compile(restring)
		except:
			raise NotParseable("Regular expression for %s does not compile" % item)
		if reqitems > 0:
			ok = False
			if "(?P<item1>.+?)" in restring and reqitems == 1:
				ok = True
			if "(?P<item2>.+?)" in restring and reqitems == 2:
				ok = True
			if "(?P<item3>.+?)" in restring and reqitems == 3:
				ok = True
			if not ok:
				restring = ""
				recompiled = None

		return restring, recompiled
		
	def articlenamespace(self, article):
		try:
			namespacetext, realname = article.split(":",1)
			namespace = self.namespaces.get(namespacetext, 0)
			return namespace
		except:
			return 0


	def parseRCmsg(self, msg):
		msg = msg.replace("\x03","\x04",14)
		strippedmsg = self.reStripMisc.sub("", self.reStripColours.sub("\x03",msg))
		fields = strippedmsg.split("\x03",14)
		if len(fields[14]) > 0:
			if fields[14][-1:]=="\x03":
				fields[14]=fields[14][0:-1]
		
		special = self.reMatchLog.search(fields[2])
		if special != None:
			parser = getattr(self,"parse_"+special.group(1), None)
			if parser == None:
				print "No handler for special log %s " % special.group(1)
				return None
			else:
				return parser(fields)
		
		# Got this far so it's not a log item, must be a "straight" edit (or New)
		
		article = fields[2]
		diff = fields[6]
		editor = fields[10]
		minor = ("M" in fields[4])
		new =  ("N" in fields[4])
		size = eval(fields[13].strip())
		
		comment = fields[14].replace("\x03","")
		
		namespace = self.articlenamespace(article) # Main

		user=""
		if namespace in (2,3):  # A user page
			res = self.reMatchUser.search(article)
			if res != None:
				user = res.group("username")
		
		rbuser = None
		if not new and self.regex["rollback"] != None:
			res = self.regex["rollback"].search(comment)
			if res !=None:
				rbuser = res.group('item2')

		if new:
			return rcNew(article, namespace, editor, diff, comment, size, minor, user)
		else:
			return rcEdit(article, namespace, editor, diff, comment, size, minor, user, rbuser)
	
	def parse_move(self,fields):
		if self.regex["moved1"] == None or self.regex["moved2"] == None:
			return
		res = self.regex["moved1"].search(fields[14])
		if res == None:
			res = self.regex["moved2"].search(fields[14])
			if res == None:
				return None
		
		item1 = self.reStripColours2.sub("",res.group('item1'))
		item2 = self.reStripColours2.sub("",res.group('item2'))
				
		return rcMovePage(fields[10], item1, self.articlenamespace(item1), item2, self.articlenamespace(item2),self.makecomment(res.group('comment')))
		
	def parse_delete(self,fields):
		if self.regex["restored"] != None:
			res = self.regex["restored"].search(fields[14])
			if res != None:
				return rcRestoreArticle(res.group('item1'), self.articlenamespace(res.group('item1')), fields[10], self.makecomment(res.group('comment')))
		if self.regex["deleted"] != None:
			res = self.regex["deleted"].search(fields[14])
			if res != None:
				return rcDelArticle(res.group('item1'), self.articlenamespace(res.group('item1')), fields[10], self.makecomment(res.group('comment')))
		return None
		
	def parse_protect(self,fields):
		if self.regex["protected"] != None:
			res = self.regex["protected"].search(fields[14])
			if res != None:
				return rcProtect(fields[10], res.group('item1'), self.articlenamespace(res.group('item1')), self.makecomment(res.group('comment')))
		if self.regex["unprotected"] != None:
			res = self.regex["unprotected"].search(fields[14])
			if res != None:
				return rcUnprotect(fields[10], res.group('item1'), self.articlenamespace(res.group('item1')), self.makecomment(res.group('comment')))
		return None

	def parse_rights(self,fields):
		if self.regex["rights"] != None:
			res = self.regex["rights"].search(fields[14])
			if res != None:
				return rcRights(res.group('item1'), fields[10] , self.makecomment(res.group('comment')))
		return None
		
	def parse_upload(self, fields):
		if self.regex["uploaded"] != None:
			res = self.regex["uploaded"].search(fields[14])
			if res != None:
				return rcUploaded(fields[10],res.group('item1'), self.articlenamespace(res.group('item1')),self.makecomment(res.group('comment')))
		return None

	def parse_block(self,fields):
		if self.regex["blocked"] != None:
			res = self.regex["blocked"].search(fields[14])
			if res != None:
				blockname = res.group('item1')
				if blockname.startswith(self.namespaces["ns_2"]+":"):
					blockname = blockname.replace(self.namespaces["ns_2"]+":","",1)
				return rcBlockEditor(blockname, fields[10], res.group('item2'), self.makecomment(res.group('comment')))
		if self.regex["unblocked"] != None:
			res = self.regex["unblocked"].search(fields[14])
			if res != None:
				blockname = res.group('item1')
				if blockname.startswith(self.namespaces["ns_2"]+":"):
					blockname = blockname.replace(self.namespaces["ns_2"]+":","",1)
				return rcUnblockEditor(blockname, fields[10], self.makecomment(res.group('comment')))
		return None

	def parse_newusers(self,fields):
		if self.regex["newuser"] != None:
			res = self.regex["newuser"].search(fields[14])
			if res != None:
				created = res.group('item1')
				if created.startswith(self.namespaces["ns_2"]+":"):
					created = created.replace(self.namespaces["ns_2"]+":","",1)
				return rcNewEditor(created, fields[10])
		return rcNewEditor(fields[10],fields[10])
		
	def parse_renameuser(self,fields):
		if self.regex["renameuser"] != None:
			res = self.regex["renameuser"].search(fields[14])
			if res != None:
				return rcRights(fields[10] , res.group('item1'), res.group('item2'))
		return None
	
	def makecomment(self, value):
		if value == None:
			return ""
		else:
			return self.reStripColours2.sub("",value)
