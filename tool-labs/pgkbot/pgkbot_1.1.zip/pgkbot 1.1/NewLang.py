#!/usr/bin/python
import sys, os
def newlang(lang):
  print "Setting up directories for %s" % lang
  os.mkdir("Config/%s" % lang)
  os.mkdir("Logs/%s" % lang)
  x = file("Config/%s/Console.help" % lang,"w")
  x.close()
  x = file("Config/%s/Console.msgs" % lang,"w")
  x.close()
  filein = file("Config/en/StaticConfig","r")
  fileout = file("Config/%s/StaticConfig" % lang,"w")
  for line in filein:
    fileout.write(line)
  filein.close()
  fileout.close()
  print "Created basic directory structure, config now needs updating for correct values for language"
  
if __name__ == '__main__':
  for lang in sys.argv[1:]:
    newlang(lang)



