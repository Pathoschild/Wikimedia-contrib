#!/usr/bin/python
import sys, shelve, CVUBot.Utils, os.path, imp, CVUBot.Processor, os, NewLang, CVUBot.ListManager, platform
try:
  import getdate
  gdate = True
except:
  gdate = False

names=["Acl", "ArticleList", "Config","ImageList", "NewUserWatchWord","Routes","Stats","UserList","WheelerWords"]
  
  
def mergeconfig( filename, olddict, renames={}, commentout=[]):
  mergewith = open(filename,"r")
  alllines = list(mergewith)
  mergewith.close()
  mergeto = open(filename,"w")
  for line in alllines:
    if line == "" or line.startswith("#"):
      mergeto.write(line)
      continue
    try:
      items = line.split('=',1)
      oldname = renames.get(items[0], items[0])
      if oldname.lower() in olddict:
        mergeto.write("%s=%s\n" % (items[0], olddict[oldname.lower()]))
      else:
        if items[0] in commentout:
          mergeto.write("#")
        mergeto.write(line)
      continue
    except ValueError:
      mergeto.write(line)
      continue
  mergeto.close()

if not gdate:
  print "The getdate python extension is missing, please install this before proceeding"
  if platform.system == "Windows":
    print "For windows you can run the installer in the getdate directory, getdate_inst.exe or build from scratch (complex)"
  else:
    print "You will need to build the module from scratch, this requires a suitably configured python environment and c compiler, run the setup.py file with the install parameter in the getdate directory"
  system.exit(1)

if len(sys.argv) <= 2:
  print "Usage: python Upgrade.py <olddirectory> <lang>*"
  sys.exit(2)

oldpath = os.path.abspath(sys.argv[1])
if not os.path.isdir(oldpath):
  print "%s is not a directory" % sys.argv[1]
  sys.exit(2)

#try:
#  olddets = imp.find_module("RCProcessor",[oldpath+"/CVUBot"])
#except:
#  print "Couldn't work out old version, the old directory maybe wrong or maybe incompatible with the upgrade process"
#  sys.exit(2)
#try:
#oldproc = imp.load_module("oldprocessor",olddets[0],olddets[1],olddets[2])
#except:
#  print "Couldn't work out old version, the old directory maybe wrong or maybe incompatible with the upgrade process"
#  try: 
#   olddets[0].close()
#  except:
#   pass
#  sys.exit(2)

#try:
#  oldver = oldproc.VERSION
#except:
#  oldver = None

#if oldver == None:
#  print "Couldn't work out old version, the old directory maybe wrong or maybe incompatible with the upgrade process"
#  sys.exit(2)
#    
#print "Upgrading from version %2.2f to %2.2f" % (oldver, CVUBot.processor.VERSION)
print ""
print "Processing basic config"
oldconf1 = CVUBot.Utils.readConfig(oldpath + "/Config/IRCConsole.conf")
oldconf2 = CVUBot.Utils.readConfig(oldpath + "/Config/RCReader.conf")

print "Updating IRCConsole.conf"
mergeconfig("Config/IRCConsole.conf", oldconf1,{},("operpassword","password","nickoload"))
print "Updating RCReader.conf"
mergeconfig("Config/RCReader.conf", oldconf2)

namemap={}
for name in names:
 namemap[name.lower()]=name

langs = set(sys.argv[2:])

for lang in langs:
  print ""
  print "Processing lang %s " % lang
  oldstatic = CVUBot.Utils.readConfig(oldpath + "/Config/%s/StaticConfig" % lang)
  if not os.path.isdir("Config/%s" % lang):
    NewLang.newlang(lang)
  mergeconfig("Config/%s/StaticConfig" % lang, oldstatic, {}, ("dumpfreq","mysql_user","mysql_password","mysql_dbase","mysql_host"))  
  newstatic = CVUBot.Utils.readConfig("Config/%s/StaticConfig" % lang)
  print "Copying list files"
  for key, value in oldstatic.iteritems():
    if key.startswith("list_") and value in ("LMShelf", "LMSimpleShelf"):
      if key in newstatic:
        shelfname = namemap[key[5:]]+".dbm"
        oldshelf = shelve.open(oldpath+"/Config/%s/%s" %(lang, shelfname),"c")
        newlist = CVUBot.ListManager.getlist(lang, namemap[key[5:]])
        for key,item in oldshelf.iteritems():
          if value == "LMShelf":
            if not item.expired():
              print key
              newlist[key]=item
          else:
            newlist[key]=item
        newlist.close()
print "Finished processing all files, remember to check config file Config/IRCConsole.conf and Config/*/StaticConfig as new options have been added to these files"
