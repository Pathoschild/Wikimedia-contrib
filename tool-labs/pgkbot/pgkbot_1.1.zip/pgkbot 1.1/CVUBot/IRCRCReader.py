# Twisted imports
from twisted.words.protocols import irc
from twisted.internet import reactor, protocol

# system imports
import sys, logging, logging.handlers
import RCParser

# CVUBot imports
from Utils import readConfig

class RCReader(irc.IRCClient):
	"""A logging IRC bot."""

	nickname = ""
	logger = logging.getLogger("rcreader")
	
	def __init__(self):
		fh = logging.handlers.TimedRotatingFileHandler("Logs/RCReader.log","W0",2,26)
		fh.setFormatter(logging.Formatter("%(levelname)s %(asctime)s %(message)s"))
		self.logger.propogate = False
		self.logger.addHandler(fh)
		self.logger.setLevel(logging.DEBUG)
 
	def connectionMade(self):
		self.nickname = self.factory.config['nick']
		irc.IRCClient.connectionMade(self)
		self.logger.info("Connected")
		self.mapchanneltolang = {}
		self.mapchanneltoparser = {}
		for lang, processor in self.factory.RCProcessors.iteritems():
			channel = processor.staticconfig["rcsourcechannel"]
			if channel in self.mapchanneltolang:
				self.mapchanneltolang[channel].add(lang)
			else:
				self.mapchanneltolang[channel]=set([lang])
				self.mapchanneltoparser[channel] = RCParser.RCParser(processor)

		self.file = open("msgs", "a")

	def connectionLost(self, reason):
		irc.IRCClient.connectionLost(self, reason)
		self.logger.info("Disconnected")
		for lang in self.factory.RCProcessors:
			self.factory.RCProcessors[lang].delReader()
		self.file.close()

	def reset(self):
		self.logger.info("Reseting")
		self.quit("Reseting")

	# callbacks for events

	def signedOn(self):
		"""Called when bot has succesfully signed on to server."""
		self.logger.info("Signed on")
		for channel in self.mapchanneltolang:
			self.join(channel)
		for lang in self.factory.RCProcessors:
			self.factory.RCProcessors[lang].setReader(self)

	def joined(self, channel):
		"""This will get called when the bot joins the channel."""
		self.logger.info("joined %s" % channel)

	def privmsg(self, user, channel, msg):
		"""This will get called when the bot receives a message."""
		if channel not in self.mapchanneltolang or channel not in self.mapchanneltoparser:
			return

		rcEvent = self.mapchanneltoparser[channel].parseRCmsg(msg)
		if rcEvent == None:
			self.file.write("%s : %s\n" % (channel, msg))
			return

		for lang in self.mapchanneltolang[channel]:
			if lang in self.factory.RCProcessors:
				self.factory.RCProcessors[lang].doRCEvent(rcEvent)

class ReaderFactory(protocol.ClientFactory):
	# A factory for RCReaders. Contains the config for the reader
	# As the Readers themselves die when connection is lost

	# the class of the protocol to build when new connection is made
	protocol = RCReader

	def __init__(self, processors):
		self.RCProcessors = processors;
		self.config = readConfig("Config/RCReader.conf")
		reactor.connectTCP(self.config['server'], eval(self.config['port']), self)

	def clientConnectionLost(self, connector, reason):
		"""If we get disconnected, reconnect to server."""
		connector.connect()

	def clientConnectionFailed(self, connector, reason):
		print "connection failed:", reason
		reactor.stop()




