import ListManager, threading, cPickle, time, bz2, os, logging, re, urllib2
# Constants for editor types
c_whitelist=0
c_blacklist=1
c_adminlist=2
c_anon=3
c_normal=4
c_bot=5
c_greylist=6

c_editor_events=["white","black","admin","anon","normal","bot","grey"]

# Constants for articles types
c_watchlist=0
c_ignorelist=1
c_normalarticle=2

# Constants for images types
c_img_watchlist=0
c_img_normalimage=2

# Constants for list types
c_editorlist = 0
c_articlelist = 1
c_watchwords = 2
c_wheelerwords = 3
c_acl = 4
c_imagelist = 5
c_grey = 6
c_aclo = 7

userlists = (c_editorlist, c_grey)
articlelists = (c_articlelist, c_imagelist)


class Lists:
	def __init__(self, lang, getMsg, sconf):

		self.getMsg = getMsg
		self.logger = logging.getLogger("processor.%s" % lang)
		
		self.reListCmd = re.compile("(.*?)(\sx=(\d*?)){0,1}(\sr=(.*)){0,1}$",re.I)
		
		self.editors = ListManager.getlist(lang,'UserList')
		self.articles = ListManager.getlist(lang,'ArticleList')
		self.images = ListManager.getlist(lang,'ImageList')
		self.newuserWW = ListManager.getlist(lang,'NewUserWatchWord')
		self.moveWW = ListManager.getlist(lang,'WheelerWords')
		self.acl = ListManager.getlist(lang,'Acl')
		self.aclo = ListManager.getlist(lang,'AclO')
		self.greylist = ListManager.getlist(lang,'Greylist')  # Could be a shelf but probably need not, since items expire after a few minutes
		self.staticconfig = sconf
		
		self.reIP = re.compile("^\d{1,3}\.\d{1,3}.\d{1,3}.\d{1,3}$")

		# map of list types, including the list itself, case sensitive, regex format, delonly, convert space to _
		self.listmap = {
			c_editorlist    : [self.editors, True, False, False, True],
			c_articlelist   : [self.articles, True, False, False, True],
			c_watchwords    : [self.newuserWW, False, True, False, False],
			c_wheelerwords  : [self.moveWW, False, True, False, False],
			c_acl           : [self.acl, False, False, False, False],
			c_aclo         : [self.aclo, False, False, False, False],
			c_imagelist     : [self.images, True, False, False, True],
			c_grey          : [self.greylist, True, False, True, True]}

		if "dumpfreq" in sconf:
			if eval(sconf["dumpfreq"]) > 0:
				dumper = ListDumper({"editors":self.editors,
														"articles":self.articles,
														"new users watch words":self.newuserWW,
														"wheeler words":self.moveWW,
				"image list":self.images,
				"acl":self.acl}, lang, eval(sconf["dumpfreq"]))
				dumper.setDaemon(True)
				dumper.start()

	def getEditors(self, requestor, type, url):
		edGet = UserListBuilder(self.editors, url , requestor, type, self.logger)
		edGet.start() # kick off thread
		
	def updateList(self, list, type, subcommand, data, user):

		subcommand = subcommand.lower()
		ldetails = self.listmap[list]
		thelist = ldetails[0]
		lcase = not ldetails[1]
		regexp = ldetails[2]
		delonly = ldetails[3]
		spaceto_ = ldetails[4]

		msgbase=((list*1000)+10000) + (type*100)

		# Split up item, should be the item key, optionally x=<hours> and r=<reason>
		result = self.reListCmd.search(data)
		if result == None:
			return self.getMsg(4,{"command": subcommand})
		if spaceto_:
			key = result.group(1).strip().replace(" ","_")
		else:
			key = result.group(1).strip()
		
		if lcase:
			key = key.lower()
		if (list in userlists and self.staticconfig["user_initcap"].lower().startswith("y")) or (list in articlelists and self.staticconfig["article_initcap"].lower().startswith("y")) :
			if len(key) > 1:
				key = key[0].upper() + key[1:]
			else:
				key = key.upper()
			
		if result.group(3) != None:
			expire = eval(result.group(3))
		else:
			expire = -1
		
		reason = result.group(5)
		
		item=thelist.get(key)
		
		if subcommand == 'add' and not delonly:
			if item != None:
				if item.type == type:
					if reason != None:
						item.reason = reason
					item.who = user
					if expire != -1:
						item.expiry = expire
					item.timestamp = time.time()
					thelist[key]=item
					return self.getMsg(msgbase+1,item)
				return self.getMsg(msgbase+10+item.type,item)
			if regexp:
				try:
					tempre = re.compile(key)
				except re.error:
					return self.getMsg(50)
			if expire == -1:
				expire = 0
			if reason == None:
				reason = self.getMsg(1) # No reason
				
			newitem = ListEntry(key, user, type, reason, expire)
			thelist[key] = newitem
			return self.getMsg(msgbase,newitem)

		if subcommand == 'del':
			if item == None:
				return self.getMsg(msgbase+21,{"itemname":key})
			if item.type != type:
				return self.getMsg(msgbase+21,item)
			thelist.deleteitem(key,user,reason)
			return self.getMsg(msgbase+20, item)

		return self.getMsg(2,{"command":subcommand})
			
			
	def classifyeditor(self, ed):
		ed = ed.replace(" ","_")
		editor = self.greylist.get(ed,self.editors.get(ed))
		
		if editor != None:
			return editor.type, editor
		result = self.reIP.search(ed)
		if result == None:
			return c_normal, editor
		return c_anon, editor

	def classifyarticle(self, art):
		art = art.replace(" ","_")
		article = self.articles.get(art)

		if article == None:
			return c_normalarticle, article

		return article.type, article
			
	def classifyimage(self, img):
		img = img.replace(" ","_")

		image = self.images.get(img)

		if image == None:
			return c_img_normalimage, image

		return image.type, image




class ListEntry:

	expiryconvsecs=3600

	def __init__(self, what, who, type, reason, expiry, expiryconvsecs=3600):
		self.what = what
		self.who = who
		self.type = type
		self.reason = reason
		self.expiry = expiry
		self.timestamp = time.time()
		self.expiryconvsecs=expiryconvsecs
		
	def dbitems(self):
		return (("editor","C","255"), ("reason","C","255"), ("type","N","3"))
		
	def __getitem__(self, key):
		if key == "type":
			return self.type
		if key == "itemname":
			return self.what
		if key == "editor":
			return self.who
		if key == "reason":
			return self.reason
		if key == "expiry":
			if (self.expiry == 0):
				return "indefinite"
			if (self.timestamp + (self.expiry * self.expiryconvsecs)) < time.time():
				return "expired"
			return time.strftime("%H:%M:%S %d-%b-%Y UTC", time.gmtime(self.timestamp + (self.expiry * self.expiryconvsecs)))
		if key == "timestamp":
			return time.strftime("%H:%M:%S %d-%b-%Y UTC", time.gmtime(self.timestamp))
		if key == "expired":
			if (self.expiry == 0):
				return False
			if (self.timestamp + (self.expiry * self.expiryconvsecs)) < time.time():
				return True
			return False
		raise KeyError

	def expired(self):
		return self.__getitem__("expired")

	def expiry_time(self):
		if self.expiry == 0:
			return None
		else:
			return self.timestamp + (self.expiry * self.expiryconvsecs)

	def __contains__(self, item):
		return item in ("itemname","editor","reason","expiry","timestamp","expired")
		
class ListDumper(threading.Thread):
	def __init__(self,lists, lang, frequency):
		self.lists=lists
		self.lang = lang
		self.frequency = frequency
		threading.Thread.__init__(self)
	
	def run(self):
		while True:
			stime = (self.frequency*3600) - (time.time() % (self.frequency*3600))
			time.sleep(stime) # Wait until the hour is up
			outfile = bz2.BZ2File("flatconfig/temp-%s" % self.lang,"w")
			outfile.write("Config for %s\n" % self.lang)
			count = 0
			for name, list in self.lists.iteritems():
				outfile.write("#<%s>#\n" % name)
				for item, value in list.iteritems():
					count = count + 1
					if count % 200 == 0:
						time.sleep(0.1) # short pause every 200 items
					if value != None:
						outfile.write("key:%s\n" % item)
						cPickle.dump(value,outfile,2)
			outfile.close()
			newfile = "flatconfig/dump-%s-%s" % (self.lang, time.strftime("%Y%m%d%H",time.gmtime()))
			os.rename("flatconfig/temp-%s" % self.lang, newfile)

class UserListBuilder(threading.Thread):
	def __init__(self, userlist, url, user, type, log):
		self.userlist = userlist
		self.url = url
		self.user = user
		self.type = type
		self.log = log
		threading.Thread.__init__(self)
	
	def run(self):
		# Work out currentlist
		currentlist=set()
		count = 0
		for key, item in self.userlist.iteritems():
			count = count + 1
			if count % 100 == 0:
				time.sleep(0.1) # Short pause so we don't lockup the list
			if item.type == self.type:
				currentlist.add(key)
		self.log.info("Existing list has %i entries" % len(currentlist))
		
		req = urllib2.Request(self.url,headers={"user-agent":"pgkbot"})
		reUser=re.compile("\<li\>\<a href\=\"\/wiki\/.+?\" title=\".*?\"\>(.*?)\</a\>")
		data = urllib2.urlopen(req)
		count=0
		newlist=set()
		for line in data:
			result = reUser.search(line)
			if result == None:
				continue
			luser = result.group(1).replace(" ","_")
			count=count+1
			newlist.add(luser)
			entry = self.userlist.get(luser, None)
			if entry != None:
				if entry.type == self.type:  # already a whatever
					continue
			entry = ListEntry(luser,self.user, self.type, "Auto download from wiki",0)
			self.userlist[luser]=entry # Overwrite current entry with new entry
			if count % 100 == 0: 
				time.sleep(0.1) # Every 100 have a short pause (makes sure the list isn't locked up)
		self.log.info("New list has %i entries" % len(newlist))
		self.log.info("Added %i new entries" % len(newlist.difference(currentlist)))
		dellist=currentlist.difference(newlist)
		count = 0
		for user in dellist:
			count = count + 1
			if count % 100 == 0:
				time.sleep(0.1)
			self.userlist.deleteitem(user, self.user, "Auto download from wiki")
		self.log.info("Deleted %i old entries" % len(dellist))

