import RCPLists, getdate, ListManager, re, time
from urllib import quote

class StandardHandler:

	def __init__(self, Lists, reportEvent, lang, getMsg):
		self.Lists = Lists
		self.getMsg = getMsg
		self.reportEvent = reportEvent
		self.blocks = ListManager.getlist(lang,'Blocklist')  # Not a shelf since we might bugger up over down periods of the bot
		self.config = ListManager.getlist(lang,'Config')
		self.reOldid = re.compile("oldid=(\d+)")


	def process_rcNew(self, rcevent):

		sizeattrib=""
		sizereset=""
		classes = set()
		msgno = -1
		editortype, item = self.Lists.classifyeditor(rcevent.editor)
		articletype, artitem = self.Lists.classifyarticle(rcevent.articlename)
		classes.add(RCPLists.c_editor_events[editortype])

		# Don't care about users creating their own page or talk page nor admins or whitelisted users
		if (rcevent.userpage or rcevent.usertalk) and (rcevent.user == rcevent.editor or editortype in (RCPLists.c_adminlist, RCPLists.c_whitelist)):
			return
		
		if editortype in (RCPLists.c_blacklist, RCPLists.c_greylist):
			msgno = 5000+editortype
		
		if rcevent.size > eval(self.config["newbig"]):
			msgno = 5010+editortype
			classes.add("bignew")
			sizeattrib=self.getMsg(100)
			sizereset=self.getMsg(102)
		if rcevent.size < eval(self.config["newsmall"]):
			msgno = 5020 + editortype
			classes.add("tinynew")
			sizeattrib=self.getMsg(100)
			sizereset=self.getMsg(102)
		if articletype == RCPLists.c_watchlist:
			msgno = 5030+editortype
			classes.add("watched")
			classes.add("cvp")

		if msgno == -1:
			self.content_check(rcevent)
			return
		
		if rcevent.minor:
			minor = "M"
		else:
			minor = ""
		
		msg = self.getMsg(msgno, {
			"article": rcevent.articlename,
			"earticle": quote(rcevent.articlename),
			"editor": rcevent.editor,
			"size": "%d" % rcevent.size,
			"reason": rcevent.summary,
			"minor": minor,
			"sizeattrib": sizeattrib,
			"sizereset": sizereset
			})

		self.reportEvent(msg, classes)

	def process_rcEdit(self, rcevent):
		sizeattrib=""
		sizereset=""
		classes = set()
		msgno = -1
		articletype, artitem = self.Lists.classifyarticle(rcevent.articlename)

		if articletype == RCPLists.c_ignorelist:
			return

		editortype, item = self.Lists.classifyeditor(rcevent.editor)
		
		if editortype == RCPLists.c_adminlist and self.config["glonrollback"] not in ("0","00") and rcevent.rbuser != None:
			if rcevent.rbuser != rcevent.editor:  # Don't concern with users rolling back themselves
				editortype2, item2 = self.Lists.classifyeditor(rcevent.rbuser)
				if editortype2 in (RCPLists.c_anon, RCPLists.c_normal, RCPLists.c_whitelist, RCPLists.c_greylist):
					item = RCPLists.ListEntry(rcevent.rbuser.replace("_"," "), rcevent.editor, RCPLists.c_greylist, "admin rollback on [[%s]]" % rcevent.articlename , eval(self.config["glonrollback"]), 60)
					self.Lists.greylist[rcevent.rbuser.replace(" ","_")] = item
		
		# Ignore smaller edits by the owner of the page, but do concerning blanking and large additions 
		if (rcevent.userpage or rcevent.usertalk) and (rcevent.user == rcevent.editor):
			if editortype in (RCPLists.c_adminlist, RCPLists.c_whitelist):
				return
			if not (rcevent.size > eval(self.config["editbig"]) or rcevent.size < eval(self.config["editblank"])):
				return

		classes.add(RCPLists.c_editor_events[editortype])
		
		if editortype in (RCPLists.c_blacklist, RCPLists.c_greylist):
			msgno = 5100+editortype

		if rcevent.size > eval(self.config["editbig"]):
			msgno = 5110+editortype
			classes.add("bigedit")
			sizeattrib=self.getMsg(100)
			sizereset=self.getMsg(102)
		if articletype == RCPLists.c_watchlist:
			msgno = 5130+editortype
			classes.add("watched")
			classes.add("cvp")
		if rcevent.size < eval(self.config["editblank"]):
			msgno = 5120+editortype
			classes.add("bigremove")
			sizeattrib=self.getMsg(101)
			sizereset=self.getMsg(103)

		if msgno == -1:
			self.content_check(rcevent)
			return
		if rcevent.minor:
			minor = "M"
		else:
			minor = ""
		
		res = self.reOldid.search(rcevent.difflink)
		if res == None:
			oldid="0"
		else:
			oldid=res.group(1)

		reason = rcevent.summary
		# self.reWikiTidy.replace("\1]]",rcevent.summary)

		msg = self.getMsg(msgno, {
			"article": rcevent.articlename,
			"earticle": quote(rcevent.articlename),
			"oldid": oldid,
			"editor": rcevent.editor,
			"size": "%d" % rcevent.size,
			"reason": reason,
			"minor": minor,
			"sizeattrib": sizeattrib,
			"sizereset": sizereset
			})

		self.reportEvent(msg, classes)
		
	def content_check(self, rcevent):
		# preparing to integrate on toolserver, if we have a tsdatabase add to the queue
		# Just in case make sure we are using the ts and that it hasn't already been checked
		pass

	def process_rcNewEditor(self, rcevent):
		classes = set(["newuser"])
		msgno = 5200
		word = ""
		for word in self.Lists.newuserWW:
			word = word.lower()
			result = re.search(word, rcevent.editor,re.I)
			if result != None:
				msgno = 5201
				classes.add("wwuser")
				break

		msg = self.getMsg(msgno,{
			"editor": rcevent.editor,
			"watchword": word
			})
		
		
		self.reportEvent(msg, classes)
		if "wwuser" in classes:
			item = RCPLists.ListEntry(rcevent.editor.replace(" ","_"), "auto", RCPLists.c_greylist, "new user matching bnu", eval(self.config["glonbnu"]),60)
			self.Lists.greylist[rcevent.editor.replace(" ","_")]=item
	

	def process_rcDelArticle(self, rcevent):
		classes=set(("delete",))
		msgno=5300
		articletype, artitem = self.Lists.classifyarticle(rcevent.articlename)
		if articletype == RCPLists.c_ignorelist:
			return
		if articletype == RCPLists.c_watchlist:
			classes.add("watched")
			classes.add("cvp")
			msgno=5301
		
		msg = self.getMsg(msgno, {
			"earticle": quote(rcevent.articlename),
			"article": rcevent.articlename,
			"editor": rcevent.admin,
			"reason": rcevent.reason
			})

		self.reportEvent(msg, classes)

	def process_rcUnblockEditor(self, rcevent):
		classes = set(("block",))
		msg = self.getMsg(5700, {
			"blockname": rcevent.editor,
			"editor": rcevent.admin,
			"reason": rcevent.reason
			})
		self.reportEvent(msg, classes)
		self.blocks.deleteitem(rcevent.editor,rcevent.admin,'Unblocked:%s' % rcevent.reason)
		
	def process_rcBlockEditor(self, rcevent):

		classes = set(("block",))
		msg = self.getMsg(5400, {
			"blockname": rcevent.editor,
			"editor": rcevent.admin,
			"reason": rcevent.reason,
			"length": rcevent.length
			})

		self.reportEvent(msg, classes)
		
		# Blocked they won't be vandalising again so remove from greylist
		if rcevent.editor.replace(" ","_") in self.Lists.greylist:
			self.Lists.greylist.deleteitem(rcevent.editor.replace(" ","_"),"system","User blocked")
				
		if rcevent.length != None:
			if rcevent.length.lower() in ("indefinite","infinite"):
				expiresecs = 0
			else:
				expiresecs = getdate.getdate(rcevent.length)
				if expiresecs == -1:
					expiresecs=None
				else:
					expiresecs=expiresecs-time.time()

		if rcevent.length != None:
			newitem = RCPLists.ListEntry(rcevent.editor, rcevent.admin, 0, rcevent.reason, expiresecs, 1)

			oldblock = self.blocks.get(rcevent.editor)
			if oldblock == None:
				self.blocks[rcevent.editor] = newitem
			else:
				self.checkBlockConflict(newitem, oldblock)
		
		blacklist = True
		
		blacklistlength=0
		onehour = 60 * 60 
		oneday = 24 * onehour
		
		if rcevent.length != None:
			if expiresecs > 0:   # not indef, less than 12 hours, blacklist for 1 day after expiry
				blacklistlength = oneday
			if expiresecs > 12 * onehour:
				blacklistlength=3 * oneday
			if expiresecs > 36 * onehour:
				blacklistlength=14 * oneday
			if expiresecs > 4 * oneday:
				blacklistlength=30 * oneday
			if expiresecs > 28 * oneday:
				blacklistlength = 60 * oneday
			blacklistlength = blacklistlength + expiresecs
		else:
			blacklistlength = 7 * oneday
		
		if blacklistlength == 0:
			return
		
		editor = rcevent.editor.replace(" ","_")
	
		item = self.Lists.editors.get(editor,None) # Don't care aboute greylist
		if item != None:
			if item.type != RCPLists.c_blacklist:
				msg = self.getMsg(60+item.type, {"editor": editor})
				self.reportEvent(msg, classes)
				return

		if item == None or (item.expiry != 0 and ((item.expiry * item.expiryconvsecs) + item.timestamp) < (time.time() + blacklistlength)):
			item = RCPLists.ListEntry(editor, rcevent.admin, RCPLists.c_blacklist, "Autoblacklist: %s" % rcevent.reason, blacklistlength, 1)
			self.Lists.editors[editor]=item

		msg = self.getMsg(10000+(item.type*100)+22,item)
	
		self.reportEvent(msg, classes)
		
		
	def checkBlockConflict(self, newitem, olditem):
		classes = set(("blockconflict",))
		msgno = 0

		if newitem.expiry == 0 and olditem.expiry != 0:
			msgno = 5800

		if olditem.expiry == 0 and newitem.expiry != 0:
			self.blocks[newitem.what] = newitem # take the shortest
			msgno = 5801

		if olditem.expiry != 0 and newitem.expiry != 0:
			diff = (newitem.timestamp+newitem.expiry) - (olditem.timestamp+olditem.expiry)
			if diff < 0:
				self.blocks[newitem.what] = newitem # take the shortest
				if abs(diff) > eval(self.config["blockconflict"]) * 3600:
					msgno = 5802
			else:
				if diff > eval(self.config["blockconflict"]) * 3600:
					msgno = 5803

		if msgno == 0:
			return

		msg = self.getMsg(msgno, {
			"blockname": newitem.what,
			"oldadmin": olditem.who,
			"newadmin": newitem.who,
			"oldtime": olditem['expiry'],
			"newtime": newitem['expiry'],
			"oldreason": olditem['reason'],
			"newreason": newitem['reason'],
			})
		self.reportEvent(msg, classes)

	def process_rcMovePage(self, rcevent):
		classes = set(("move",))
		editortype, item = self.Lists.classifyeditor(rcevent.editor)
		classes.add(RCPLists.c_editor_events[editortype])
		
		msgno = 5500+editortype
		for word in self.Lists.moveWW:
			word = word.lower()
			result = re.search(word, rcevent.nameto, re.I)
			if result != None:
				msgno = 5510+editortype
				classes.add("wheeler")
				break
			else:
				result = re.search(word, rcevent.namefrom, re.I)
				if result != None:
					msgno = 5520+editortype
					classes.add("wheeler")
					break
		
		msg = self.getMsg(msgno, {
			"editor": rcevent.editor,
			"fromname": rcevent.namefrom,
			"toname": rcevent.nameto,
			"reason": rcevent.reason
			})

		self.reportEvent(msg, classes)

	def process_rcUploaded(self, rcevent):
		classes = set(("upload",))
		editortype, item = self.Lists.classifyeditor(rcevent.editor)
		imagetype, imgitem = self.Lists.classifyimage(rcevent.itemname)
		classes.add(RCPLists.c_editor_events[editortype])
		msgno = 5600+editortype
		
		if imagetype == RCPLists.c_img_watchlist:
			msgno = 5610+editortype
			classes.add("cvi")

		msg = self.getMsg(msgno,{
			"editor": rcevent.editor,
			"reason": rcevent.comment,
			"uploaditem": rcevent.itemname
			})
		
		self.reportEvent(msg, classes)

