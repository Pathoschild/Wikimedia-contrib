import Utils, ListManager, RCHandler, Version
from RCEvents import *
from urllib import quote 
import RCPLists

import sys, time, re, logging, Queue, logging.handlers
from string import Template


allevents = set((
		"once","newuser","wwuser","block","delete","move","upload","wheeler","blockconflict","grey","cvi","cvp",
		"watched","bigremove","bigedit","bignew","tinynew","black","-white","-admin","-bot","cmds","cmdsq"))

# Main class of interest, this gets the commands from the IRC Channel and
# processes them.  Receives the RCEvents and hands them onto the handler to deal with
#
class Processor:

	def __init__(self, lang):

		self.lang = lang
		
		self.logger = logging.getLogger("processor.%s" % lang)
		fh = logging.handlers.TimedRotatingFileHandler("Logs/%s/RCProcessor.log" % lang,"W0",2,26)
		fh.setFormatter(logging.Formatter("%(levelname)s %(asctime)s %(message)s"))
		self.logger.propogate = False
		self.logger.addHandler(fh)
		self.logger.setLevel(logging.DEBUG)
		self.logger.info("Processor for %s started" % lang)

		self.configitems = {
		"newbig"   : re.compile("^\d{1,6}$"),
		"newsmall" : re.compile("^\d{1,2}$"),
		"editbig"  : re.compile("^\d{1,6}$"),
		"editblank": re.compile("^-\d{1,6}$"),
		"blockconflict": re.compile("^\d{1,2}$"),
		"glonrollback": re.compile("^\d{1,2}$"),
		"pseudonym": re.compile("^\w{0,10}$"),
		"startupquiet": re.compile("^(?:yes|no)$")
		}

		#self.reWikiTidy = re.compile("(\[\[.*?\(|.*?)\]\]")
		self.reAdminRollback = re.compile("Reverted edits by \[\[Special:Contributions\/.*?\|(.*?)\]\]")

		self.console = None
		self.reader = None
		self.initok = False
		self.firsteventtime = 0
		self.silent={}
		self.silentwho = {}
		self.silentwhen = {}

		self.lasteventtime = time.time()
		self.lasteventtype = "Reset"

		self.help = Utils.readHelp(lang,Utils.readHelp('en'))
		self.staticconfig=Utils.readConfig("Config/%s/StaticConfig" % self.lang)
		self.readMessages()

		self.Lists = RCPLists.Lists(lang, self.getMsg, self.staticconfig)
		self.RCHandler = RCHandler.StandardHandler(self.Lists, self.reportEvent, lang, self.getMsg)

		self.routes = ListManager.getlist(lang,'Routes')
		self.stats = ListManager.getlist(lang,'Stats') # Probably a shelf to gather long term stats
		self.config = ListManager.getlist(lang,'Config')
		Utils.mergeConfig("Config/Default.conf", self.config, False)
	
		for channel in self.routes:
			if self.config["startupquiet"] == "yes":
				self.silent[channel]=True
			else:
				self.silent[channel]=False
			self.silentwhen[channel]=time.time()
			self.silentwho[channel]=''
		cc = self.staticconfig["controlchannel"]	
		self.silent[cc]=(self.config["startupquiet"] == "yes")
		self.silentwhen[cc]=time.time()
		self.silentwho[cc]=''
		
		self.gotts = False
		if "tsdatabase" in self.staticconfig:
			self.tsqueueout = queue (1000)
			try:
				# Attempt to instance toolserver processor thread here
				pass
				self.gotts = True
			except:
				self.gotts = False
				del self.tsqueueout

	# The commands the bot accepts as a dictionary mapping to array of 
	# four values. 
	# 1st the method to process the msg.
	# 2nd the destination of the response. either "C" for channel, "P" for private, "N" for notice to users
	# 3rd the privilege level required to run either "" for none, "+" for voiced or "@" for op'd
	# 4th if this command should be accepted on channels without a "cmdsq" or "cmds" event

		self.botCommands = {
				"dest"    : [self.cmdDest, "C", "!",False],
				"help"    : [self.cmdHelp, "P", "",False],
				"nhelp"   : [self.cmdHelp, "N", "",False],
				"wl"      : [self.cmdWL, "C","+",False],
				"al"      : [self.cmdAL,"C","!",False],
				"bl"      : [self.cmdBL,"C","+",False],
				"gl"      : [self.cmdGL,"C","+",False],
				"acl"     : [self.cmdACL, "C", "+",False],
				"aclo"   : [self.cmdACLO,"C","@",False],
				"bot"     : [self.cmdBot,"C","!",False],
				"cvp"     : [self.cmdCVP,"C","+",False],
				"cvi"     : [self.cmdCVI,"C","+",False],
				"cnvp"    : [self.cmdCNVP,"C","@",False],
				"bnu"     : [self.cmdBNU,"C","+",False],
				"wheels"  : [self.cmdWheels,"C","+",False],
				"config"  : [self.cmdConfig,"C","@",False],
				"bcl"     : [self.cmdBCL,"C","",False],
				"intel"   : [self.cmdBCL, "C", "",False],
				"aintel"  : [self.cmdAIntel, "C", "",False],
				"iintel"  : [self.cmdIIntel, "C", "",False],
				"quiet"   : [self.cmdQuiet,"C","+",True],
				"speak"   : [self.cmdSpeak,"C","+",True],
				"shutdown": [self.cmdShutdown,"C","@",False],
				"reader"  : [self.cmdReader,"C","!",False],
				"status"  : [self.cmdStatus,"C","",True],
				"quietall": [self.cmdQuietAll,"C","!",False],
				"owner"   : [self.cmdInfo,"C","",True],
				"info"    : [self.cmdInfo,"C","",True],
				"stats"   : [self.cmdStats,"C","",False]
				}
		initok = True
		
	def readMessages(self):
		msgs = Utils.readConfig("Config/%s/Console.msgs" % self.lang, Utils.readConfig("Config/en/Console.msgs"));
		bu = self.staticconfig["baseurl"]
		pr = self.staticconfig["prefixwikilinks"]

		for msgno, msg in msgs.iteritems():
			msg = msg.replace("${baseurl}",bu).replace("[[","[[%s" % pr).replace("%c","\x03").replace("%o","\x0f").replace("%b","\x02").replace("%u","\x1f")
			msgs[msgno] = Template(msg)
		self.msgs = msgs

	def getMsg(self, msgno, dict={}):
		return self.msgs["%05u" % msgno].substitute(dict)

	def setConsole(self, console):
		self.console = console
		console.join(self.staticconfig['controlchannel'],self)
		for channel in self.routes:
			if channel.startswith('#'):
				console.join(channel,self)

	def delConsole(self):
		self.console = None

	def setReader(self, reader):
		self.reader = reader

	def delReader(self):
		self.reader = None


#*****************First Part - Deals with IRC Commands *************************
#*******************************************************************************

	def cmdShutdown(self, source, subcommand, data, user, channel):
		self.logger.info("Shutdown initiated by %s on %s" % (user, channel))
		source.shutdown()
		return ""
		
	def cmdInfo(self, source, subcommand, data, user, channel):
		return self.getMsg(90,{"owner":self.console.getowner(), "version": "%2.2f" % Version.VERSION})
	
	def cmdSpeak(self, source, subcommand, data, user, channel):
		if self.silent[channel]:
			self.silent[channel]=False
			self.silentwho[channel]=user
			self.silentwhen[channel]=time.time()
			return self.getMsg(5)
		
		return ""

	def cmdQuietAll(self, source, subcommand, data, user, channel):
		reason = "%s %s" % (subcommand, data)
		msg = self.getMsg(80,{"user":user, "channel": channel, "reason": reason})
		for channel2 in self.silent:
			if not self.silent[channel2]:
				self.silent[channel2] = True
				self.silentwhen[channel2] = time.time()
				self.silentwho[channel2] = user
				if channel != channel2:
					source.msg(channel2, msg)
		return self.getMsg(81)

	def cmdQuiet(self, source, subcommand, data, user, channel):
		if not self.silent[channel]:
			self.silent[channel]=True
			self.silentwho[channel]=user
			self.silentwhen[channel]=time.time()
			return self.getMsg(7)
		return ""

	def cmdStatus(self, source, subcommand, data, user, channel):
		if self.reader == None:
				return self.getMsg(41)
		else:
			lasttime = str(time.time() - self.lasteventtime)
			lasttype = self.lasteventtype
			msg = self.getMsg(42,{"lastrcevent": lasttime, "lastrceventtype" : lasttype})

		if self.silent[channel]:
			msg = self.getMsg(43, {"silentwho":self.silentwho[channel], "silentwhen":time.strftime("%H:%M:%S %d-%b-%Y UTC", time.gmtime(self.silentwhen[channel]))}) + "\n" + msg
		else:
			msg = self.getMsg(44, {"silentwho":self.silentwho[channel], "silentwhen":time.strftime("%H:%M:%S %d-%b-%Y UTC", time.gmtime(self.silentwhen[channel]))}) + "\n" + msg
		return msg

	def cmdReader(self, source, subcommand, data, user, channel):
		subcommand = subcommand.lower()
		if subcommand == "reset" and self.reader != None:
			self.reader.reset()
			self.lasteventtime = time.time()
			self.lasteventtype = "Reset"
			self.firsteventtime = 0
			return self.getMsg(40)
		if subcommand == "reset":
			return self.getMsg(41)
		if subcommand == "status":
			if self.reader == None:
				return self.getMsg(41)
			else:
				lasttime = str(time.time() - self.lasteventtime)
				lasttype = self.lasteventtype
				return self.getMsg(42,{"lastrcevent": lasttime, "lastrceventtype" : lasttype})
		return getMsg(2,{"command": subcommand})
			
	def cmdStats(self, source, subcommand, data, user, channel):
		if subcommand == "full":
			return self.fullstats()
			
		endtime = long(time.time())
		begtime = endtime-3600
		total = self.stats["total"]
		msg = self.getMsg(200,
			{"total":total.get("total",0),
			 "totale":total.get("rcEdit",0)+total.get("rcNew",0),
			 "totalb":total.get("rcBlockEditor",0),
			 "totald":total.get("rcDelArticle",0),
			 "totalu":total.get("rcNewEditor",0)})
		
		if self.firsteventtime == 0 or time.time() < self.firsteventtime + 3600:
			msg = msg + "\n" + self.getMsg(203)
			return msg
		
		runtot = {}
		for mintime in range(int(begtime), int(endtime), 60):
			mintotal = self.stats.get(time.strftime("%Y%m%d%H%M",time.gmtime(mintime)),{})
			for key in mintotal:
				runtot[key]=runtot.get(key,0)+mintotal[key]
		
		msg = msg + "\n" + self.getMsg(201,
			{"total":runtot.get("total",0),
			 "totale":runtot.get("rcEdit",0)+runtot.get("rcNew",0),
			 "totalb":runtot.get("rcBlockEditor",0),
			 "totald":runtot.get("rcDelArticle",0),
			 "totalu":runtot.get("rcNewEditor",0)})
		
		msg = msg + "\n" + self.getMsg(202,
			{"total":runtot.get("total",0)/60,
			 "totale":(runtot.get("rcEdit",0)+runtot.get("rcNew",0))/60,
			 "totalb":runtot.get("rcBlock",0)/60,
			 "totald":runtot.get("rcDelArticle",0)/60,
			 "totalu":runtot.get("rcNewEditor",0)/60})
		
		return msg
		
	def fullstats(self):
		endtime = time.time()
		begtime = endtime-3600
		msg = self.getMsg(210) + self.statsbreakdown(self.stats.get("total",{}),1)
		
		if self.firsteventtime == 0 or time.time() < self.firsteventtime + 3600:
			msg = msg + "\n" + self.getMsg(203)
			return msg
		
		runtot = {}
		for mintime in range(begtime, endtime, 60):
			mintotal = self.stats.get(time.strftime("%Y%m%d%H%M",time.gmtime(mintime)),{})
			for key in mintotal:
				runtot[key]=runtot.get(key,0)+mintotal[key]

		msg = msg + "\n" + self.getMsg(211) + self.statsbreakdown(runtot)
		
		msg = msg + "\n" + self.getMsg(212) + self.statsbreakdown(runtot,60)
		
		return msg
		
	def statsbreakdown(self, map, divisor=1):
		if len(map) == 0:
			return "\n" + self.getMsg(214)
		retval = ""
		for event in sorted(map.keys()):
			retval = retval +"\n" + self.getMsg(213,{"event":event,"number":map.get(event,0)/divisor})
		return retval

	def cmdWL(self, source, subcommand, data, user, channel):
			return self.Lists.updateList(RCPLists.c_editorlist, RCPLists.c_whitelist, subcommand, data, user)

	def cmdBL(self, source, subcommand, data, user, channel):
			return self.Lists.updateList(RCPLists.c_editorlist, RCPLists.c_blacklist, subcommand, data, user)

	def cmdAL(self, source, subcommand, data, user, channel):
			return self.Lists.updateList(RCPLists.c_editorlist, RCPLists.c_adminlist, subcommand, data, user)

	def cmdGL(self, source, subcommand, data, user, channel):
			return self.Lists.updateList(RCPLists.c_grey, RCPLists.c_greylist, subcommand, data, user)

	def cmdBot(self, source, subcommand, data, user, channel):
			return self.Lists.updateList(RCPLists.c_editorlist, RCPLists.c_bot, subcommand, data, user)

	def cmdACL(self, source, subcommand, data, user, channel):
			return self.Lists.updateList(RCPLists.c_acl, 0, subcommand, data, user)
			
	def cmdACLO(self, source, subcommand, data, user, channel):
			return self.Lists.updateList(RCPLists.c_aclo, 0, subcommand, data, user)

	def cmdCVI(self, source, subcommand, data, user, channel):
		return self.Lists.updateList(RCPLists.c_imagelist, RCPLists.c_img_watchlist, subcommand, data, user)

	def cmdCVP(self, source, subcommand, data, user, channel):
		return self.Lists.updateList(RCPLists.c_articlelist, RCPLists.c_watchlist, subcommand, data, user)

	def cmdCNVP(self, source, subcommand, data, user, channel):
		return self.Lists.updateList(RCPLists.c_articlelist, RCPLists.c_ignorelist, subcommand, data, user)

	def cmdBNU(self, source, subcommand, data, user, channel):
		return self.Lists.updateList(RCPLists.c_watchwords, 0, subcommand, data, user)

	def cmdWheels(self, source, subcommand, data, user, channel):
		return self.Lists.updateList(RCPLists.c_wheelerwords, 0, subcommand, data, user)

	def cmdDest(self, source, subcommand, data, user, channel):
		subcommand = subcommand.lower()
		
		if subcommand == "list":
			space = " "
			tempchans=[]
			temppres=[]
			for channel in sorted(self.routes.keys()):
				if channel[0] == '#':
					tempchans.append(channel)
				else:
					temppres.append(channel)
			if len(tempchans) != 0:
				output = self.getMsg(110) 
				for channel in tempchans:
					output=output+"\n"+self.getMsg(114,{"channel":channel, "events": space.join(sorted(self.routes[channel]))})
			else:
				output = self.getMsg(112)

			if len(temppres) != 0:
				output = output + "\n" +self.getMsg(111) 
				for channel in temppres:
					output=output+"\n"+self.getMsg(114,{"channel":channel, "events": space.join(sorted(self.routes[channel]))})
			else:
				output = output + "\n" +self.getMsg(113)
			
			return output

		if subcommand == "swap":
			channels = data.split()
			if len(channels) != 2:
				return self.getMsg(11)
			channel1 = channels[0]
			channel2 = channels[1]
			if channel1.startswith("!") or channel2.startswith("!"):
				return self.getMsg(11)
			if not channel1.startswith("#"):
				channel1 = "#"+channel1
			if not channel2.startswith("#"):
				channel2 = "#"+channel2
			
			if channel1 not in self.routes and channel2 not in self.routes:
				return self.getMsg(19)
			
			routes2 = None
			
			routes1 = self.routes.get(channel1)
			if routes1 != None:
				del self.routes[channel1]
				del self.silent[channel1]

			routes2 = self.routes.get(channel2)

			if routes2 != None:
				del self.routes[channel2]
			
			if routes1 != None:
				self.routes[channel2] = routes1
				if routes2 == None:
					self.console.join(channel2,self)
					self.silent[channel2]=(self.config["startupquiet"] == "yes")
					self.silentwho[channel]=user
					self.silentwhen[channel]=time.time()
			else:
				if routes2 != None:
					source.leave(channel2,self, "swapped with %s" % channel1)
					del self.silent[channel2]
			
			if routes2 != None:
				self.routes[channel1] = routes2
				if routes1 == None:
					self.console.join(channel1,self)
					self.silent[channel1]=(self.config["startupquiet"] == "yes")
					self.silentwho[channel]=user
					self.silentwhen[channel]=time.time()
			else:
				if routes1 != None:
					source.leave(channel1,self,"swapped with %s" % channel2)
					del self.silent[channel1]

			return self.getMsg(28, {"channel1" : channel1, "channel2" : channel2})
		
		if subcommand not in ("add","del","set"):
			return self.getMsg(2,{"command":subcommand})

		words = data.split()
		channel = words[0]
		if not (channel.startswith("#") or channel.startswith("!")):
			channel = "#"+channel
		events = words[1:]
			
		if subcommand == "set":
			if len(events) != 1:
				return self.getMsg(4,{"command" : "dest set"})
			if events[0] not in self.routes:
				return self.getMsg(27,{"channel1":channel, "channel2": events[0]})
			if channel.startswith("#") and channel not in self.routes:
				self.console.join(channel,self)
				self.silent[channel]=(self.config["startupquiet"] == "yes")
				self.silentwho[channel]=user
				self.silentwhen[channel]=time.time()
			self.routes[channel]=set(self.routes[events[0]])
			return self.getMsg(29,{"channel1":channel, "channel2": events[0]})
		
		badevents = set()
		badstr = ""
		okevents = set()
		okstr = ""
		for eventtype in events:
			if eventtype not in allevents:
				badevents.add(eventtype)
			else:
				okevents.add(eventtype)
				
		for event in sorted(badevents):
			badstr = badstr + " " + event
		badstr = badstr.strip()
		for event in sorted(okevents):
			okstr = okstr + " " + event
		okstr = okstr.strip()
		
		if len(okevents) == 0:
			return self.getMsg(10,{"events":badstr})
			
		if subcommand == "add":
			if channel in self.routes:
				self.routes[channel]=self.routes[channel].union(okevents)
			else:
				self.routes[channel]=okevents
				if channel.startswith("#"):
					self.console.join(channel,self)
					self.silent[channel]=(self.config["startupquiet"] == "yes")
					self.silentwho[channel]=user
					self.silentwhen[channel]=time.time()
			return self.getMsg(6,{"events":okstr, "channel":channel})
		
		if subcommand == "del":
			if channel in self.routes:
				self.routes[channel]=self.routes[channel].difference(okevents)
				if len(self.routes[channel]) == 0:
					if channel.startswith("#"):
						source.leave(channel, self, "No longer needed")
						del self.silent[channel]
					del self.routes[channel]
			return self.getMsg(8,{"events":okstr, "channel":channel})


	def cmdConfig(self, source, subcommand, data, user, channel):

		subcommand = subcommand.lower()

		if subcommand == "list":
			msg = self.getMsg(13)
			for item, value in self.config.iteritems():
				msg = msg +"\n%s = %s" % (item, value)
			return msg
		if subcommand == "unkick":
			if not data.startswith('#'):
				data="#"+data
			if self.console.unkick(data, user):
				return self.getMsg(70,{"channel":data})
			else:
				return self.getMsg(71,{"channel":data})
		
		if subcommand == "readmsgs":
			self.readMessages()
			return self.getMsg(0)
			
		if subcommand == "getadmins":
			self.Lists.getEditors(user, RCPLists.c_adminlist, self.staticconfig["baseurl"] + "/w/index.php?title=Special:Listusers&limit=2000&offset=0&group=sysop")
			return self.getMsg(91)

		if subcommand == "getbots":
			self.Lists.getEditors(user, RCPLists.c_bot, self.staticconfig["baseurl"] + "/w/index.php?title=Special:Listusers&limit=2000&offset=0&group=bot")
			return self.getMsg(91)
		
		if subcommand not in self.configitems:
			return self.getMsg(14,{"configname":subcommand})
		checkformat = self.configitems[subcommand].search(data.strip())
		if checkformat == None:
			return self.getMsg(15,{"configname": subcommand, "configvalue": data})
		self.config[subcommand]=data.strip()
		return self.getMsg(16,{"configname": subcommand, "configvalue": data})

	def cmdBCL(self, source, subcommand, data, user, channel):
		ed = (subcommand + " " + data).strip() # .replace(" ","_")
		editortype, item = self.Lists.classifyeditor(ed)
		if item != None:
			msg = self.getMsg(10000+(editortype*100)+22, item)
		else:
			#msg = self.getMsg(20+editortype-RCPLists.c_anon,{"editor":ed.replace("_"," ")})
			msg = self.getMsg(20+editortype-RCPLists.c_anon,{"editor":ed})

		return msg + "\n" + self.getMsg(30,{"editor":ed})

	def cmdAIntel(self, source, subcommand, data, user, channel):
		art = (subcommand + " " + data).strip() # .replace(" ","_")
		articletype, artitem = self.Lists.classifyarticle(art)
		if articletype in (RCPLists.c_watchlist, RCPLists.c_ignorelist):
			msg = self.getMsg(11000+(artitem.type*100)+22, artitem)
		else:
			#msg = self.getMsg(35,{"article": art.replace("_"," ")})
			msg = self.getMsg(35,{"article": art})
		return msg

	def cmdIIntel(self, source, subcommand, data, user, channel):
		img = (subcommand + " " + data).strip() # .replace(" ","_")
		imagetype, imgitem = self.Lists.classifyimage(img)
		if imagetype == RCPLists.c_img_watchlist:
			msg = self.getMsg(15000+(imgitem.type*100)+22, imgitem)
		else:
			# msg = self.getMsg(36,{"image": img.replace("_"," ")})
			msg = self.getMsg(36,{"image": img})
		return msg

	def cmdHelp(self, source, subcommand, data, user, channel):
		if subcommand in self.help:
			return self.help[subcommand]

		return self.getMsg(3,{"command":subcommand})

# Does the basic command processing, uses botCommands to route to the right
# method and takes the response and routes to the right destination.

	def processMessage(self, source, channel, user, msg, usermode, identified):
		origmsg = msg
		pseudonym = self.config["pseudonym"]
		if pseudonym == "":
			pseudonym = source.nickname
		
		checknick = re.search("^(%s|%s)(?: |:|>)(.*)" % (source.nickname, pseudonym),msg,re.I)
		if checknick == None:
			return
			
		self.logger.info("Got a message on %s by <%s> \"%s\"" % (channel, user, msg))

		if checknick.group(1).lower() == source.nickname.lower():
			usednick = True
		else:
			usednick = False
		
		msg = checknick.group(2)

		if usednick or not self.silent[channel]:
			reply=True
		else:
			reply=False

		fullcommands=False # Only accept a subset of commands in this channel
		eventset = self.routes.get(channel,set())
		if channel == self.staticconfig["controlchannel"] or len(eventset.intersection(("cmds","cmdsq"))) > 0:
			fullcommands=True # Accept all commands
		
		if (not usednick) and (not channel == self.staticconfig['controlchannel']) and "cmdsq" in eventset:
				reply=False # only listening for commands in this channel, say nothing

		try:
			(command, subcommand, data) = msg.split(None,2)
		except ValueError:
			data = ""
			try: 
				(command, subcommand) = msg.split(None,1)
			except ValueError:
				command = msg
				subcommand = ""

		commandAction = self.botCommands.get(command.lower())

		if commandAction == None:
			if reply and fullcommands:
				source.notice(user,self.getMsg(2,{"command":msg})) 
			return

		if usermode == "" or usermode == None:
			aclentry = self.Lists.acl.get(user.lower())
			usermode=""

			if aclentry != None:
				usermode="+"
		
		if usermode != "@" and identified and user.lower() in self.Lists.aclo:
			usermode = "!"
					
		self.logger.info("user has mode <%s> " % (usermode))

		# Check we are interested in all commands on this channel or it's a command we are interested in 
		if not (commandAction[3] or fullcommands):
			self.logger.info("Not processing not fullcommands")
			return

		if commandAction[2] == "+" and usermode == "":
			self.logger.info("Not processing command requires voice")
			if reply:
				source.notice(user,self.getMsg(120))
			return
			
		if commandAction[2] == "!" and usermode in ("", "+"):
			if identified == None and user in self.Lists.aclo:
				self.logger.info("Checking if user identitified")
				source.checkIdentified(user, channel, origmsg, self)
				return
			self.logger.info("Not processing command requires bot operator")
			if user in self.Lists.aclo and reply:
				source.notice(user,self.getMsg(129))
				return
			if reply:
				source.notice(user,self.getMsg(121))
			return
		
		if commandAction[2] == "@" and usermode != "@":
			self.logger.info("Not processing command requires ops")
			if reply:
				source.notice(user,self.getMsg(122))
			return
		
		response = commandAction[0](source, subcommand, data, user, channel)
		if not reply and not command.lower() == 'speak':  # Check silent in case is was the speak command
			return
	
		for line in response.splitlines():
			if commandAction[1] == "C":
				source.msg(channel, line)
			else:
				if commandAction[1] == "N":
					source.notice(user,line)
				else:
					source.msg(user, line)


#*****************Second Part - Deals with RC Events *************************
#*****************************************************************************
	
	# Called by the Handler to report the results of its dealing with the revents
	def reportEvent(self, msg, classes):
		
		if self.console == None:
			return
			
		destlist=set()

		for channel, routes in self.routes.iteritems():
			if channel.startswith("!"):
				continue
			if self.silent[channel]:
				continue
			skipit=False
			for check in (("-white","white"),("-admin","admin"),("-bot","bot")):
				if check[0] in routes and check[1] in classes:
					skipit=True
			if skipit:
				continue
			if len(routes.intersection(classes)) > 0:
				destlist.add(channel)
					
		if self.console == None or len(destlist) == 0:
			return
		else:
			self.console.multimsg(destlist, msg)
			

	def doRCEvent(self, rcevent):
	# Update the stats
		self.lasteventtime = time.time()
		if self.firsteventtime == 0:
			self.firsteventtime = self.lasteventtime
		
		cname = rcevent.__class__.__name__
		self.lasteventtype = cname
		
		thetime = time.strftime("%Y%m%d%H%M",time.gmtime(self.lasteventtime))
		if thetime not in self.stats:
			self.stats[thetime]={}

		timestats=self.stats[thetime]
		timestats[self.lasteventtype]=timestats.get(self.lasteventtype,0)+1
		timestats["total"]=timestats.get("total",0)+1
		self.stats[thetime]=timestats

		if "total" not in self.stats:
			self.stats["total"]={}

		timestats=self.stats["total"]

		timestats[self.lasteventtype]=timestats.get(self.lasteventtype,0)+1
		timestats["total"]=timestats.get("total",0)+1

		self.stats["total"]=timestats
		
		# See if our handler know how to process, if so execute the appropriate method
		handler = getattr(self.RCHandler,"process_"+cname,None)
		if handler != None:
			handler(rcevent)

