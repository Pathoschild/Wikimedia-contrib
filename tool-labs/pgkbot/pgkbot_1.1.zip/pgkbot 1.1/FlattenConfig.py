import cPickle, sys
from bz2 import BZ2File
import CVUBot.ListManager as ListManager

def writeitems(list, outputfile):
	count = 0
	for item, value in list.iteritems():
		if value != None:
			outputfile.write("key:%s\n" % item)
			cPickle.dump(value,outputfile,2)
			count = count + 1
	return count

lang = sys.argv[1]
filename = sys.argv[2]
outfile = BZ2File(filename,"w")

outfile.write("Config for %s\n" % lang)

outfile.write("#<editors>#\n")
count = writeitems(ListManager.getlist(lang,'UserList'), outfile)
print "Processed %d editors" % count

outfile.write("#<articles>#\n")
count = writeitems(ListManager.getlist(lang,'ArticleList'), outfile)
print "Processed %d articles" % count

outfile.write("#<new users watch words>#\n")
count = writeitems(ListManager.getlist(lang,'NewUserWatchWord'), outfile)
print "Processed %d bnu expressions" % count

outfile.write("#<wheeler words>#\n")
count = writeitems(ListManager.getlist(lang,'WheelerWords'), outfile)
print "Processed %d wheeler words" % count

outfile.write("#<image list>#\n")
count = writeitems(ListManager.getlist(lang,'ImageList'), outfile)
print "Processed %d images" % count

outfile.write("#<acl>#\n")
count = writeitems(ListManager.getlist(lang,'Acl'),outfile)
print "Processed %d acl entries" % count

outfile.close()


