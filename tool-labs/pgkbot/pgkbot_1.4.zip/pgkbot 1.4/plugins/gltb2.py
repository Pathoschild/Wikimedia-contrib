import CVUBot.RCPLists, shelve, re

class GreyListTawkerBot2:

	TITLE = "Greylist users reverted by Tawkerbot2"
	VERSION = 1
	PIVERSION = 2

	def __init__(self, lang, lists, reportEvent):
		self.reportEvent = reportEvent
		self.lang = lang
		self.lists = lists
		self.myconfig = shelve.open("plugins/Config/GLTB2-%s.dbm" % lang,"c")
		if "gltb2_mins" not in self.myconfig:
			self.myconfig["gltb2_mins"] = "10"
			self.myconfig.sync()
		if "gltb2_regex" not in self.myconfig:
			self.myconfig["gltb2_regex"] = "\[\[User.talk:(?P<user>.*?)(\||\]\])"
			self.myconfig.sync()
		self.reTB2msg = re.compile(self.myconfig["gltb2_regex"])
	
	def config(self, item, value=None):
		if item == "list":
			return "gltb2_mins = %s\ngltb2_regex = %s" % (self.myconfig["gltb2_mins"], self.myconfig["gltb2_regex"])
			
		if item == "gltb2_mins":
			if re.search("^\d{1,2}$", value) == None:
				return "Error in value must be 0 to 99"
			self.myconfig["gltb2_mins"] = value
			self.myconfig.sync()
			return "Config updated"
		elif item == "gltb2_regex":
			if re.search("\(\?P<user>", value) == None:
				return "Error regex doesn't contain a user group"
			try:
				x = re.compile(value)
			except re.error:
				return "Error not a valid python regex"
			self.myconfig["gltb2_regex"] = value
			self.reTB2msg = x
		else:
			return "Error, that isn't a config item for this plugin"

	def configitems(self):
		return ("gltb2_mins",)

	def rcPriority(self):
		return set((50,)) # Just after the main bot processes
		
	def handleRCEvent(self, rcEvent, resultlist, priority):
		if not rcEvent.__class__.__name__  == "rcEdit": # not an edit
			return rcEvent

		if rcEvent.editor != "Tawkerbot2": # is the editor tawkerbot2
			return rcEvent

		if eval(self.myconfig["gltb2_mins"]) == 0: # No time for greylisting
			return rcEvent

		res =	self.reTB2msg.search(rcEvent.summary)
		# Couldn't work it out
		if res == None:
			return rcEvent

		try:
			revertededitor = res.group("user")

			editortype, editoritem = self.lists.classifyeditor(revertededitor)
			if editortype in (CVUBot.RCPLists.c_anon,CVUBot.RCPLists.c_normal, CVUBot.RCPLists.c_whitelist, CVUBot.RCPLists.c_greylist):
				item = CVUBot.RCPLists.ListEntry(revertededitor.replace("_"," "), rcEvent.editor, CVUBot.RCPLists.c_greylist, "tawkerbot2 rollback on [[%s]]" % rcEvent.articlename , eval(self.myconfig["gltb2_mins"]), 60)
				self.lists.greylist[revertededitor.replace(" ","_")] = item
		except:
			pass
		
		return rcEvent











