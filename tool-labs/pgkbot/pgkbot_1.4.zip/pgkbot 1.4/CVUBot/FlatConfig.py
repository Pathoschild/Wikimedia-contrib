import ListManager, re, cPickle

# Define what we have out there, 
# key = identified in flat file 
# value = sequence of "List Name" (i.e. Listmanager name), "Description" and if should be loaded by default

maplists = {
	"editors"                :("UserList","editor list", True),
	"articles"               :("ArticleList","article list", True),
	"new users watch words"  :("NewUserWatchWord","bnu list", True),
	"new article watch words":("NewArticleWatchWord","bna list", True),
	"wheeler words"          :("WheelerWords","wheeler words", True),
	"image list"             :("ImageList","cvi list", True),
	"acl"                    :("Acl","acl", False),
	"aclo"                   :("Aclo","aclo", False),
	"flag list"              :("Flaglist","flag list", True),
	"ip category"            :("IPClassify","ip categories", True)}

def processitems(list, infile, stopevent):
	count = 0
	line = infile.readline()
	while line.startswith("key:"):
		item = line[4:].rstrip()
		value = cPickle.load(infile)
		list[item]=value
		line = infile.readline()
		count = count + 1
		if count % 500 == 0:
			stopevent.wait(0.01)  # wait a bit, let others access the list
			if stopevent.isSet():
				return "", count
	return line, count

def skipitems(infile, stopevent):
	count = 0
	line = infile.readline()
	while line.startswith("key:"):
		item = line[4:].rstrip()
		value = cPickle.load(infile)
		line = infile.readline()
		if count % 500 == 0:
			if stopevent.isSet():
				return "", count
		count = count + 1
	return line, count

def trymsg(msg, msghandler):
	try:
		msghandler(msg)
	except:
		pass

def loadconfig(lang, infile, msghandler, stopevent):
	line = infile.readline()
	if not line.startswith("Config for "):
		trymsg("Not a config file", msghandler)
		return False

	reHeader = re.compile("#<(.*?)>#")

	line = infile.readline()
	while line != "":
		if stopevent.isSet():
			break
		
		res = reHeader.search(line)

		if res == None:
			trymsg("Couldn't interpret header line %s" % line.strip(), msghandler)
			return False

		list = maplists.get(res.group(1))
		if list == None:
			trymsg("Skipping unknown list %s" % res.group(1), msghandler)
			line, count = self.skipitems(infile, stopevent)
			trymsg("Skipped unknown list %s" % res.group(1), msghandler)
			continue

		if list[2]:
			trymsg("Loading %s" % list[1],msghandler)
			line, count = processitems(ListManager.getlist(lang, list[0]), infile, stopevent)
			trymsg("Processed %d entries for %s" % (count,list[1]),msghandler)
			continue
				
		trymsg("Skipping %s" % list[1],msghandler)
		line, count = skipitems(infile, stopevent)
		trymsg("Skipped list %s" % list[1], msghandler)
		
	if line == "":
		return True
	else:
		return False

def saveconfig(lang, outfile, msghandler, stopevent):
	global maplists
	outfile.write("Config for %s\n" % lang)
	for name, list in maplists.iteritems():
		if stopevent.isSet():
			break
		trymsg("Starting %s" % list[1], msghandler)
		outfile.write("#<%s>#\n" % name)
		count = 0
		thelist = ListManager.getlist(lang, list[0])
		for item, value in thelist.iteritems():
			count = count + 1
			if count % 200 == 0:
				stopevent.wait(0.1) # short pause every 200 items
				if stopevent.isSet():
					break
			if value != None:
				outfile.write("key:%s\n" % item)
				cPickle.dump(value,outfile,2)
		trymsg("Written %d items for %s" % (count, list[1]), msghandler)
	if stopevent.isSet():
		return False
	else:
		return True
