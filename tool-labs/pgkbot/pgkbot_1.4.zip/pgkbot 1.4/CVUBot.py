#!/bin/python
#
# Main program for CVUBot. Determines platform and imports/calls the appropriate startup
#
import platform
if platform.system() in ("Windows","Microsoft"):
	from CVUBot.CVUBotW import main
else:
	from CVUBot.CVUBotU import main

main()
